<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Pasar consulta - a�adir s�ntoma</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuMedico.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:form>
					<h:outputText value="#{msg.pasarConsulta}" styleClass="h1" />
					<br>
					<br>
					<h:outputText value="#{msg.addSintoma}" styleClass="h2" />
					<br>
					<br>
					<h:panelGrid border="0" columns="3">
						<h:outputText value="#{msg.registroDescripcion}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputTextarea id="descripcion" required="true"
							value="#{beanAddSintoma.descripcion}" styleClass="textAreaSmall" />
						<h:message for="descripcion" styleClass="errorForm" />

						<h:outputText value="#{msg.registroValoracionGravedad}"
							styleClass="etiquetaForm"></h:outputText>
						<h:selectOneMenu id="valoracionGravedad" required="true"
							value="#{beanAddSintoma.valoracionGravedad}">
							<f:selectItems value="#{beanAddSintoma.valoracionesGravedad}" />
						</h:selectOneMenu>
						<h:message for="valoracionGravedad" styleClass="errorForm" />
					</h:panelGrid>
					<br>
					<br>
					<h:commandButton value="#{msg.addSintoma}" id="addSintoma"
						actionListener="#{beanAddSintoma.addSintoma}"
						binding="#{beanAddSintoma.botonAdd}" />
					<h:message for="addSintoma" styleClass="errorForm" />
					<br>
					<h:commandButton value="#{msg.continuar}"
						actionListener="#{beanAddDiagnostico.addDiagnosticoListener}"
						action="continuar" immediate="true">
						<f:param id="citaId" value="#{beanAddSintoma.cita}" />
					</h:commandButton>
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>