<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Registrar m�dico</title>
</head>
<body>
	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuAdministrador.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.registrarMedico}" styleClass="h1" />
				<br>
				<br>
				<h:form id="registroMedico">
					<h:outputText value="#{msg.datosPersonales}" styleClass="h2" />
					<br>
					<br>
					<h:panelGrid border="0" columns="3">
						<h:outputText value="#{msg.registroNombre}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="nombre" value="#{beanRegistroMedico.nombre}"
							required="true" />
						<h:message for="nombre" styleClass="errorForm" />

						<h:outputText value="#{msg.registroApellidos}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="apellidos"
							value="#{beanRegistroMedico.apellidos}" required="true"></h:inputText>
						<h:message for="apellidos" styleClass="errorForm" />

						<h:outputText value="#{msg.registroNumColegiado}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="numColegiado"
							value="#{beanRegistroMedico.numColegiado}" required="true">
							<f:validateLength minimum="9" maximum="9" />
							<f:validateLongRange/>
						</h:inputText>
						<h:message for="numColegiado" styleClass="errorForm" />

						<h:outputText value="#{msg.registroCM}" styleClass="etiquetaForm"></h:outputText>
						<h:selectOneMenu id="centroMedico"
							value="#{beanRegistroMedico.centroMedico}" required="true">
							<f:selectItems value="#{beanRegistroMedico.centrosMedicos}" />
						</h:selectOneMenu>
						<h:message for="centroMedico" styleClass="errorForm" />
					</h:panelGrid>

					<br>
					<br>
					<h:outputText value="#{msg.datosAplicacion}" styleClass="h2" />
					<br>
					<br>
					<h:panelGrid border="0" columns="3">
						<h:outputText value="#{msg.registroNombreUsuario}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="nombreUsuario"
							value="#{beanRegistroMedico.nombreUsuario}" required="true">
							<f:validator validatorId="validadorNombreUsuario" />
						</h:inputText>
						<h:message for="nombreUsuario" styleClass="errorForm" />

						<h:outputText value="#{msg.registroClave}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputSecret id="clave" value="#{beanRegistroMedico.clave}"
							required="true" binding="#{beanRegistroMedico.inputClave}">
							<f:validateLength minimum="3" />
						</h:inputSecret>
						<h:message for="clave" styleClass="errorForm" />

						<h:outputText value="#{msg.registroClave2}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputSecret id="clave2" value="#{beanRegistroMedico.clave2}"
							required="true" validator="#{beanRegistroMedico.validarClave2}" />
						<h:message for="clave2" styleClass="errorForm" />
					</h:panelGrid>
					<br>
					<br>
					<h:commandButton value="#{msg.registrar}"
						action="#{beanRegistroMedico.registrar}"></h:commandButton>
				</h:form>


			</h:panelGroup>
		</h:panelGrid>

	</f:view>

</body>
</html>