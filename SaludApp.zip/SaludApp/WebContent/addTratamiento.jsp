<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Pasar consulta - a�adir tratamiento</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuMedico.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:form>
					<h:outputText value="#{msg.pasarConsulta}" styleClass="h1" />
					<br>
					<br>
					<h:outputText value="#{msg.addTratamiento}" styleClass="h2" />
					<br>
					<br>
					<h:panelGrid border="0" columns="3">
						<h:outputText value="#{msg.registroMedicamento}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="medicamento" required="true"
							value="#{beanAddTratamiento.medicamento}" />
						<h:message for="medicamento" styleClass="errorForm" />

						<h:outputText value="#{msg.registroCantidad}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="cantidad" required="true"
							value="#{beanAddTratamiento.cantidad}" />
						<h:message for="cantidad" styleClass="errorForm" />

						<h:outputText value="#{msg.registroDosisDiaria}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="dosisDiaria" required="true"
							value="#{beanAddTratamiento.dosisDiaria}" />
						<h:message for="dosisDiaria" styleClass="errorForm" />
					</h:panelGrid>
					<h:panelGrid border="0" columns="4">
						<h:outputText value="#{msg.registroInicio}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="inicio" value="#{beanAddTratamiento.inicio}"
							required="true">
							<f:validator validatorId="validadorFecha"/>
							<f:converter converterId="conversorFecha" />							
						</h:inputText>
						<h:outputText value="(YYYY-MM-dd)" />
						<h:message for="inicio" styleClass="errorForm" />

						<h:outputText value="#{msg.registroFin}" styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="fin" value="#{beanAddTratamiento.fin}"
							required="true">
							<f:validator validatorId="validadorFecha"/>
							<f:converter converterId="conversorFecha" />
						</h:inputText>
						<h:outputText value="(YYYY-MM-dd)" />
						<h:message for="fin" styleClass="errorForm" />
					</h:panelGrid>
					<br>
					<h:commandButton value="#{msg.addTratamiento}" id="addTratamiento"
						actionListener="#{beanAddTratamiento.addTratamiento}"
						binding="#{beanAddTratamiento.botonAdd}" />
					<h:message for="addTratamiento" styleClass="errorForm" />
					<br>
					<br>
					<h:commandButton value="#{msg.pedirCitaRevision}"
						actionListener="#{beanPedirCitaRevision.pedirCitaRevisionListener}"
						action="pedirCitaRevision" immediate="true">
						<f:param id="citaId" value="#{beanAddTratamiento.cita}" />
					</h:commandButton>
					<h:commandButton value="#{msg.finalizarConsulta}"
						action="finalizarConsulta" immediate="true">
					</h:commandButton>
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>