<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Pasar consulta - a�adir diagn�stico</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuMedico.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:form id="addDiagnostico">
					<h:outputText value="#{msg.pasarConsulta}" styleClass="h1" />
					<br>
					<br>
					<h:outputText value="#{msg.addDiagnostico}" styleClass="h2" />
					<br>
					<br>
					<h:panelGrid border="0" columns="3">
						<h:outputText value="#{msg.registroEnfermedad}"
							styleClass="etiquetaForm"></h:outputText>
						<h:inputText id="enfermedad"
							value="#{beanAddDiagnostico.enfermedad}"
							required="true" />
						<h:message for="enfermedad" styleClass="errorForm" />

						<h:selectBooleanCheckbox
							value="#{beanAddDiagnostico.hospitalizacion}">
							<h:outputText value="#{msg.registroHospitalizacion}"
								styleClass="etiquetaForm"></h:outputText>
						</h:selectBooleanCheckbox>
					</h:panelGrid>
					<br>
					<br>
					<h:commandButton value="#{msg.addDiagnostico}" id="addDiagnostico"
						actionListener="#{beanAddDiagnostico.addDiagnostico}"
						binding="#{beanAddDiagnostico.botonAdd}" />
					<h:message for="addDiagnostico" styleClass="errorForm" />
					<br>
					<h:commandButton value="#{msg.continuar}"
						actionListener="#{beanAddTratamiento.addTratamientoListener}"
						action="continuar" immediate="true">
						<f:param id="citaId" value="#{beanAddSintoma.cita}" />
					</h:commandButton>
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>