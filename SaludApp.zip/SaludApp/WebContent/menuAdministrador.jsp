<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />
<link rel="stylesheet" type="text/css" href="css/plantilla.css">

<h:panelGrid border="0" columns="1">
	<h:outputLink value="registroCentroMedico.faces">
		<h:outputText value="#{msg.registrarCM}"></h:outputText>
	</h:outputLink>
	<h:outputLink value="registroMedico.faces">
		<h:outputText value="#{msg.registrarMedico}"></h:outputText>
	</h:outputLink>
	<h:outputLink value="registroPaciente.faces">
		<h:outputText value="#{msg.registrarPaciente}"></h:outputText>
	</h:outputLink>
	<hr>
	<h:outputLink value="adscribirMedico.faces">
		<h:outputText value="#{msg.adscribirMedico}"></h:outputText>
	</h:outputLink>
	<h:outputLink value="pedirCitaUrgencia.faces">
		<h:outputText value="#{msg.pedirCitaUrgencia}"></h:outputText>
	</h:outputLink>
	<h:outputLink value="resolverSolicitudCM.faces">
		<h:outputText value="#{msg.resolverSolicitudCM}"></h:outputText>
	</h:outputLink>
	<hr>
	<h:outputLink value="listarUsuarios.ctrl">
		<h:outputText value="#{msg.listarUsuarios}"></h:outputText>
	</h:outputLink>
	<hr>
	<h:form>
		<h:commandLink value="#{msg.verSugerencias}"
			action="verSugerencias"
			actionListener="#{beanSugerencia.verSugerencias}">
		</h:commandLink>
	</h:form>
</h:panelGrid>
