<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@ taglib prefix="tag" tagdir="/WEB-INF/tags"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Pedir cita</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuPaciente.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.pedirCita}" styleClass="h1" />
				<br>
				<br>
				<h:outputText value="#{msg.noAdscrito}"
					rendered="#{beanPedirCita.mostrarMsgNoAdscrito}" />

				<h:panelGrid border="0" columns="1"
					rendered="#{beanPedirCita.mostrarPanelCita}">
					<h:outputText value="#{msg.citaPendiente}" styleClass="h2" />
					<h:panelGrid border="0" columns="1" />
					<h:panelGrid border="0" columns="2">
						<h:outputText value="#{msg.dia}" styleClass="etiquetaForm" />
						<h:outputText value="#{beanPedirCita.dia}" />
					</h:panelGrid>
					<h:panelGrid border="0" columns="4">
						<h:outputText value="#{msg.horaInicio}" styleClass="etiquetaForm" />
						<h:outputText value="#{beanHoraDuracion.horaInicio}" />
						<h:outputText value=":" />
						<h:outputText value="#{beanHoraDuracion.minutoInicio}" />

						<h:outputText value="#{msg.duracion}" styleClass="etiquetaForm" />
						<h:outputText value="#{beanHoraDuracion.duracion}">
							<f:converter converterId="conversorDuracion" />
						</h:outputText>
						<h:panelGroup />
						<h:outputText value="#{msg.minutos}"></h:outputText>
					</h:panelGrid>
				</h:panelGrid>

				<h:panelGrid border="0" columns="1"
					rendered="#{beanPedirCita.mostrarPanelPedirCita}">
					<h:form id="pedirCita">
						<h:panelGrid border="0" columns="4">
							<h:outputText value="#{msg.dia}" styleClass="etiquetaForm" />
							<h:inputText value="#{beanPedirCita.dia}" id="dia"
								required="true">
								<f:converter converterId="conversorFecha" />
								<f:validator validatorId="validadorFecha" />
							</h:inputText>
							<h:outputText value="(YYYY-MM-dd)" />
							<h:message for="dia" styleClass="errorForm" />
						</h:panelGrid>
						<h:commandButton value="#{msg.verDisponibilidad}"
							actionListener="#{beanPedirCita.verDisponibilidad}" />
						<br>
						<br>
						<tag:intervalos intervalos1="${intervalos1}"
							intervalos2="${intervalos2}" />
						<br>
						<br>
						<jsp:include page="horaInicioDuracion.jsp" flush="true" />
						<br>
						<br>
						<h:commandButton value="#{msg.pedirCita}"
							action="#{beanPedirCita.registrar}" />
					</h:form>
				</h:panelGrid>

			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>