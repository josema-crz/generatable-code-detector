<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@ taglib uri="/sa" prefix="sa"%>
<%@ taglib prefix="tag" tagdir="/WEB-INF/tags"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Listar usuarios</title>
</head>
<body>
	<jsp:useBean id="medicos" type="java.util.Collection" scope="request" />

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuAdministrador.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.listarUsuarios}" styleClass="h1" />
				<br>
				<br>
				<h:outputText value="#{msg.pacientes}" styleClass="h2" />
				<tag:listaPacientes pacientes="${pacientes}" />
				<br>
				<br>
				<h:outputText value="#{msg.medicos}" styleClass="h2" />
				<table border="1">
					<tr>						
						<td width="45%">
							<p align="center">
								<b><h:outputText value="#{msg.apellidos}" /></b>
							</p>
						</td>
						<td width="15%">
							<p align="center">
								<b><h:outputText value="#{msg.nombre}" /></b>
							</p>
						</td>
						<td width="25%">
							<p align="center">
								<b><h:outputText value="#{msg.numColegiado}" /></b>
							</p>
						</td>
						<td width="15%">
							<p align="center">
								<b><h:outputText value="#{msg.nombreUsuario}" /></b>
							</p>
						</td>
					</tr>
					<sa:listaMedicos medicos="<%=medicos%>">
						<tr>
							<td width="45%" align="center"><%=apellidos%></td>
							<td width="15%" align="center"><%=nombre%></td>
							<td width="25%" align="center"><%=numColegiado%></td>
							<td width="15%" align="center"><%=nombreUsuario%></td>
						</tr>
					</sa:listaMedicos>
				</table>

			</h:panelGroup>
		</h:panelGrid>

	</f:view>

</body>
</html>