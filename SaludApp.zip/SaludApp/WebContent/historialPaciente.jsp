<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Ver historial del paciente</title>
</head>
<body>
	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuMedico.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.pasarConsulta}" styleClass="h1" />
				<br>
				<br>
				<h:outputText value="#{msg.historialPaciente}" styleClass="h2" />
				<br>
				<br>
				<h:form>
					<h:dataTable id="citas" value="#{beanHistorialPaciente.citas}"
						var="cita" border="1">
						<h:column>
							<f:facet name="header">
								<h:outputText value="#{msg.diaCita}" />
							</f:facet>
							<h:outputText value="#{cita.fecha}" />
						</h:column>
						<h:column>
							<f:facet name="header">
								<h:outputText value="#{msg.horaCita}" />
							</f:facet>
							<h:outputText value="#{cita.intervalo.horaInicio}" />
						</h:column>
						<h:column>
							<f:facet name="header">
								<h:outputText value="#{msg.medicoCita}" />
							</f:facet>
							<h:outputText value="#{cita.medico.nombre}" />
						</h:column>
						<h:column>
							<f:facet name="header">
								<h:outputText value="#{msg.verCita}" />
							</f:facet>
							<h:commandLink value="#{msg.verCita}" action="verDetallesCita"
								actionListener="#{beanDetallesCita.verDetallesCita}">
								<f:param id="citaId" value="#{cita.id}" />
							</h:commandLink>
						</h:column>
					</h:dataTable>
					<br>
					<br>
					<h:commandButton value="#{msg.continuar}"
						actionListener="#{beanAddSintoma.addSintomaListener}"
						action="continuar">
						<f:param id="citaId" value="#{beanHistorialPaciente.cita}" />
					</h:commandButton>
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>