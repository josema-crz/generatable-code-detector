<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Cambiar cita</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuPaciente.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.cambiarCita}" styleClass="h1" />
				<br>
				<br>
				<h:form id="cambiarCita">
					<h:outputText value="#{msg.cita}" styleClass="etiquetaForm" />
					<h:selectOneMenu value="#{beanCambiarCita.cita}" id="cita"
						required="true">
						<f:selectItems value="#{beanCambiarCita.citas}" />
					</h:selectOneMenu>
					<h:message for="cita" styleClass="errorForm" />
					<br>
					<br>
					<h:commandButton value="#{msg.cambiarCita}"
						actionListener="#{beanPedirCita.cambiarCitaListener}"
						action="pedirCita">
						<f:param id="idCita" value="#{beanCambiarCita.cita}" />
					</h:commandButton>
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>