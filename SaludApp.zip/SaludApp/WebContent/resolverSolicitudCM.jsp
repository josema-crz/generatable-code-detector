<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Resolver solicitud de cambio de m�dico</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuAdministrador.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.resolverSolicitudCM}" styleClass="h1" />
				<br>
				<br>
				<h:form>
					<h:panelGrid border="0" columns="3">
						<h:outputText value="#{msg.seleccioneSolicitud}"
							styleClass="etiquetaForm" />
						<h:selectOneMenu id="solicitud"
							value="#{beanResolverSolicitud.solicitud}" >
							<f:selectItems value="#{beanResolverSolicitud.solicitudes}" />
						</h:selectOneMenu>
						<h:commandButton value="#{msg.verDetallesSolicitud}"
							actionListener="#{beanResolverSolicitud.verDetalles}" />
					</h:panelGrid>
					<h:outputText binding="#{beanResolverSolicitud.msgFinal}"
						rendered="false" />
					<br>
					<h:panelGrid border="0" columns="2" rendered="false"
						binding="#{beanResolverSolicitud.panelDetalles}">
						<h:outputText value="#{msg.registroPaciente}"
							styleClass="etiquetaForm" />
						<h:outputText value="#{beanResolverSolicitud.paciente}" />

						<h:outputText value="#{msg.registroNuevoMedico}"
							styleClass="etiquetaForm" />
						<h:outputText value="#{beanResolverSolicitud.nuevoMedico}" />

						<h:outputText value="#{msg.cupoNuevoMedico}"
							styleClass="etiquetaForm" />
						<h:outputText value="#{beanResolverSolicitud.cupoNuevoMedico}" />

						<h:outputText value="#{msg.registroMotivoCambio}"
							styleClass="etiquetaForm" />
						<h:outputText value="#{beanResolverSolicitud.motivoCambio}" />

					</h:panelGrid>
					<br>
					<br>
					<h:commandButton value="#{msg.aceptar}"
						actionListener="#{beanResolverSolicitud.aceptar}"></h:commandButton>
					<h:commandButton value="#{msg.denegar}"
						actionListener="#{beanResolverSolicitud.denegar}"></h:commandButton>
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>