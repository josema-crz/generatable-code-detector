<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />
<link rel="stylesheet" type="text/css" href="css/plantilla.css">

<h:panelGrid border="0" columns="1">
	<h:outputLink value="consultarCitas.faces">
		<h:outputText value="#{msg.consultarCitas}"></h:outputText>
	</h:outputLink>
	<h:outputLink value="retrasarConsulta.faces">
		<h:outputText value="#{msg.retrasarConsulta}"></h:outputText>
	</h:outputLink>
	<hr>
	<h:form>
		<h:commandLink value="#{msg.establecerHorario}"
			action="establecerHorario"
			actionListener="#{beanHorario.establecerHorarioListener}">
		</h:commandLink>
	</h:form>
	<hr>
	<h:outputLink value="enviarAvisoMedico.faces">
		<h:outputText value="#{msg.enviarAviso}"></h:outputText>
	</h:outputLink>
	<h:outputLink value="enviarSugerencia.faces">
		<h:outputText value="#{msg.enviarSugerencia}"></h:outputText>
	</h:outputLink>
</h:panelGrid>
