<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Ver aviso m�dico</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuPaciente.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.verAviso}" styleClass="h1" />
				<br>
				<br>
				<h:panelGrid border="0" columns="2">
					<h:outputText value="#{msg.registroFecha}"
						styleClass="etiquetaForm" />
					<h:outputText value="#{beanAvisosMedico.fecha}" />

					<h:outputText value="#{msg.registroAsunto}"
						styleClass="etiquetaForm" />
					<h:outputText value="#{beanAvisosMedico.asunto}" />

					<h:outputText value="#{msg.registroTexto}"
						styleClass="etiquetaForm" />
					<h:outputText value="#{beanAvisosMedico.texto}" />
				</h:panelGrid>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>