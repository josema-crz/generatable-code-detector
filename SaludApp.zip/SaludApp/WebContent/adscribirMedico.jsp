<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Adscribir m�dico</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuAdministrador.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.adscribirMedico}" styleClass="h1" />
				<br>
				<br>
				<h:form id="adscribirMedico">
					<h:panelGrid border="0" columns="2">
						<h:outputText value="#{msg.selecPaciente}"
							styleClass="etiquetaForm" />
						<h:outputText value="#{msg.selecMedico}" styleClass="etiquetaForm" />

						<h:selectOneListbox id="pacientes" required="true"
							value="#{beanAdscribirMedico.paciente}" styleClass="lista"
							immediate="true"
							binding="#{beanAdscribirMedico.listBox}">
							<f:selectItems value="#{beanAdscribirMedico.pacientes}" />
						</h:selectOneListbox>

						<h:selectOneListbox id="medicos" required="true"
							value="#{beanAdscribirMedico.medico}" styleClass="lista">
							<f:selectItems value="#{beanAdscribirMedico.medicos}" />
						</h:selectOneListbox>

						<h:message for="pacientes" styleClass="errorForm" />
						<h:message for="medicos" styleClass="errorForm" />

						<h:commandButton value="#{msg.verMedicosDisponibles}"
							immediate="true" actionListener="#{beanAdscribirMedico.actualizarMedicos}"/>

						<h:panelGroup />
						<h:commandButton value="#{msg.adscribir}" id="adscribir"
							actionListener="#{beanAdscribirMedico.adscribir}"
							binding="#{beanAdscribirMedico.botonAdscribir}" />
						<h:message for="adscribir" styleClass="errorForm" />
					</h:panelGrid>
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>