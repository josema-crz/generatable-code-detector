<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Enviar aviso m�dico</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<%@ include file="cabecera.jsp"%>
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuMedico.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.enviarAviso}" styleClass="h1" />
				<br>
				<br>
				<h:form id="enviarAviso">
					<h:panelGrid border="0" columns="3">
						<h:outputLabel value="#{msg.registroAsunto}" for="asunto"
							styleClass="etiquetaForm" />
						<h:inputText id="asunto" value="#{beanAvisosMedico.asunto}"
							required="true" />
						<h:message for="asunto" styleClass="errorForm" />

						<h:outputLabel value="#{msg.registroTexto}" for="texto"
							styleClass="etiquetaForm" />
						<h:inputTextarea id="texto" value="#{beanAvisosMedico.texto}"
							required="true" styleClass="textArea">
							<f:validateLength maximum="255" />
						</h:inputTextarea>
						<h:message for="texto" styleClass="errorForm" />

						<h:commandButton binding="#{beanAvisosMedico.botonEnviar}"
							value="#{msg.enviarAviso}" id="enviarTexto"
							actionListener="#{beanAvisosMedico.enviarTexto}" />
						<h:message for="enviarTexto" styleClass="errorForm" />
					</h:panelGrid>
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>