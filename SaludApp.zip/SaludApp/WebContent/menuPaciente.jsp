<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />
<link rel="stylesheet" type="text/css" href="css/plantilla.css">

<h:panelGrid border="0" columns="1">
	<h:form>
		<h:commandLink value="#{msg.pedirCita}" action="pedirCita"
			actionListener="#{beanPedirCita.pedirCitaListener}">
		</h:commandLink>
	</h:form>
	<h:outputLink value="cambiarCita.faces">
		<h:outputText value="#{msg.cambiarCita}"></h:outputText>
	</h:outputLink>
	<hr>
	<h:outputLink value="solicitarCambioMedico.faces">
		<h:outputText value="#{msg.solicitarCambioMedico}"></h:outputText>
	</h:outputLink>
	<hr>
	<h:outputLink value="verAvisosMedicos.faces">
		<h:outputText value="#{msg.verAvisos}"></h:outputText>
	</h:outputLink>
	<h:outputLink value="enviarSugerencia.faces">
		<h:outputText value="#{msg.enviarSugerencia}"></h:outputText>
	</h:outputLink>
</h:panelGrid>
