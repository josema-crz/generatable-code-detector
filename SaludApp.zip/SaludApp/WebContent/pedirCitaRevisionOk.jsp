<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@ taglib prefix="tag" tagdir="/WEB-INF/tags"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Pedir cita de revisi�n</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuMedico.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.pedirCitaRevision}" styleClass="h1" />				
				<br>
				<br>
				<h:outputText value="#{msg.pedirCitaRevisionOk}" styleClass="h2" />
				<br>
				<br>
				<h:panelGrid border="0" columns="2">
					<h:outputText value="#{msg.dia}" styleClass="etiquetaForm" />
					<h:outputText value="#{beanPedirCitaRevision.dia}" />
				</h:panelGrid>
				<h:panelGrid border="0" columns="4">
					<h:outputText value="#{msg.horaInicio}" styleClass="etiquetaForm" />
					<h:outputText value="#{beanHoraDuracion.horaInicio}" />
					<h:outputText value=":" />
					<h:outputText value="#{beanHoraDuracion.minutoInicio}" />

					<h:outputText value="#{msg.duracion}" styleClass="etiquetaForm" />
					<h:outputText value="#{beanHoraDuracion.duracion}" >
						<f:converter converterId="conversorDuracion"/>
					</h:outputText>
					<h:panelGroup />
					<h:outputText value="#{msg.minutos}"></h:outputText>
				</h:panelGrid>
				<h:outputText value="#{msg.motivoRevision}"
					styleClass="etiquetaForm" />
				<h:outputText value="#{beanPedirCitaRevision.motivoRevision}"
					styleClass="textArea" />
				<br>
				<br>
				<h:outputText value="#{msg.finalizadaConsulta}" styleClass="h2" />
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>