<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Registrar m�dico</title>
</head>
<body>
	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuAdministrador.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.registrarMedico}" styleClass="h1" />
				<br>
				<br>
				<h:outputText value="#{msg.registroMedicoOk}" styleClass="h2" />
				<br>
				<br>
				<h:outputText value="#{msg.datosPersonales}" styleClass="h2" />
				<br>
				<br>
				<h:panelGrid border="0" columns="2">
					<h:outputText value="#{msg.registroNombre}"
						styleClass="etiquetaForm"></h:outputText>
					<h:outputText id="nombre" value="#{beanRegistroMedico.nombre}" />

					<h:outputText value="#{msg.registroApellidos}"
						styleClass="etiquetaForm"></h:outputText>
					<h:outputText id="apellidos" value="#{beanRegistroMedico.apellidos}"/>

					<h:outputText value="#{msg.registroNumColegiado}"
						styleClass="etiquetaForm"></h:outputText>
					<h:outputText id="numColegiado"
						value="#{beanRegistroMedico.numColegiado}"/>

					<h:outputText value="#{msg.registroIdCM}" styleClass="etiquetaForm"></h:outputText>
					<h:outputText id="centroMedico"
						value="#{beanRegistroMedico.centroMedico}"/>
				</h:panelGrid>
				<br>
				<br>
				<h:outputText value="#{msg.datosAplicacion}" styleClass="h2" />
				<br>
				<br>
				<h:panelGrid border="0" columns="2">
					<h:outputText value="#{msg.registroNombreUsuario}"
						styleClass="etiquetaForm"></h:outputText>
					<h:outputText id="nombreUsuario"
						value="#{beanRegistroMedico.nombreUsuario}" />

					<h:outputText value="#{msg.registroClave}"
						styleClass="etiquetaForm"></h:outputText>
					<h:outputText id="clave" value="#{beanRegistroMedico.clave}"/>
				</h:panelGrid>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>
</body>
</html>