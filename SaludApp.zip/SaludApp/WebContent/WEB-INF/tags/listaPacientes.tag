<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ tag body-content="empty"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ attribute name="pacientes" required="true"
	type="java.util.Collection"%>
	
<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />
	
<table border="1">
	<tr>		
		<td width="45%">
			<p align="center">
				<b><h:outputText value="#{msg.apellidos}" /></b>
			</p>
		</td>
		<td width="15%">
			<p align="center">
				<b><h:outputText value="#{msg.nombre}" /></b>
			</p>
		</td>
		<td width="25%">
			<p align="center">
				<b><h:outputText value="#{msg.nss}" /></b>
			</p>
		</td>
		<td width="15%">
			<p align="center">
				<b><h:outputText value="#{msg.nombreUsuario}" /></b>
			</p>
		</td>
	</tr>
	<c:forEach items="${pacientes}" var="paciente">
		<tr>
			<td width="45%" align="center">${paciente.apellidos}</td>
			<td width="15%" align="center">${paciente.nombre}</td>
			<td width="25%" align="center">${paciente.NSS}</td>
			<td width="15%" align="center">${paciente.nombreUsuario}</td>
		</tr>
	</c:forEach>
</table>