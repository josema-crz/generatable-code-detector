<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ tag body-content="empty"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ attribute name="intervalos1" required="true"
	type="java.util.Collection"%>
<%@ attribute name="intervalos2" required="true"
	type="java.util.Collection"%>

<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

<table border="0">
	<tr class="etiquetasHora">
		<td colspan="12">08:00</td>
		<td colspan="12">09:00</td>
		<td colspan="12">10:00</td>
		<td colspan="12">11:00</td>
		<td colspan="12">12:00</td>
		<td colspan="12">13:00</td>
		<td colspan="6">14:00</td>
	</tr>
	<tr>
		<c:forEach items="${intervalos1}" var="i">
			<td title="${i.title}" class="${i.estilo}" />
		</c:forEach>
	</tr>
	<tr class="separacionIntervalos">
	</tr>
	<tr>
		<c:forEach items="${intervalos2}" var="i">
			<td title="${i.title}" class="${i.estilo}" />
		</c:forEach>
	<tr>
	<tr class="etiquetasHora">
		<td colspan="6" />
		<td colspan="12">15:00</td>
		<td colspan="12">16:00</td>
		<td colspan="12">17:00</td>
		<td colspan="12">18:00</td>
		<td colspan="12">19:00</td>
		<td colspan="12">20:00</td>
	</tr>
	<tr class="separacionIntervalos">
	</tr>
	<tr class="leyenda">
		<td class="intervalonocontemplado" />
		<td colspan="9">${msg.noContemplado}</td>
		<td class="intervaloocupado" />
		<td colspan="9">${msg.ocupado}</td>
		<td class="intervalodisponible" />
		<td colspan="9">${msg.disponible}</td>
	</tr>
</table>