<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Ver historial del paciente</title>
</head>
<body>
	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuMedico.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.pasarConsulta}" styleClass="h1" />
				<br>
				<br>
				<h:outputText value="#{msg.historialPaciente}" styleClass="h2" />
				<br>
				<br>
				<h:outputText value="#{msg.detallesCita}" styleClass="h3" />
				<br>
				<br>
				<h:outputText value="#{msg.sintomas}" styleClass="h3" />
				<h:dataTable value="#{beanDetallesCita.sintomas}" var="sintoma"
					border="1">
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.descripcion}" />
						</f:facet>
						<h:outputText value="#{sintoma.descripcion}" />
					</h:column>
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.valoracionGravedad}" />
						</f:facet>
						<h:outputText value="#{sintoma.valoracionGravedad}" />
					</h:column>
				</h:dataTable>
				<br>
				<br>
				<h:outputText value="#{msg.diagnosticos}" styleClass="h3" />
				<h:dataTable value="#{beanDetallesCita.diagnosticos}"
					var="diagnostico" border="1">
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.enfermedad}" />
						</f:facet>
						<h:outputText value="#{diagnostico.enfermedad}" />
					</h:column>
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.hospitalizacion}" />
						</f:facet>
						<h:selectBooleanCheckbox disabled="true"
							value="#{diagnostico.hospitalizacion}" />
					</h:column>
				</h:dataTable>
				<br>
				<br>
				<h:outputText value="#{msg.tratamientos}" styleClass="h3" />
				<h:dataTable value="#{beanDetallesCita.tratamientos}"
					var="tratamiento" border="1">
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.medicamento}" />
						</f:facet>
						<h:outputText value="#{tratamiento.medicamento}" />
					</h:column>
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.cantidad}" />
						</f:facet>
						<h:outputText value="#{tratamiento.cantidad}" />
					</h:column>
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.dosisDiaria}" />
						</f:facet>
						<h:outputText value="#{tratamiento.dosisDiaria}" />
					</h:column>
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.inicio}" />
						</f:facet>
						<h:outputText value="#{tratamiento.inicio}" />
					</h:column>
					<h:column>
						<f:facet name="header">
							<h:outputText value="#{msg.fin}" />
						</f:facet>
						<h:outputText value="#{tratamiento.fin}" />
					</h:column>
				</h:dataTable>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>