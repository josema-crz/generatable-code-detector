<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<h:panelGrid border="0" columns="5">
	<h:outputText value="#{msg.horaInicio}" styleClass="etiquetaForm" />
	<h:selectOneMenu id="horaInicio" value="#{beanHoraDuracion.horaInicio}">
		<f:selectItems value="#{beanHoraDuracion.horas}" />
	</h:selectOneMenu>
	<h:outputText value=":" />
	<h:selectOneMenu id="minutoInicio"
		value="#{beanHoraDuracion.minutoInicio}">
		<f:selectItems value="#{beanHoraDuracion.minutos}" />
	</h:selectOneMenu>
	<h:outputText value="(HH:mm)" />

	<h:outputText value="#{msg.duracion}" styleClass="etiquetaForm" />
	<h:selectOneMenu id="duracion" value="#{beanHoraDuracion.duracion}">
		<f:converter converterId="conversorDuracion" />
		<f:selectItems value="#{beanHoraDuracion.duraciones}" />
	</h:selectOneMenu>
	<h:panelGroup />
	<h:panelGroup />
	<h:outputText value="#{msg.minutos}"></h:outputText>
</h:panelGrid>