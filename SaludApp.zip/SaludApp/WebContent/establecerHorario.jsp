<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>
<%@ taglib prefix="tag" tagdir="/WEB-INF/tags"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Establecer horario de consulta</title>
</head>
<body>

	<f:view>
		<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />

		<f:subview id="cabecera">
			<jsp:include page="cabecera.jsp" flush="true" />
		</f:subview>

		<h:panelGrid border="1" columns="2" styleClass="menuYcontenido"
			columnClasses="menu,contenido">
			<h:panelGroup>
				<f:subview id="menu">
					<jsp:include page="menuMedico.jsp" flush="true" />
				</f:subview>
			</h:panelGroup>

			<h:panelGroup>
				<h:outputText value="#{msg.establecerHorario}" styleClass="h1" />
				<br>
				<br>
				<tag:intervalos intervalos1="${intervalos1}"
					intervalos2="${intervalos2}" />
				<h:form>
					<br>
					<br>
					<h:panelGrid border="0" columns="2">
						<h:outputText value="#{msg.minimoMinutos}"
							styleClass="etiquetaForm" />
						<h:outputText value="#{beanHorario.minimoMinutos}" />
						<h:outputText value="#{msg.totalMinutos}"
							styleClass="etiquetaForm" />
						<h:outputText value="#{beanHorario.totalMinutos}"
							styleClass="#{beanHorario.totalMinutos >= beanHorario.minimoMinutos ? 'totalMinutosOk' : 'totalMinutosFallo' }" />
					</h:panelGrid>
					<br>
					<jsp:include page="horaInicioFin.jsp" flush="true" />
					<br>
					<br>
					<h:panelGrid border="0" columns="3">
						<h:commandButton value="#{msg.a�adirIntervalo}" id="addIntervalo"
							binding="#{beanHorario.botonAdd}"
							actionListener="#{beanHorario.addIntervalo}" />
						<h:commandButton value="#{msg.eliminarIntervalo}"
							id="removeIntervalo" binding="#{beanHorario.botonRemove}"
							actionListener="#{beanHorario.removeIntervalo}" />
						<h:commandButton value="#{msg.eliminarIntervalos}"
							id="removeIntervalos" binding="#{beanHorario.botonRemoveTodos}"
							actionListener="#{beanHorario.removeIntervalos}" />
					</h:panelGrid>
					<h:message for="addIntervalo" styleClass="errorForm" />
					<h:message for="removeIntervalo" styleClass="errorForm" />
					<h:message for="removeIntervalos" styleClass="errorForm" />
				</h:form>
			</h:panelGroup>
		</h:panelGrid>
	</f:view>

</body>
</html>


