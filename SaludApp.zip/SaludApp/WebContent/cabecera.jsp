<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%><%@taglib
	uri="http://java.sun.com/jsf/core" prefix="f"%>

<f:loadBundle basename="saludapp.resource.saludapp" var="msg" />
<link rel="stylesheet" type="text/css" href="css/plantilla.css">
<h:panelGrid border="1" columns="1" styleClass="cabecera">
	<h:panelGrid border="0" columns="3" styleClass="cabecera"
		columnClasses="cabeceraLogo,cabeceraTitulo,cabeceraSalir">
		<h:panelGroup>
			<h:graphicImage value="imgs/logo.jpg" title="�ndice"
				styleClass="imagenLogo" />
		</h:panelGroup>

		<h:panelGroup>
			<h:outputText value="SaludApp" styleClass="titulo"></h:outputText>
		</h:panelGroup>

		<h:panelGroup>
			<form method="post" action="ServletLogout">
				<input type="submit" value="Salir" >				
			</form>
		</h:panelGroup>
	</h:panelGrid>
</h:panelGrid>
