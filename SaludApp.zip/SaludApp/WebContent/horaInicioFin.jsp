<%@ taglib uri="http://java.sun.com/jsf/html" prefix="h"%>
<%@ taglib uri="http://java.sun.com/jsf/core" prefix="f"%>

<h:panelGrid border="0" columns="5">
	<h:outputText value="#{msg.horaInicio}" styleClass="etiquetaForm" />
	<h:selectOneMenu id="horaInicio"
		value="#{beanHoraInicioFin.horaInicio}">
		<f:selectItems value="#{beanHoraInicioFin.horas}" />
	</h:selectOneMenu>
	<h:outputText value=":" />
	<h:selectOneMenu id="minutoInicio"
		value="#{beanHoraInicioFin.minutoInicio}">
		<f:selectItems value="#{beanHoraInicioFin.minutos}" />
	</h:selectOneMenu>
	<h:outputText value="(HH:mm)" />

	<h:outputText value="#{msg.horaFin}" styleClass="etiquetaForm" />
	<h:selectOneMenu id="horaFin" value="#{beanHoraInicioFin.horaFin}">
		<f:selectItems value="#{beanHoraInicioFin.horas}" />
	</h:selectOneMenu>
	<h:outputText value=":" />
	<h:selectOneMenu id="minutoFin" value="#{beanHoraInicioFin.minutoFin}">
		<f:selectItems value="#{beanHoraInicioFin.minutos}" />
	</h:selectOneMenu>
	<h:outputText value="(HH:mm)" />
</h:panelGrid>