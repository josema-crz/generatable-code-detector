package similarity.tests;

public class Registry {

	public static void addPlace(Object name) {
		// TODO Auto-generated method stub

	}

	public static void addPerson(String name) {
		// TODO Auto-generated method stub

	}

}
