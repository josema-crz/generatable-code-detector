package similarity.tests;

public class Logger {

	public static void log(String string) {
		// TODO Auto-generated method stub

	}

}
