
package similarity.tests;

public class Test {
	public boolean test(int a, int b) {
		return false;
	}
}
