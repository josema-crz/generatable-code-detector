package similarity.tests;

public class Appointment {
}
