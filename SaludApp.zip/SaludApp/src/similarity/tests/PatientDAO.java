package similarity.tests;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import saludapp.dao.DAOException;

public class PatientDAO {
	private SessionFactory sessionFactory;

	public Patient registerPatient(String name, String user, String pass, String phoneNumber, String address,
			String email, long idHospital) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Patient patient;
		try {
			tx = session.beginTransaction();

			Hospital hospital = (Hospital) session.get(Hospital.class, idHospital);
			patient = new Patient(name, user, pass);
			patient.setPhoneNumber(phoneNumber);
			patient.setAddress(address);
			patient.setEmail(email);
			patient.setHospital(hospital);

			if (Validator.isValidPatient(patient)) {
				Registry.addPerson(patient.getName());
			}

			session.save(patient);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return patient;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
}
