package similarity.tests;

import java.util.List;

public class Patient {
	private String name, user, pass, phoneNumber, address, email;
	private List<Appointment> appointments;
	private Hospital hospital;

	public Patient(String name, String user, String pass) {
		// TODO Auto-generated constructor stub
	}

	public List<Appointment> getAppointments() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setPhoneNumber(String phoneNumber) {
		// TODO Auto-generated method stub

	}

	public void setAddress(String address) {
		// TODO Auto-generated method stub

	}

	public void setEmail(String email) {
		// TODO Auto-generated method stub

	}

	public void setHospital(Hospital hospital) {
		// TODO Auto-generated method stub

	}

}
