package similarity.tests;

public class Hospital {
	private String name, address, phoneNumber;	

	public Hospital(String name) {
		// TODO Auto-generated constructor stub
	}

	public void setAddress(String address) {
		// TODO Auto-generated method stub

	}

	public void setPhoneNumber(String phoneNumber) {
		// TODO Auto-generated method stub

	}

	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
