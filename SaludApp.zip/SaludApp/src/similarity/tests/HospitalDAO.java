package similarity.tests;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import saludapp.dao.DAOException;

public class HospitalDAO {
	private SessionFactory sessionFactory;

	public Hospital registerHospital(String name, String address, String phoneNumber) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Hospital hospital;
		try {
			tx = session.beginTransaction();

			hospital = new Hospital(name);
			hospital.setAddress(address);
			hospital.setPhoneNumber(phoneNumber);

			if (Validator.isValidHospital(hospital)) {
				Registry.addPlace(hospital.getName());
			}

			session.save(hospital);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return hospital;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
}