package similarity.tests;

public class Validator {

	public static boolean isValidHospital(Hospital hospital) {
		// TODO Auto-generated method stub
		return false;
	}

	public static boolean isValidPatient(Patient patient) {
		// TODO Auto-generated method stub
		return false;
	}

}
