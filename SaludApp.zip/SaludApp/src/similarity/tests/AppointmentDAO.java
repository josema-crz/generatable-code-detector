package similarity.tests;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import saludapp.dao.DAOException;

public class AppointmentDAO {
	private SessionFactory sessionFactory;

	public List<Appointment> getAppointments(Long idPatient) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<Appointment> appointments;

		try {
			tx = session.beginTransaction();

			Patient patient = (Patient) session.get(Patient.class, idPatient);
			appointments = patient.getAppointments();

			Logger.log("Appointments of patient " + patient.getName() + " have been recovered");

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return appointments;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
}