package saludapp.dao;

import java.util.List;

import javax.sql.DataSource;

import saludapp.modelo.CentroMedico;

public class MySQLJDBCCentroMedicoDAO implements CentroMedicoDAO {
	private final DataSource ds;

	public MySQLJDBCCentroMedicoDAO(DataSource ds) {
		this.ds = ds;
	}

	@Override
	public CentroMedico registrarCentroMedico(String nombre, String direccion)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CentroMedico> getCentrosMedicos() throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

}
