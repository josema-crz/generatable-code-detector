package saludapp.dao;

import java.util.List;

import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.modelo.*;

public interface UsuarioDAO {

	public Paciente registrarPaciente(String nombre, String apellidos,
			String usuario, String clave, String nSS, String numTarjeta,
			String telefono, String movil, String direccion, String mail,
			FormaNotificacion formaNotificacion, long idCentroMedico)
			throws DAOException;

	public Medico registrarMedico(String nombre, String apellidos,
			String usuario, String clave, String numColegiado,
			long idCentroMedico) throws DAOException;

	public Usuario login(String nombreUsuario, String clave)
			throws DAOException;

	public Administrador registrarAdministrador(String nombreUsuario,
			String clave) throws DAOException;

	public Usuario getUsuario(String usuario) throws DAOException;

	public List<Medico> getMedicosDisponibles(long idPaciente)
			throws DAOException;

	public List<Cita> setRetrasoConsulta(long idMedico, LocalDate fecha,
			LocalTime hora, Duration duracion) throws DAOException;

	public int adscribirPaciente(Long idMedico, Long idPaciente)
			throws DAOException;	

	public List<Medico> getMedicos() throws DAOException;

	public List<Paciente> getPacientes() throws DAOException;

	public List<Cita> getCitasDia(long idMedico, LocalDate fecha)
			throws DAOException;

	public int getTotalMinutosHorarioConsulta(long idMedico)
			throws DAOException;

	public List<EstadoIntervalo> getEstadosIntervalos(long idMedico,
			List<IntervaloHorario> intervalos, LocalDate dia) throws DAOException;

	public IntervaloHorario addIntervaloHorarioConsulta(long idMedico,
			LocalTime horaInicio, LocalTime horaFin) throws DAOException;

	public IntervaloHorario removeIntervaloHorarioConsulta(long idMedico,
			LocalTime horaInicio, LocalTime horaFin) throws DAOException;

	public boolean removeIntervalosHorarioConsulta(long idMedico) throws DAOException;

	public Medico getMedicoAdscrito(long idPaciente) throws DAOException;	
}
