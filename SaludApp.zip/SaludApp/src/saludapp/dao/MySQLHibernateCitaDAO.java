package saludapp.dao;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.modelo.Cita;
import saludapp.modelo.CitaUrgencia;
import saludapp.modelo.Diagnostico;
import saludapp.modelo.IntervaloHorario;
import saludapp.modelo.Medico;
import saludapp.modelo.Paciente;
import saludapp.modelo.Revision;
import saludapp.modelo.Sintoma;
import saludapp.modelo.Tratamiento;
import saludapp.modelo.ValoracionGravedad;

public class MySQLHibernateCitaDAO implements CitaDAO {
	private final SessionFactory sessionFactory;

	public MySQLHibernateCitaDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Cita registrarCita(LocalDate fecha, LocalTime hora,
			Duration duracion, long idPaciente) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Cita cita;

		try {
			tx = session.beginTransaction();

			Paciente p = (Paciente) session.get(Paciente.class, idPaciente);

			cita = new Cita(fecha, hora, duracion, p, p.getAdscrito());

			session.save(cita);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return cita;
	}

	@Override
	public Cita modificarCita(long idCita, long idMedico, LocalDate fecha,
			LocalTime hora, Duration duracion) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Cita cita;

		try {
			tx = session.beginTransaction();

			cita = (Cita) session.get(Cita.class, idCita);

			// Cambio de m�dico
			if (idMedico != cita.getMedico().getId()) {
				cita.getMedico().removeCita(cita);

				Medico m = (Medico) session.get(Medico.class, idMedico);
				cita.setMedico(m);
				m.addCita(cita);
			}
			cita.setFecha(fecha);
			cita.setIntervalo(new IntervaloHorario(hora, duracion));

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return cita;
	}

	@Override
	public Sintoma registrarSintoma(long idCita, String descripcion,
			ValoracionGravedad valoracionGravedad) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Sintoma sintoma;

		try {
			tx = session.beginTransaction();

			Cita cita = (Cita) session.get(Cita.class, idCita);
			sintoma = new Sintoma(descripcion, valoracionGravedad);
			session.save(sintoma);
			cita.addSintoma(sintoma);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return sintoma;
	}

	@Override
	public Diagnostico registrarDiagnostico(long idCita, String enfermedad,
			boolean hospitalizacion) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Diagnostico diagnostico;

		try {
			tx = session.beginTransaction();

			Cita cita = (Cita) session.get(Cita.class, idCita);
			diagnostico = new Diagnostico(enfermedad, hospitalizacion);
			session.save(diagnostico);
			cita.addDiagnostico(diagnostico);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return diagnostico;
	}

	@Override
	public Tratamiento registrarTratamiento(long idCita, String medicamento,
			double cantidad, double dosisDiaria, LocalDate inicio, LocalDate fin)
			throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Tratamiento tratamiento;

		try {
			tx = session.beginTransaction();

			Cita cita = (Cita) session.get(Cita.class, idCita);
			tratamiento = new Tratamiento(medicamento, cantidad, dosisDiaria,
					inicio, fin);
			session.save(tratamiento);
			cita.addTratamiento(tratamiento);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return tratamiento;
	}

	@Override
	public Cita registrarCitaUrgencia(LocalDate fecha, LocalTime hora,
			Duration duracion, long idPaciente, String motivo)
			throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		CitaUrgencia cita;

		try {
			tx = session.beginTransaction();

			Paciente p = (Paciente) session.get(Paciente.class, idPaciente);

			cita = new CitaUrgencia(fecha, hora, duracion, p, p.getAdscrito(),
					motivo);

			session.save(cita);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return cita;
	}

	@Override
	public Cita registrarRevision(long idCitaRevisada, LocalDate fecha,
			LocalTime hora, Duration duracion, String motivo)
			throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Revision cita;

		try {
			tx = session.beginTransaction();

			Cita c = (Cita) session.get(Cita.class, idCitaRevisada);

			cita = new Revision(fecha, hora, duracion, c.getPaciente(), c.getMedico(),
					motivo, c);

			session.save(cita);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return cita;
	}

	@Override
	public Set<Sintoma> getSintomas(Long cita) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Set<Sintoma> sintomas = new LinkedHashSet<Sintoma>();

		try {
			tx = session.beginTransaction();

			Cita c = (Cita) session.get(Cita.class, cita);

			sintomas = c.getSintomas();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return sintomas;
	}

	@Override
	public Set<Diagnostico> getDiagnosticos(Long cita) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Set<Diagnostico> diagnosticos = new LinkedHashSet<Diagnostico>();

		try {
			tx = session.beginTransaction();

			Cita c = (Cita) session.get(Cita.class, cita);

			diagnosticos = c.getDiagnosticos();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return diagnosticos;
	}

	@Override
	public Set<Tratamiento> getTratamientos(Long cita) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Set<Tratamiento> tratamientos = new LinkedHashSet<Tratamiento>();

		try {
			tx = session.beginTransaction();

			Cita c = (Cita) session.get(Cita.class, cita);

			tratamientos = c.getTratamientos();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return tratamientos;
	}
	
	@Override
	public List<Cita> getHistorialPaciente(long idPaciente) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<Cita> historial;

		try {
			tx = session.beginTransaction();

			Query q = session
					.createQuery("from Cita c where c.paciente.id = :idPaciente AND c.fecha < :fechaHoy");

			q.setParameter("fechaHoy",
					new LocalDate(System.currentTimeMillis()));
			q.setLong("idPaciente", idPaciente);
			historial = q.list();

			tx.commit();

		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return historial;
	}

	@Override
	public List<Cita> getCitasActualesPaciente(long idPaciente) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<Cita> citasActuales = new LinkedList<Cita>();

		try {
			tx = session.beginTransaction();

			Query q = session
					.createQuery("from Cita c where c.paciente.id = :idPaciente AND c.fecha >= :fechaHoy " +
							"AND c.intervalo.horaFin >= :horaActual");

			q.setParameter("fechaHoy",
					new LocalDate(System.currentTimeMillis()));
			q.setParameter("horaActual", new LocalTime(System.currentTimeMillis()));
			q.setLong("idPaciente", idPaciente);
			citasActuales = q.list();
			
			tx.commit();

		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return citasActuales;
	}
}
