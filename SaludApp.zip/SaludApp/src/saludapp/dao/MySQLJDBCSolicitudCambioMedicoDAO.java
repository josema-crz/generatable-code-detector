package saludapp.dao;

import java.util.List;

import javax.sql.DataSource;

import saludapp.modelo.SolicitudCambioMedico;

public class MySQLJDBCSolicitudCambioMedicoDAO implements
		SolicitudCambioMedicoDAO {
	private final DataSource ds;

	public MySQLJDBCSolicitudCambioMedicoDAO(DataSource ds) {
		this.ds = ds;
	}

	@Override
	public SolicitudCambioMedico registrarSolicitudCambioMedico(
			long idPaciente, long idNuevoMedico, String motivo)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SolicitudCambioMedico resolverSolicitudCambioMedico(
			long idSolicitud, boolean aceptada) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SolicitudCambioMedico> getSolicitudesCambioMedicoPendientes()
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

}
