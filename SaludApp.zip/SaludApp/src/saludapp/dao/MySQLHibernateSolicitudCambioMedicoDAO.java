package saludapp.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import saludapp.modelo.Medico;
import saludapp.modelo.Paciente;
import saludapp.modelo.SolicitudCambioMedico;
import saludapp.modelo.Usuario;


public class MySQLHibernateSolicitudCambioMedicoDAO implements
		SolicitudCambioMedicoDAO {
	private SessionFactory sessionFactory;	
	
	public MySQLHibernateSolicitudCambioMedicoDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public List<SolicitudCambioMedico> getSolicitudesCambioMedicoPendientes() throws DAOException {
		Session session = sessionFactory.openSession(); 
		Transaction tx = null;
		List<SolicitudCambioMedico> resultados;

		try {
			tx = session.beginTransaction(); 

			Query q = session.createQuery("from SolicitudCambioMedico s where s.resuelta = :false");
			q.setBoolean("false", false);
			resultados = q.list();	

			tx.commit(); 
		}catch (Exception e) {
			if (tx!=null) tx.rollback();
			throw new DAOException(e.getMessage());
		}
		finally {
			session.close();
		}		
		return resultados;		
	}

	@Override
	public SolicitudCambioMedico registrarSolicitudCambioMedico(long idPaciente, long idNuevoMedico, String motivo)
			 throws DAOException {
		Session session = sessionFactory.openSession(); 
		Transaction tx = null;
		SolicitudCambioMedico solicitud = null;

		try {
			tx = session.beginTransaction(); 
			
			Paciente paciente = (Paciente) session.get(Paciente.class, idPaciente);
			Medico nuevoMedico = (Medico) session.get(Medico.class, idNuevoMedico);

			solicitud = new SolicitudCambioMedico(paciente, nuevoMedico, motivo);

			session.save(solicitud); 

			tx.commit(); 
		}catch (Exception e) {
			if (tx!=null) tx.rollback();
			throw new DAOException(e.getMessage());
		}
		finally {
			session.close();
		}			
		return solicitud;
	}

	@Override
	public SolicitudCambioMedico resolverSolicitudCambioMedico(
			long idSolicitud, boolean aceptada) throws DAOException {
		Session session = sessionFactory.openSession(); 
		Transaction tx = null;
		SolicitudCambioMedico solicitud;

		try {
			tx = session.beginTransaction(); 

			solicitud = (SolicitudCambioMedico) session.get(SolicitudCambioMedico.class, idSolicitud);
			solicitud.resolver(aceptada);
			
			tx.commit(); 
		}catch (Exception e) {
			if (tx!=null) tx.rollback();
			throw new DAOException(e.getMessage());
		}
		finally {
			session.close();
		}			
		return solicitud;
	}
	
}
