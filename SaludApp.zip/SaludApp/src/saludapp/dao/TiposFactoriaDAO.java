package saludapp.dao;

public enum TiposFactoriaDAO {
	MYSQL_HIBERNATE, MYSQL_JDBC;
}
