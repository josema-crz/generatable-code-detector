package saludapp.dao;

import javax.sql.DataSource;

import saludapp.pool.ConnectionPool;


public class MySQLJDBCFactoriaDAO extends FactoriaDAO {
	DataSource ds;	
	
	public MySQLJDBCFactoriaDAO () throws DAOException, ClassNotFoundException, java.sql.SQLException {
		ds = ConnectionPool.getInstance();
	}

	@Override
	public UsuarioDAO getUsuarioDAO() {
		return new MySQLJDBCUsuarioDAO(ds);
	}

	@Override
	public CitaDAO getCitaDAO() {
		return new MySQLJDBCCitaDAO(ds);
	}

	@Override
	public CentroMedicoDAO getCentroMedicoDAO() {
		return new MySQLJDBCCentroMedicoDAO(ds);
	}

	@Override
	public SolicitudCambioMedicoDAO getSolicitudCambioMedicoDAO() {
		return new MySQLJDBCSolicitudCambioMedicoDAO(ds);
	}

}
