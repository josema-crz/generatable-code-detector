package saludapp.dao;

import java.util.List;

import saludapp.modelo.SolicitudCambioMedico;


public interface SolicitudCambioMedicoDAO {
	public SolicitudCambioMedico registrarSolicitudCambioMedico(long idPaciente, long idNuevoMedico, String motivo)
			 throws DAOException;
	
	public SolicitudCambioMedico resolverSolicitudCambioMedico(long idSolicitud, boolean aceptada) throws DAOException;
	
	public List<SolicitudCambioMedico> getSolicitudesCambioMedicoPendientes() throws DAOException;
}
