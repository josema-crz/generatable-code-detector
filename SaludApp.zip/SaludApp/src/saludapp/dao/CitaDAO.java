package saludapp.dao;

import java.util.List;
import java.util.Set;

import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.modelo.Cita;
import saludapp.modelo.Diagnostico;
import saludapp.modelo.Sintoma;
import saludapp.modelo.Tratamiento;
import saludapp.modelo.ValoracionGravedad;

public interface CitaDAO {
	public Cita registrarCita(LocalDate fecha, LocalTime hora,
			Duration duracion, long idPaciente) throws DAOException;

	public Cita registrarCitaUrgencia(LocalDate fecha, LocalTime hora,
			Duration duracion, long idPaciente, String motivo)
			throws DAOException;

	public Cita registrarRevision(long idCitaRevisada, LocalDate fecha,
			LocalTime hora, Duration duracion, String motivo)
			throws DAOException;

	public Cita modificarCita(long idCita, long idMedico, LocalDate fecha,
			LocalTime hora, Duration duracion) throws DAOException;

	public Sintoma registrarSintoma(long idCita, String descripcion,
			ValoracionGravedad valoracionGravedad) throws DAOException;

	public Diagnostico registrarDiagnostico(long idCita, String enfermedad,
			boolean hospitalizacion) throws DAOException;

	public Tratamiento registrarTratamiento(long idCita, String medicamento,
			double cantidad, double dosisDiaria, LocalDate inicio, LocalDate fin)
			throws DAOException;

	public Set<Sintoma> getSintomas(Long cita) throws DAOException;

	public Set<Diagnostico> getDiagnosticos(Long cita) throws DAOException;

	public Set<Tratamiento> getTratamientos(Long cita) throws DAOException;
	
	public List<Cita> getHistorialPaciente(long idPaciente) throws DAOException;
	
	public List<Cita> getCitasActualesPaciente(long idPaciente) throws DAOException;
}
