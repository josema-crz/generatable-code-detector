package saludapp.dao;

import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.modelo.Cita;
import saludapp.modelo.Diagnostico;
import saludapp.modelo.Sintoma;
import saludapp.modelo.Tratamiento;
import saludapp.modelo.ValoracionGravedad;

public class MySQLJDBCCitaDAO implements CitaDAO {
	private final DataSource ds;

	public MySQLJDBCCitaDAO(DataSource ds) {
		this.ds = ds;
	}

	@Override
	public Cita registrarCita(LocalDate fecha, LocalTime hora,
			Duration duracion, long idPaciente) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cita registrarCitaUrgencia(LocalDate fecha, LocalTime hora,
			Duration duracion, long idPaciente, String motivo)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cita registrarRevision(long idCitaRevisada, LocalDate fecha,
			LocalTime hora, Duration duracion, String motivo)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cita modificarCita(long idCita, long idMedico, LocalDate fecha,
			LocalTime hora, Duration duracion) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sintoma registrarSintoma(long idCita, String descripcion,
			ValoracionGravedad valoracionGravedad) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Diagnostico registrarDiagnostico(long idCita, String enfermedad,
			boolean hospitalizacion) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Tratamiento registrarTratamiento(long idCita, String medicamento,
			double cantidad, double dosisDiaria, LocalDate inicio, LocalDate fin)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Sintoma> getSintomas(Long cita) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Diagnostico> getDiagnosticos(Long cita) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Tratamiento> getTratamientos(Long cita) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cita> getHistorialPaciente(long idPaciente) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cita> getCitasActualesPaciente(long idPaciente)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

}
