package saludapp.dao;

import java.util.List;

import saludapp.modelo.CentroMedico;

public interface CentroMedicoDAO {
	public CentroMedico registrarCentroMedico(String nombre, String direccion) throws DAOException;
	
	public List<CentroMedico> getCentrosMedicos() throws DAOException;
}
