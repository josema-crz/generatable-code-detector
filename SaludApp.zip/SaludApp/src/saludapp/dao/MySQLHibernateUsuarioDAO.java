package saludapp.dao;

import java.util.LinkedList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.jms.AvisosImportantesMedicoX;
import saludapp.modelo.Administrador;
import saludapp.modelo.CentroMedico;
import saludapp.modelo.Cita;
import saludapp.modelo.EstadoIntervalo;
import saludapp.modelo.FormaNotificacion;
import saludapp.modelo.HorarioConsulta;
import saludapp.modelo.IntervaloHorario;
import saludapp.modelo.Medico;
import saludapp.modelo.Paciente;
import saludapp.modelo.Usuario;

public class MySQLHibernateUsuarioDAO implements UsuarioDAO {
	private final SessionFactory sessionFactory;

	public MySQLHibernateUsuarioDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Paciente registrarPaciente(String nombre, String apellidos,
			String usuario, String clave, String nSS, String numTarjeta,
			String telefono, String movil, String direccion, String mail,
			FormaNotificacion formaNotificacion, long idCentroMedico)
			throws DAOException {

		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Paciente paciente;
		try {
			tx = session.beginTransaction();

			CentroMedico centroMedico = (CentroMedico) session.get(
					CentroMedico.class, idCentroMedico);

			paciente = new Paciente(nombre, apellidos, usuario, clave, nSS,
					numTarjeta, telefono, movil, direccion, mail,
					formaNotificacion, centroMedico);

			session.save(paciente);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return paciente;
	}

	@Override
	public Medico registrarMedico(String nombre, String apellidos,
			String usuario, String clave, String numColegiado,
			long idCentroMedico) throws DAOException {

		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Medico medico;
		try {
			tx = session.beginTransaction();

			CentroMedico centroMedico = (CentroMedico) session.get(
					CentroMedico.class, idCentroMedico);

			medico = new Medico(nombre, apellidos, usuario, clave,
					numColegiado, centroMedico);

			session.save(medico);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return medico;
	}

	@Override
	public Usuario getUsuario(String usuario) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Usuario resultado;

		try {
			tx = session.beginTransaction();

			Query q = session
					.createQuery("from Usuario u where u.nombreUsuario = :fname");
			q.setString("fname", usuario);
			resultado = (Usuario) q.uniqueResult();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return resultado;
	}

	@Override
	public List<Medico> getMedicosDisponibles(long idPaciente)
			throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<Medico> resultados;

		try {
			tx = session.beginTransaction();

			Paciente p = (Paciente) session.get(Paciente.class, idPaciente);

			Query q = session
					.createQuery("from Medico m where m.cupoPacientes > 0 AND m.id != :idExcluido AND m.centroMedico.id = :idCentroMedico");

			long idExcluido;
			if (p.getAdscrito() == null)
				idExcluido = -1; // No tiene m�dico, no excluimos ninguno
			else
				idExcluido = p.getAdscrito().getId();

			q.setDouble("idExcluido", idExcluido);
			q.setDouble("idCentroMedico", p.getCentroMedico().getId());
			resultados = q.list();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return resultados;
	}

	@Override
	public List<Cita> setRetrasoConsulta(long idMedico, LocalDate fecha,
			LocalTime hora, Duration duracion) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<Cita> citasAfectadas = null;

		try {
			tx = session.beginTransaction();

			// Obtenemos el m�dico
			Medico m = (Medico) session.get(Medico.class, idMedico);
			// Obtenemos las citas del m�dico ese d�a
			List<Cita> citasDia = getCitasDia(idMedico, fecha);

			// Establecemos el retraso en esas citas (obtenemos las afectadas
			// por dicho retraso)
			citasAfectadas = m.setRetraso(citasDia, hora, duracion);

			// Sincronizamos con la bbdd pues las obtuvimos en otra sesi�n y
			// est�n detached
			for (Cita cita : citasAfectadas)
				session.update(cita);

			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return citasAfectadas;
	}

	@Override
	public IntervaloHorario addIntervaloHorarioConsulta(long idMedico,
			LocalTime horaInicio, LocalTime horaFin) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		IntervaloHorario intervalo = null;

		try {
			tx = session.beginTransaction();

			HorarioConsulta horario = (HorarioConsulta) session.get(
					HorarioConsulta.class, idMedico);

			intervalo = new IntervaloHorario(horaInicio, horaFin);

			if (!horario.addIntervalo(intervalo))
				return null;

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return intervalo;
	}

	@Override
	public IntervaloHorario removeIntervaloHorarioConsulta(long idMedico,
			LocalTime horaInicio, LocalTime horaFin) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		IntervaloHorario intervalo = null;

		try {
			tx = session.beginTransaction();

			HorarioConsulta horario = (HorarioConsulta) session.get(
					HorarioConsulta.class, idMedico);

			intervalo = new IntervaloHorario(horaInicio, horaFin);

			if (!horario.removeIntervalo(intervalo))
				return null;

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return intervalo;
	}

	@Override
	public boolean removeIntervalosHorarioConsulta(long idMedico)
			throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		boolean resultado = false;

		try {
			tx = session.beginTransaction();

			HorarioConsulta horario = (HorarioConsulta) session.get(
					HorarioConsulta.class, idMedico);

			horario.removeIntervalos();

			resultado = true;

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return resultado;
	}

	@Override
	public int getTotalMinutosHorarioConsulta(long idMedico)
			throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		int totalMinutos;

		try {
			tx = session.beginTransaction();

			HorarioConsulta horario = (HorarioConsulta) session.get(
					HorarioConsulta.class, idMedico);
			totalMinutos = horario.getTotalMinutos();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return totalMinutos;
	}

	/**
	 * @return 0 si la adscripci�n ha sido exitosa -1 si el m�dico no tiene cupo
	 */
	@Override
	public int adscribirPaciente(Long idMedico, Long idPaciente)
			throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		int retorno;

		try {
			tx = session.beginTransaction();

			Medico medico = (Medico) session.get(Medico.class, idMedico);
			Paciente paciente = (Paciente) session.get(Paciente.class,
					idPaciente);

			Medico antiguo = paciente.getAdscrito();

			if (antiguo != null)
				antiguo.desvincularPaciente(paciente);

			retorno = medico.adscribirPaciente(paciente);

			
			if (retorno == 0) {
				/*
				 * Creamos la subscripci�n a los avisos del nuevo m�dico. Si ya
				 * exist�a una subscripci�n asociada a este paciente, se elimina
				 * autom�ticamente
				 */
				AvisosImportantesMedicoX.getUnicaInstancia().registrarApartado(
						idPaciente.toString(), idMedico.toString());

				// Cerramos la subscripci�n porque no queremos estar recibiendo
				// avisos de los pacientes estando el admin logueado
				AvisosImportantesMedicoX.getUnicaInstancia().close();
			}

			tx.commit();

		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return retorno;
	}

	@Override
	public List<Medico> getMedicos() throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<Medico> medicos;

		try {
			tx = session.beginTransaction();

			Query q = session.createQuery("from Medico");
			medicos = q.list();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return medicos;
	}

	@Override
	public List<Paciente> getPacientes() throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<Paciente> pacientes;

		try {
			tx = session.beginTransaction();

			Query q = session.createQuery("from Paciente");
			pacientes = q.list();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return pacientes;
	}

	@Override
	public List<Cita> getCitasDia(long idMedico, LocalDate fecha)
			throws DAOException {
		List<Cita> citas = new LinkedList<Cita>();
		Session session = sessionFactory.openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();

			Query q = session
					.createQuery("from Cita c where c.medico.id = :idMedico AND c.fecha = :fecha");
			q.setDouble("idMedico", idMedico);
			q.setParameter("fecha", fecha);
			citas = q.list();

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return citas;
	}

	@Override
	public Usuario login(String nombreUsuario, String clave)
			throws DAOException {

		// Buscamos el usuario en bbdd
		// Devolvemos null si no existe o la contrase�a suministrada no es
		// correcta
		Usuario usuario = getUsuario(nombreUsuario);

		if (usuario != null)
			if (!usuario.getClave().equals(clave))
				usuario = null;

		return usuario;
	}

	@Override
	public Administrador registrarAdministrador(String nombreUsuario,
			String clave) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Administrador admin = null;

		try {
			tx = session.beginTransaction();

			// Buscamos el administrador en bbdd
			// En la aplicaci�n actualmente s�lo hay un administrador. Si la
			// aplicaci�n se extendiera a�adiendo m�s,
			// habr�a que cambiar la consulta por una que buscara en funci�n del
			// nombre de usuario.
			Query q = session.createQuery("from Administrador");
			admin = (Administrador) q.uniqueResult();

			// Si no existe, lo creamos y registramos en bbdd
			if (admin == null) {
				admin = new Administrador(nombreUsuario, clave);
				session.save(admin);
			}

			tx.commit();

		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return admin;
	}

	@Override
	public List<EstadoIntervalo> getEstadosIntervalos(long idMedico,
			List<IntervaloHorario> intervalos, LocalDate dia)
			throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		List<EstadoIntervalo> estados = new LinkedList<EstadoIntervalo>();

		try {
			tx = session.beginTransaction();

			// Obtenemos el m�dico
			Medico m = (Medico) session.get(Medico.class, idMedico);

			// Obtenemos las citas del m�dico ese d�a
			List<Cita> citasDia = null;
			// Si dia vale pasamos null como lista
			if (dia != null)
				citasDia = getCitasDia(idMedico, dia);

			// Obtenemos el estado del intervalo en cuesti�n
			estados = m.getEstadosIntervalos(intervalos, citasDia);

			tx.commit();

		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return estados;
	}

	@Override
	public Medico getMedicoAdscrito(long idPaciente) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Medico medico = null;

		try {
			tx = session.beginTransaction();

			// Obtenemos el paciente
			Paciente p = (Paciente) session.get(Paciente.class, idPaciente);

			// Obtenemos su m�dico adscrito
			medico = p.getAdscrito();

			tx.commit();

		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		} finally {
			session.close();
		}
		return medico;
	}

}
