package saludapp.dao;

//Define una factoria abstracta que devuelve todos los DAO de la aplicacion

public abstract class FactoriaDAO {
	private static FactoriaDAO unicaInstancia;
	public static FactoriaDAO getFactoriaDAO(){
		return unicaInstancia;
	}

	public static FactoriaDAO getFactoriaDAO (TiposFactoriaDAO tipo) throws DAOException {
		// Tipos de factor�a disponibles
		switch(tipo) { 
		case MYSQL_HIBERNATE: {
			try { 
				unicaInstancia = new MySQLHibernateFactoriaDAO();
				return unicaInstancia;
			} catch (Exception e) {
				throw new DAOException(e.getMessage());
			} 
		}
		/*case MYSQL_JDBC: {
			try { 
				unicaInstancia = new MySQLJDBCFactoriaDAO();
				return unicaInstancia;
			} catch (Exception e) {
				throw new DAOException(e.getMessage());
			} 
		}*/
		default: return null;
		}
	}

	protected FactoriaDAO (){}


	// Metodos factoria
	public abstract UsuarioDAO getUsuarioDAO();
	public abstract CitaDAO getCitaDAO();
	public abstract CentroMedicoDAO getCentroMedicoDAO();
	public abstract SolicitudCambioMedicoDAO getSolicitudCambioMedicoDAO();
}
