package saludapp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;

import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.modelo.Administrador;
import saludapp.modelo.Cita;
import saludapp.modelo.EstadoIntervalo;
import saludapp.modelo.FormaNotificacion;
import saludapp.modelo.IntervaloHorario;
import saludapp.modelo.Medico;
import saludapp.modelo.Paciente;
import saludapp.modelo.Usuario;

public class MySQLJDBCUsuarioDAO implements UsuarioDAO {
	private static int ID_USUARIO = 0;

	private final DataSource ds;

	public MySQLJDBCUsuarioDAO(DataSource ds) {
		this.ds = ds;
	}

	private int getId() {
		return ID_USUARIO++;
	}

	@Override
	public Paciente registrarPaciente(String nombre, String apellidos,
			String usuario, String clave, String nSS, String numTarjeta,
			String telefono, String movil, String direccion, String mail,
			FormaNotificacion formaNotificacion, long idCentroMedico)
			throws DAOException {
		Connection con = null;
		try {
			con = ds.getConnection();
			Statement stmt = con.createStatement();
			stmt.executeUpdate("INSERT into paciente values (" + "'" + getId()
					+ "'," + "'" + nombre + "'," + "'" + apellidos + "'," + "'"
					+ usuario + "'," + "'" + clave + "'," + "'" + nSS + "',"
					+ "'" + numTarjeta + "'," + "'" + telefono + "'," + "'"
					+ movil + "'," + "'" + direccion + "'," + "'" + mail + "',"
					+ "'" + formaNotificacion.toString() + "'," + "'"
					+ String.valueOf(idCentroMedico) + "'" + ")");
			stmt.close();
			con.close();

			// Creamos el paciente (su centro m�dico no se carga - carga
			// perezosa)
			Paciente p = new Paciente(nombre, apellidos, usuario, clave, nSS,
					numTarjeta, telefono, movil, direccion, mail,
					formaNotificacion, null);

			return p;
		} catch (SQLException e) {
			throw new DAOException(e.getMessage());
		}
	}

	@Override
	public Usuario getUsuario(String nombreUsuario) throws DAOException {
		Connection con = null;
		try {
			con = ds.getConnection();
			Statement stmt = con.createStatement();

			// Buscamos en Administrador, Paciente y M�dico
			ResultSet rs = stmt
					.executeQuery("SELECT * from administrador WHERE nombre_usuario = '"
							+ nombreUsuario
							+ "'"
							+ " UNION "
							+ "SELECT * from paciente WHERE nombre_usuario = '"
							+ nombreUsuario
							+ "'"
							+ " UNION "
							+ "SELECT * from medico WHERE nombre_usuario = '"
							+ nombreUsuario + "'");

			Usuario u = null;
			if (rs.next()) {
				switch (rs.getString("tipoUsuario")) {
				case "Administrador":
					Administrador a = new Administrador();
					a.setId(Long.parseLong(rs.getString("id")));
					u = a;
					break;
				case "Paciente":
					Paciente p = new Paciente();
					p.setId(Long.parseLong(rs.getString("id")));
					p.setNSS(rs.getString("nss"));
					p.setNumTarjeta(rs.getString("numTarjeta"));
					p.setTelefono(rs.getString("telefono"));
					p.setMovil(rs.getString("movil"));
					p.setDireccion(rs.getString("direccion"));
					p.setMail(rs.getString("mail"));
					p.setFormaNotificacion(FormaNotificacion.valueOf(rs
							.getString("formaNotificacion")));
					u = p;
					break;
				case "Medico":
					Medico m = new Medico();
					m.setId(Long.parseLong(rs.getString("id")));
					m.setNumColegiado(rs.getString("numColegiado"));
					u = m;
					break;
				}
				// Atributos comunes
				u.setNombre(rs.getString("nombre"));
				u.setApellidos(rs.getString("apellidos"));
				u.setNombreUsuario(rs.getString("nombreUsuario"));
				u.setClave(rs.getString("clave"));
			}
			rs.close();
			stmt.close();
			con.close();

			return u;

		} catch (SQLException e) {
			throw new DAOException(e.getMessage());
		}
	}

	@Override
	public Medico registrarMedico(String nombre, String apellidos,
			String usuario, String clave, String numColegiado,
			long idCentroMedico) throws DAOException {
		Connection con = null;
		try {
			con = ds.getConnection();

			// Creamos el m�dico (su centro m�dico no se carga - carga
			// perezosa)
			Medico m = new Medico(nombre, apellidos, usuario, clave,
					numColegiado, null);

			Statement stmt = con.createStatement();
			stmt.executeUpdate("INSERT into medico values (" + "'" + getId()
					+ "'," + "'" + nombre + "'," + "'" + apellidos + "'," + "'"
					+ usuario + "'," + "'" + clave + "'," + "'" + numColegiado
					+ "'," + "'" + m.getCupoPacientes() + "'," + "'"
					+ String.valueOf(idCentroMedico) + "'" + ")");
			stmt.close();
			con.close();

			return m;
		} catch (SQLException e) {
			throw new DAOException(e.getMessage());
		}
	}

	@Override
	public Usuario login(String nombreUsuario, String clave)
			throws DAOException {
		// Buscamos el usuario en bbdd
		// Devolvemos null si no existe o la contrase�a suministrada no es
		// correcta
		Usuario usuario = getUsuario(nombreUsuario);

		if (usuario != null)
			if (!usuario.getClave().equals(clave))
				usuario = null;
		
		return usuario;
	}

	@Override
	public Administrador registrarAdministrador(String nombreUsuario,
			String clave) throws DAOException {		
		Connection con = null;
		Administrador a = null;
		try {
			con = ds.getConnection();

			// Buscamos el administrador en bbdd
			// En la aplicaci�n actualmente s�lo hay un administrador. Si la
			// aplicaci�n se extendiera a�adiendo m�s,
			// habr�a que cambiar la consulta por una que buscara en funci�n del
			// nombre de usuario.
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM administrador");
			
			if (rs.next()) {
				a = new Administrador(rs.getString("nombreUsuario"), rs.getString("clave"));
			}
			// Si no existe, lo creamos y registramos en bbdd
			else {
				a = new Administrador(nombreUsuario, clave);
				
				stmt.executeUpdate("INSERT into administrador values (" + "'" + getId()
						+ "'," + "'" + a.getNombre() + "'," + "'" + a.getApellidos() + "'," + "'"
						+ nombreUsuario + "'," + "'" + clave + "'" + ")");
			}			
			stmt.close();
			con.close();

			return a;
		} catch (SQLException e) {
			throw new DAOException(e.getMessage());
		}		
	}

	@Override
	public List<Medico> getMedicosDisponibles(long idPaciente)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cita> setRetrasoConsulta(long idMedico, LocalDate fecha,
			LocalTime hora, Duration duracion) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int adscribirPaciente(Long idMedico, Long idPaciente)
			throws DAOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Medico> getMedicos() throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Paciente> getPacientes() throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cita> getCitasDia(long idMedico, LocalDate fecha)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotalMinutosHorarioConsulta(long idMedico)
			throws DAOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<EstadoIntervalo> getEstadosIntervalos(long idMedico,
			List<IntervaloHorario> intervalos, LocalDate dia)
			throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IntervaloHorario addIntervaloHorarioConsulta(long idMedico,
			LocalTime horaInicio, LocalTime horaFin) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IntervaloHorario removeIntervaloHorarioConsulta(long idMedico,
			LocalTime horaInicio, LocalTime horaFin) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeIntervalosHorarioConsulta(long idMedico)
			throws DAOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Medico getMedicoAdscrito(long idPaciente) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}
}
