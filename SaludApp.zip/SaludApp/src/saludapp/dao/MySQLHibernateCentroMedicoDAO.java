package saludapp.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import saludapp.modelo.CentroMedico;


public class MySQLHibernateCentroMedicoDAO implements CentroMedicoDAO {
	private final SessionFactory sessionFactory;
	
	public MySQLHibernateCentroMedicoDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public CentroMedico registrarCentroMedico(String nombre, String direccion)
			throws DAOException {			
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		CentroMedico centroMedico;
		
		try {
			tx = session.beginTransaction(); 		

			centroMedico = new CentroMedico(nombre, direccion);

			session.save(centroMedico); 

			tx.commit(); 
		}catch (Exception e) {
			if (tx!=null) tx.rollback();
			throw new DAOException(e.getMessage());
		}
		finally {
			session.close();
		}			
		return centroMedico;
	}

	@Override
	public List<CentroMedico> getCentrosMedicos() throws DAOException {
		Session session = sessionFactory.openSession(); 
		Transaction tx = null;
		List<CentroMedico> centros;

		try {
			tx = session.beginTransaction(); 
			
			Query q = session.createQuery("from CentroMedico");
			centros = q.list();	

			tx.commit(); 
		}catch (Exception e) {
			if (tx!=null) tx.rollback();
			throw new DAOException(e.getMessage());
		}
		finally {
			session.close();
		}		
		return centros;	
	}

}
