package saludapp.dao;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class MySQLHibernateFactoriaDAO extends FactoriaDAO {		
	SessionFactory sessionFactory;
	
	public MySQLHibernateFactoriaDAO () {
		sessionFactory = new Configuration().configure().buildSessionFactory();
	}

	@Override
	public UsuarioDAO getUsuarioDAO() {
		return new MySQLHibernateUsuarioDAO(sessionFactory);
	}

	@Override
	public CitaDAO getCitaDAO() {
		return new MySQLHibernateCitaDAO(sessionFactory);
	}

	@Override
	public CentroMedicoDAO getCentroMedicoDAO() {
		return new MySQLHibernateCentroMedicoDAO(sessionFactory);
	}

	@Override
	public SolicitudCambioMedicoDAO getSolicitudCambioMedicoDAO() {
		return new MySQLHibernateSolicitudCambioMedicoDAO(sessionFactory);
	}

}
