package saludapp.pool;

import java.sql.*;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;


public class ConnectionWrapper implements Connection
{
	Connection con = null;
	ConnectionPool pool;
	
	public ConnectionWrapper (ConnectionPool pool, Connection con) {
		this.con = con;
		this.pool = pool;
	}
	
	// Devuelve la conexi�n al pool
	public void close() throws SQLException
	{
		// Devuelve la conexi�n al pool
		pool.returnConnection(this);
		
	}
	
	// El resto de operaciones de la interfaz son delegadas a la conexi�n
    public Statement createStatement() throws SQLException
	{
		return con.createStatement();
	}

    
    public PreparedStatement prepareStatement(String sql)
	throws SQLException
	{
		return con.prepareStatement(sql);
	}

    
    public CallableStatement prepareCall(String sql) throws SQLException
	{
		return con.prepareCall(sql);
	}
						
    
    public String nativeSQL(String sql) throws SQLException
	{
		return con.nativeSQL(sql);
	}
   
    public void setAutoCommit(boolean autoCommit) throws SQLException
	{
		con.setAutoCommit(autoCommit);
	}

   
    public boolean getAutoCommit() throws SQLException
	{
		return con.getAutoCommit();
	}

   
    public void commit() throws SQLException
	{
		con.commit();
	}
   
    public void rollback() throws SQLException
	{
		con.rollback();
	}
    
   
    public boolean isClosed() throws SQLException
	{
		return con.isClosed();
	}

   
    public DatabaseMetaData getMetaData() throws SQLException
	{
		return con.getMetaData();
	}

   
    public void setReadOnly(boolean readOnly) throws SQLException
	{
		con.setReadOnly(readOnly);
	}

   
    public boolean isReadOnly() throws SQLException
	{
		return con.isReadOnly();
	}

   
    public void setCatalog(String catalog) throws SQLException
	{
		con.setCatalog(catalog);
	}
   
    public String getCatalog() throws SQLException
	{
		return con.getCatalog();
	}
    
    public void setTransactionIsolation(int level) throws SQLException
	{
		con.setTransactionIsolation(level);
	}
    
    public int getTransactionIsolation() throws SQLException
	{
		return con.getTransactionIsolation();
	}

    
    public SQLWarning getWarnings() throws SQLException
	{
		return con.getWarnings();
	}
    
    public void clearWarnings() throws SQLException
	{
		con.clearWarnings();
	}


    public Statement createStatement(int resultSetType, int resultSetConcurrency)
	throws SQLException
	{
		return con.createStatement(resultSetType, resultSetConcurrency);
	}

    public PreparedStatement prepareStatement(String sql, int resultSetType,
				       int resultSetConcurrency)
	throws SQLException
	{
		return con.prepareStatement(sql, resultSetType, resultSetConcurrency);
	}

    public CallableStatement prepareCall(String sql, int resultSetType,
				  int resultSetConcurrency) throws SQLException
	{
		return con.prepareCall(sql, resultSetType, resultSetConcurrency);
	}

    public java.util.Map getTypeMap() throws SQLException
	{
		return con.getTypeMap();
	}
    
	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException {
		return con.unwrap(iface);
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return con.isWrapperFor(iface);
	}

	@Override
	public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
		con.setTypeMap(map);		
	}

	@Override
	public void setHoldability(int holdability) throws SQLException {
		con.setHoldability(holdability);		
	}

	@Override
	public int getHoldability() throws SQLException {
		return con.getHoldability();
	}

	@Override
	public Savepoint setSavepoint() throws SQLException {
		return con.setSavepoint();
	}

	@Override
	public Savepoint setSavepoint(String name) throws SQLException {
		return con.setSavepoint(name);
	}

	@Override
	public void rollback(Savepoint savepoint) throws SQLException {
		con.rollback(savepoint);		
	}

	@Override
	public void releaseSavepoint(Savepoint savepoint) throws SQLException {
		con.releaseSavepoint(savepoint);
	}

	@Override
	public Statement createStatement(int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		return con.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
	}

	@Override
	public PreparedStatement prepareStatement(String sql, int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		return con.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
	}

	@Override
	public CallableStatement prepareCall(String sql, int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		return con.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
	}

	@Override
	public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
			throws SQLException {
		return con.prepareStatement(sql, autoGeneratedKeys);
	}

	@Override
	public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
			throws SQLException {
		return con.prepareStatement(sql, columnIndexes);
	}

	@Override
	public PreparedStatement prepareStatement(String sql, String[] columnNames)
			throws SQLException {
		return con.prepareStatement(sql, columnNames);
	}

	@Override
	public Clob createClob() throws SQLException {
		return con.createClob();
	}

	@Override
	public Blob createBlob() throws SQLException {
		return con.createBlob();
	}

	@Override
	public NClob createNClob() throws SQLException {
		return con.createNClob();
	}

	@Override
	public SQLXML createSQLXML() throws SQLException {
		return con.createSQLXML();
	}

	@Override
	public boolean isValid(int timeout) throws SQLException {
		return con.isValid(timeout);
	}

	@Override
	public void setClientInfo(String name, String value)
			throws SQLClientInfoException {
		con.setClientInfo(name, value);		
	}

	@Override
	public void setClientInfo(Properties properties)
			throws SQLClientInfoException {
		con.setClientInfo(properties);
	}

	@Override
	public String getClientInfo(String name) throws SQLException {
		return con.getClientInfo(name);
	}

	@Override
	public Properties getClientInfo() throws SQLException {
		return con.getClientInfo();
	}

	@Override
	public Array createArrayOf(String typeName, Object[] elements)
			throws SQLException {
		return con.createArrayOf(typeName, elements);
	}

	@Override
	public Struct createStruct(String typeName, Object[] attributes)
			throws SQLException {
		return con.createStruct(typeName, attributes);
	}

	@Override
	public void abort(Executor arg0) throws SQLException {
		con.abort(arg0);
	}

	@Override
	public int getNetworkTimeout() throws SQLException {
		return con.getNetworkTimeout();
	}

	@Override
	public String getSchema() throws SQLException {
		return con.getSchema();
	}

	@Override
	public void setNetworkTimeout(Executor arg0, int arg1) throws SQLException {
		con.setNetworkTimeout(arg0, arg1);
	}

	@Override
	public void setSchema(String arg0) throws SQLException {
		con.setSchema(arg0);
	}

    
}

