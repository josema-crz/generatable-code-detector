package saludapp.servlet;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletLog
 */
@WebServlet("/ServletLog")
public class ServletLog extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private Logger logger;
	private static final String rutaFichero = "c:\\acceso.log";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletLog() {
		super();

		FileHandler fh;

		try {
			logger = Logger.getLogger("LoginLog");
			fh = new FileHandler(rutaFichero, true);
			logger.addHandler(fh);
			logger.setLevel(Level.ALL);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);

		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		boolean identificado = (boolean) request.getAttribute("identificado");

		String usuario = request.getParameter("usuario");
		String clave = request.getParameter("clave");
		if (usuario == null) {
			usuario = (String) request.getAttribute("usuario");
			clave = (String) request.getAttribute("clave");
		}
		
		if (identificado) {
			// Registramos el nombre de usuario y clave con que se ha realizado
			// el registro y el tipo de usuario del que se trata
			String tipoUsuario = (String) request.getAttribute("tipoUsuario");			

			logger.log(Level.INFO, "Login satisfactorio. Usuario:" + usuario
					+ " Clave:" + clave + ". El usuario es un " + tipoUsuario);
		} else {
			// Registramos el nombre de usuario y clave suministrados y el
			// n�mero de intentos fallidos incluyendo este �ltimo
			int fallos = ((Integer) request.getAttribute("fallos")).intValue();
			
			logger.log(Level.WARNING, "Login err�neo. Usuario:" + usuario
					+ " Clave:" + clave + ". N�mero de intentos fallidos: " + fallos);
		}
	}

}
