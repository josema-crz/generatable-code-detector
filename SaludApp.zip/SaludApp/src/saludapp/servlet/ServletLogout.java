package saludapp.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import saludapp.jms.AvisosImportantesMedicoX;

/**
 * Servlet implementation class ServletLogout
 */
@WebServlet("/ServletLogout")
public class ServletLogout extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletLogout() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Eliminamos las cookies de inicio de sesi�n
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("usuario")
						|| cookie.getName().equals("clave")) {
					cookie.setValue("");
					// El borrado se consigue poniendo la edad a 0
					cookie.setMaxAge(0);
					response.addCookie(cookie);
				}
			}
		}

		// Cerramos la sesi�n
		HttpSession sesion = request.getSession();
		sesion.invalidate();

		// Cerramos la subscripci�n JMS
		try {
			AvisosImportantesMedicoX.getUnicaInstancia().close();
		} catch (Exception e) {
		}
		
		response.sendRedirect("ServletLogin");
	}

}
