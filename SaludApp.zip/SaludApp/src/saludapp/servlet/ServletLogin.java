package saludapp.servlet;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.*;

import saludapp.controlador.Controlador;
import saludapp.modelo.Paciente;
import saludapp.modelo.Usuario;

/**
 * Servlet implementation class ServletLogin
 */
public class ServletLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private String adminUser;
	private String adminPass;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletLogin() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		// Obtenemos el user y pass del admin, guardados como par�metros de
		// inicializaci�n
		adminUser = config.getInitParameter("adminUser");
		adminPass = config.getInitParameter("adminPass");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Comprobamos si el navegador nos env�a las cookies con el usuario y
		// clave
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			Cookie usuario = null;
			Cookie clave = null;
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals("usuario"))
					usuario = cookies[i];
				else if (cookies[i].getName().equals("clave"))
					clave = cookies[i];
			}
			// Iniciamos sesi�n con el usuario y clave en cuesti�n
			if (usuario != null && clave != null) {
				// Extraigo el valor de las cookies
				String usuarioS = usuario.getValue();
				String claveS = clave.getValue();
				// Delego en el post para que haga el login de forma normal
				request.setAttribute("usuario", usuarioS);
				request.setAttribute("clave", claveS);
				doPost(request, response);
				return;
			}
		}
		// Si no hay cookies de identificaci�n, mostramos la p�gina de login
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		// Obtenemos la ruta f�sica el fichero del formulario
		String pathFichero = getServletConfig().getServletContext()
				.getRealPath("login.html");
		// Tenemos el formulario vac�o en el fichero "login.html"
		BufferedReader br = new BufferedReader(new FileReader(pathFichero));
		String linea;
		while ((linea = br.readLine()) != null)
			out.println(linea);
		br.close();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		boolean identificado = false;

		// Recuperamos el objeto sesi�n
		HttpSession sesion = request.getSession(true);
		// Obtenemos el n�mero de identificaciones fallidas
		Integer numFallos = (Integer) sesion.getAttribute("fallos");
		if (numFallos == null) {
			// No se ha identificado
			numFallos = new Integer(0);
			sesion.setAttribute("fallos", numFallos);
		} else if (numFallos.intValue() == 3) {
			PrintWriter out = response.getWriter();
			out.println("N�mero de fallos de identificaci�n excedido");
			return;
		}

		// Obtenemos la informaci�n de la petici�n, consultando los
		// par�metros...
		String usuario = request.getParameter("usuario");
		String clave = request.getParameter("clave");
		boolean mantenerSesion = (request.getParameter("mantenerSesion") != null);
		// ...o los atributos de la petici�n
		if (usuario == null) {
			usuario = (String) request.getAttribute("usuario");
			clave = (String) request.getAttribute("clave");
			mantenerSesion = false; // lo ponemos a false pues las cookies ya
									// existen
		}

		Usuario u = null;

		// Si es el admin, llamamos al controlador para que lo registre en caso
		// de ser necesario
		if (usuario.equals(adminUser)) {
			if (clave.equals(adminPass))
				u = Controlador.getUnicaInstancia().registrarAdministrador(
						usuario, clave);
		}
		// Si no es el admin, login normal
		else
			u = Controlador.getUnicaInstancia().login(usuario, clave);

		identificado = (u != null);

		// Establecemos el tipo MIME de la respuesta
		response.setContentType("text/html");

		// Establecemos la cabecera de refresco
		String referer = "";
		if (identificado)
			// Vamos a la p�gina home del tipo de usuario correspondiente
			referer = "home" + u.getClass().getSimpleName() + ".faces";
		else
			// Volvemos a la de login
			referer = "ServletLogin";
		response.setHeader("refresh", "3; URL=" + referer);

		// Escribimos la respuesta
		PrintWriter out = response.getWriter();
		// Cabecera HTMLresponse
		out.println("<html> <head> <title> Login </title> </head> <body>");
		// Resultado de la identificaci�n
		if (identificado)
			out.println("<B><P>Identificaci�n correcta</B></P>");
		else
			out.println("<B><P>Error de identificaci�n</B></P>");

		// Cierre de la p�gina
		out.println("</body>");
		out.println("</html>");

		// Le pasamos la info al ServletLog
		request.setAttribute("identificado", identificado);

		// Actualizamos la sesi�n
		if (identificado) {
			// Guardamos el objeto usuario en la sesi�n
			sesion.setAttribute("usuario", u);
			// Si es un paciente, guardamos tambi�n el id de su m�dico adscrito
			if (u instanceof Paciente) {
				Paciente p = (Paciente) u;
				if (p.getAdscrito() != null)
					sesion.setAttribute("adscrito", p.getAdscrito().getId());
			}
			// Reseteamos n�mero fallos
			sesion.setAttribute("fallos", new Integer(0));

			// Si el usuario marc� la opci�n, enviamos un par de cookies al
			// navegador web con el usuario y clave
			if (mantenerSesion) {
				Cookie cookieUsuario = new Cookie("usuario",
						u.getNombreUsuario());
				cookieUsuario.setMaxAge(60 * 60 * 24 * 7); // C�lculo segundos
															// d�a
				Cookie cookieClave = new Cookie("clave", u.getClave());
				cookieClave.setMaxAge(60 * 60 * 24 * 7);
				response.addCookie(cookieUsuario);
				response.addCookie(cookieClave);
			}

			// Le pasamos la info al ServletLog
			request.setAttribute("tipoUsuario", u.getClass().getSimpleName());

		} else {
			// Incrementamos el n�mero de fallos
			int fallos = ((Integer) sesion.getAttribute("fallos")).intValue();
			sesion.setAttribute("fallos", new Integer(++fallos));

			// Le pasamos la info al ServletLog
			request.setAttribute("fallos", fallos);
		}

		// Conseguimos la referencia al contexto de la aplicaci�n
		// para crear un request dispatcher
		ServletContext app = getServletConfig().getServletContext();
		RequestDispatcher rd = app.getNamedDispatcher("ServletLog");
		// Reenviamos la petici�n capturando cualquier excepci�n que se produzca
		try {
			// Sem�ntica forward
			rd.include(request, response);
			return;
		} catch (Exception e) {
		}
	}

}
