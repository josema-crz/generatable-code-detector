package saludapp.controlador;

import java.rmi.Naming;
import java.security.Permission;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.dao.DAOException;
import saludapp.dao.FactoriaDAO;
import saludapp.dao.TiposFactoriaDAO;
import saludapp.modelo.*;
import saludapp.rmi.GestorAvisos;

public class Controlador {
	private static Controlador unicaInstancia = new Controlador();

	private FactoriaDAO factoriaDAO;
	private GestorAvisos gestorAvisos;

	private class MySecurityManager extends SecurityManager {
		@Override
		public void checkPermission(Permission perm) {
			return;
		}
	}

	private Controlador() {
		try {
			factoriaDAO = FactoriaDAO
					.getFactoriaDAO(TiposFactoriaDAO.MYSQL_HIBERNATE);

			// Inicializaci�n RMI
			// Instalaci�n del Gestor de Seguridad RMI
			if (System.getSecurityManager() == null)
				System.setSecurityManager(new MySecurityManager());
			// Obtenci�n de la referencia remota
			try {
				gestorAvisos = (GestorAvisos) Naming.lookup("GestorAvisos");
			} catch (Exception e) {
				System.err.println("Error al obtener la referencia remota: "
						+ e);
			}

		} catch (DAOException e) {
			e.printStackTrace();
		}
	}

	public static Controlador getUnicaInstancia() {
		return unicaInstancia;
	}

	/**
	 * Crea un nuevo paciente con los datos suministrados
	 * 
	 */
	public Paciente registrarPaciente(String nombre, String apellidos,
			String usuario, String clave, String nSS, String numTarjeta,
			String telefono, String movil, String direccion, String mail,
			FormaNotificacion formaNotificacion, long idCentroMedico) {
		try {
			// Aunque el validador supuestamente ya lo habr� comprobado
			if (!existeUsuario(usuario))
				return factoriaDAO.getUsuarioDAO().registrarPaciente(nombre,
						apellidos, usuario, clave, nSS, numTarjeta, telefono,
						movil, direccion, mail, formaNotificacion,
						idCentroMedico);
			return null;

		} catch (IllegalArgumentException e) {
			return null;
		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Crea un nuevo m�dico con los datos suministrados
	 */
	public Medico registrarMedico(String nombre, String apellidos,
			String usuario, String clave, String numColegiado,
			Long idCentroMedico) {
		try {
			// Aunque el validador supuestamente ya lo habr� comprobado
			if (!existeUsuario(usuario))
				return factoriaDAO.getUsuarioDAO()
						.registrarMedico(nombre, apellidos, usuario, clave,
								numColegiado, idCentroMedico);
			else
				return null;

		} catch (IllegalArgumentException e) {
			return null;
		} catch (DAOException e) {
			return null;
		}
	}

	public boolean existeUsuario(String nombreUsuario) {
		try {
			return (factoriaDAO.getUsuarioDAO().getUsuario(nombreUsuario) != null);
		} catch (DAOException e) {
			return true;
		}
	}

	/**
	 * Crea un nuevo centro m�dico con los datos suministrados
	 */
	public CentroMedico registrarCentroMedico(String nombre, String direccion) {
		try {
			return factoriaDAO.getCentroMedicoDAO().registrarCentroMedico(
					nombre, direccion);
		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Implementa el login en el sistema. Comprueba si el usuario existe y la
	 * clave es correcta.
	 * 
	 * @return el usuario correspondiente si las credenciales son correctas.
	 *         null si las credenciales no son correctas.
	 */
	public Usuario login(String nombreUsuario, String clave) {
		Usuario usuario = null;
		try {
			usuario = factoriaDAO.getUsuarioDAO().login(nombreUsuario, clave);
		} catch (DAOException e) {
		}
		return usuario;
	}

	/**
	 * Comprueba si el usuario Administrador est� registrado en el sistema,
	 * cre�ndolo si es necesario.
	 */
	public Administrador registrarAdministrador(String usuario, String clave) {
		Administrador admin = null;
		try {
			admin = factoriaDAO.getUsuarioDAO().registrarAdministrador(usuario,
					clave);
		} catch (DAOException e) {
		}
		return admin;
	}

	/**
	 * Crea una cita el d�a indicado, a la hora indicada y con la duraci�n
	 * indicada, para el paciente indicado. Si se proporciona el id de una cita,
	 * entonces se modificar� dicha cita en lugar de crear una nueva.
	 */
	public Cita registrarCita(long idPaciente, long idMedico, Long idCita,
			LocalDate dia, int horaInicioInt, int minutoInicioInt,
			Duration duracion) {
		LocalTime hora = new LocalTime();

		try {
			hora = new LocalTime(horaInicioInt, minutoInicioInt);

			// Si el paciente ya tiene alguna cita pendiente no podr� pedir otra
			// nueva
			if (idCita == null
					&& !getCitasActualesPaciente(idPaciente).isEmpty())
				return null;

			// Obtenemos la disponibilidad del intervalo
			List<IntervaloHorario> intervalos = new LinkedList<IntervaloHorario>();
			intervalos.add(new IntervaloHorario(hora, duracion));
			EstadoIntervalo estado = getEstadosIntervalos(idMedico, intervalos,
					dia).get(0);

			// Si est� disponible, registramos o modificamos la cita
			if (estado == EstadoIntervalo.DISPONIBLE) {
				if (idCita == null)
					return factoriaDAO.getCitaDAO().registrarCita(dia, hora,
							duracion, idPaciente);
				else
					return factoriaDAO.getCitaDAO().modificarCita(idCita,
							idMedico, dia, hora, duracion);
			} else {
				return null;
			}

		} catch (IllegalArgumentException e) {
			return null;
		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Devuelve todos los m�dicos con cupo de pacientes disponible, ignorando al
	 * m�dico del paciente suministrado
	 */
	public List<Medico> getMedicosDisponibles(Long idPaciente) {
		List<Medico> medicosDisponibles = new LinkedList<Medico>();
		try {
			if (idPaciente != null)
				// Obtiene la lista de m�dicos disponibles
				medicosDisponibles = factoriaDAO.getUsuarioDAO()
						.getMedicosDisponibles(idPaciente);

		} catch (DAOException e) {
		}

		return medicosDisponibles;
	}

	/**
	 * Crea una solicitud de cambio de m�dico con los datos suministrados
	 */
	public SolicitudCambioMedico registrarSolicitudCambioMedico(
			long idPaciente, long idNuevoMedico, String motivo) {
		try {
			return factoriaDAO.getSolicitudCambioMedicoDAO()
					.registrarSolicitudCambioMedico(idPaciente, idNuevoMedico,
							motivo);

		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Registra un s�ntoma con los datos suministrados para la cita especificada
	 */
	public Sintoma addSintoma(long idCita, String descripcion,
			ValoracionGravedad valoracionGravedad) {
		try {
			return factoriaDAO.getCitaDAO().registrarSintoma(idCita,
					descripcion, valoracionGravedad);

		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Registra un diagn�stico con los datos suministrados para la cita
	 * especificada
	 */
	public Diagnostico addDiagnostico(long idCita, String enfermedad,
			boolean hospitalizacion) {
		try {
			return factoriaDAO.getCitaDAO().registrarDiagnostico(idCita,
					enfermedad, hospitalizacion);
		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Registra un tratamiento con los datos suministrados para la cita
	 * especificada
	 */
	public Tratamiento addTratamiento(long idCita, String medicamento,
			double cantidad, double dosisDiaria, LocalDate inicio, LocalDate fin) {
		try {
			return factoriaDAO.getCitaDAO().registrarTratamiento(idCita,
					medicamento, cantidad, dosisDiaria, inicio, fin);

		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Introduce un retraso con una duraci�n determinada en las citas de un
	 * m�dico a partir de cierta hora de cierto d�a
	 */
	public boolean setRetrasoConsulta(long idMedico, LocalDate dia,
			int horaInicioInt, int minutoInicioInt, Duration duracion) {
		try {
			LocalTime hora = new LocalTime(horaInicioInt, minutoInicioInt);

			return !(factoriaDAO.getUsuarioDAO().setRetrasoConsulta(idMedico,
					dia, hora, duracion) == null);

		} catch (DAOException e) {
			return false;
		}
	}

	/**
	 * A�ade un intervalo horario determinado al horario de consulta del m�dico
	 * especificado
	 */
	public IntervaloHorario addIntervaloHorarioConsulta(long idMedico,
			int horaInicioInt, int minutoInicioInt, int horaFinInt,
			int minutoFinInt) {
		try {
			LocalTime horaInicio = new LocalTime(horaInicioInt, minutoInicioInt);
			LocalTime horaFin = new LocalTime(horaFinInt, minutoFinInt);

			// Comprobamos que los datos son correctos
			if (horaInicio.isEqual(horaFin))
				return null;
			if (horaInicio.isAfter(horaFin)) {
				LocalTime temp = horaInicio;
				horaInicio = horaFin;
				horaFin = temp;
			}

			return factoriaDAO.getUsuarioDAO().addIntervaloHorarioConsulta(
					idMedico, horaInicio, horaFin);

		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Elimina un intervalo horario determinado del horario de consulta del
	 * m�dico especificado
	 */
	public Object removeIntervaloHorarioConsulta(long idMedico,
			Integer horaInicioInt, Integer minutoInicioInt, Integer horaFinInt,
			Integer minutoFinInt) {
		try {
			LocalTime horaInicio = new LocalTime(horaInicioInt, minutoInicioInt);
			LocalTime horaFin = new LocalTime(horaFinInt, minutoFinInt);

			// Comprobamos que los datos son correctos
			if (horaInicio.isEqual(horaFin))
				return null;
			if (horaInicio.isAfter(horaFin)) {
				LocalTime temp = horaInicio;
				horaInicio = horaFin;
				horaFin = temp;
			}

			return factoriaDAO.getUsuarioDAO().removeIntervaloHorarioConsulta(
					idMedico, horaInicio, horaFin);

		} catch (DAOException e) {
			return null;
		}
	}

	public boolean removeIntervalosHorarioConsulta(long idMedico) {
		try {
			return factoriaDAO.getUsuarioDAO().removeIntervalosHorarioConsulta(
					idMedico);
		} catch (DAOException e) {
			return false;
		}
	}

	/**
	 * Devuelve el n�mero de minutos de consulta configurados en el horario del
	 * m�dico con id=idMedico.
	 */
	public int getTotalMinutosHorarioConsulta(long idMedico) {
		try {
			return factoriaDAO.getUsuarioDAO().getTotalMinutosHorarioConsulta(
					idMedico);
		} catch (DAOException e) {
			return 0;
		}
	}

	/**
	 * Adscribe el paciente indicado al m�dico indicado
	 * 
	 * @return 0 �xito -1 error DAO -2 error JMS
	 */
	public int adscribirPaciente(Long idPaciente, Long idMedico) {
		try {
			return factoriaDAO.getUsuarioDAO().adscribirPaciente(idMedico,
					idPaciente);
		} catch (DAOException e) {
			e.printStackTrace();
			return -1;
		} 
	}

	/**
	 * Crea una cita de urgencia con los datos suministrados
	 */
	public Cita registrarCitaUrgencia(long idPaciente, LocalDate dia,
			int horaInicioInt, int minutoInicioInt, Duration duracion,
			String motivoUrgencia) {
		Cita cita = null;

		try {
			LocalTime hora = new LocalTime(horaInicioInt, minutoInicioInt);

			// Obtenemos el m�dico adscrito al paciente en cuesti�n
			Medico medico = factoriaDAO.getUsuarioDAO().getMedicoAdscrito(
					idPaciente);

			if (medico != null) {
				// Establecemos el retraso que pudiera llevar asociado
				// Se nos devuelven las citas afectadas por el retraso
				List<Cita> citasAfectadas = factoriaDAO
						.getUsuarioDAO()
						.setRetrasoConsulta(medico.getId(), dia, hora, duracion);

				// Si la primera de estas citas se encuentra en mitad de la hora
				// especificada, esta cita no ser� afectada y la cita de
				// urgencia se
				// desplaza hasta el final de la misma
				if (!citasAfectadas.isEmpty()) {
					Cita primeraAfectada = citasAfectadas.get(0);
					if (primeraAfectada.getIntervalo().getHoraInicio()
							.isBefore(hora))
						hora = primeraAfectada.getIntervalo().getHoraFin();
				}

				// Registramos la cita
				cita = factoriaDAO.getCitaDAO().registrarCitaUrgencia(dia,
						hora, duracion, idPaciente, motivoUrgencia);

			}
			return cita;

		} catch (DAOException e) {
			return null;
		}
	}

	public Cita registrarCitaRevision(long idMedico, long idCitaRevisada,
			LocalDate dia, int horaInicioInt, int minutoInicioInt,
			Duration duracion, String motivoRevision) {
		try {
			LocalTime hora = new LocalTime(horaInicioInt, minutoInicioInt);

			// Obtenemos la disponibilidad del intervalo
			List<IntervaloHorario> intervalos = new LinkedList<IntervaloHorario>();
			intervalos.add(new IntervaloHorario(hora, duracion));
			EstadoIntervalo estado = getEstadosIntervalos(idMedico, intervalos,
					dia).get(0);

			// Si est� disponible, registramos la cita
			if (estado == EstadoIntervalo.DISPONIBLE)
				return factoriaDAO.getCitaDAO().registrarRevision(
						idCitaRevisada, dia, hora, duracion, motivoRevision);
			return null;

		} catch (DAOException e) {
			return null;
		}
	}

	/**
	 * Resuelve la solicitud indicada. Si se acepta, se elimina la adscripci�n
	 * del paciente al antiguo m�dico y se crea la nueva
	 */
	public SolicitudCambioMedico resolverSolicitudCambioMedico(
			long idSolicitud, boolean aceptada) {
		try {
			return factoriaDAO.getSolicitudCambioMedicoDAO()
					.resolverSolicitudCambioMedico(idSolicitud, aceptada);

		} catch (DAOException e) {
			return null;
		}
	}

	public List<SolicitudCambioMedico> getSolicitudesCambioMedicoPendientes() {
		try {
			return factoriaDAO.getSolicitudCambioMedicoDAO()
					.getSolicitudesCambioMedicoPendientes();
		} catch (DAOException e) {
			return new LinkedList<SolicitudCambioMedico>();
		}
	}

	public List<Cita> getHistorialPaciente(long idPaciente) {
		try {
			List<Cita> historial = factoriaDAO.getCitaDAO()
					.getHistorialPaciente(idPaciente);
			Collections.sort(historial);
			return historial;
		} catch (DAOException e) {
			return new LinkedList<Cita>();
		}
	}

	/**
	 * Devuelve las citas pendientes del paciente (fecha futura). No permitimos
	 * pedir m�s de una cita al mismo tiempo por norma general, pero las citas
	 * de urgencia son una excepci�n a esta regla. Esta es la raz�n de que se
	 * devuelva una lista y no una �nica cita.
	 * 
	 * @param idPaciente
	 * @return
	 */
	public List<Cita> getCitasActualesPaciente(long idPaciente) {
		try {
			return factoriaDAO.getCitaDAO()
					.getCitasActualesPaciente(idPaciente);
		} catch (DAOException e) {
			return null;
		}
	}

	public List<Cita> getCitasDia(long idMedico, LocalDate dia) {
		try {
			List<Cita> citasDia = factoriaDAO.getUsuarioDAO().getCitasDia(
					idMedico, dia);
			Collections.sort(citasDia);
			return citasDia;

		} catch (DAOException e) {
			return null;
		}
	}

	public List<Paciente> getPacientes() {
		try {
			return factoriaDAO.getUsuarioDAO().getPacientes();

		} catch (DAOException e) {
			return new LinkedList<Paciente>();
		}
	}

	public List<Medico> getMedicos() {
		try {
			return factoriaDAO.getUsuarioDAO().getMedicos();

		} catch (DAOException e) {
			return new LinkedList<Medico>();
		}
	}

	public List<CentroMedico> getCentrosMedicos() {
		try {
			return factoriaDAO.getCentroMedicoDAO().getCentrosMedicos();
		} catch (DAOException e) {
			return new LinkedList<CentroMedico>();
		}
	}

	public List<EstadoIntervalo> getEstadosIntervalos(long idMedico,
			List<IntervaloHorario> intervalos, LocalDate dia) {
		try {
			return factoriaDAO.getUsuarioDAO().getEstadosIntervalos(idMedico,
					intervalos, dia);
		} catch (DAOException e) {
			return new LinkedList<EstadoIntervalo>();
		}
	}

	public Set<Sintoma> getSintomas(Long cita) {
		try {
			return factoriaDAO.getCitaDAO().getSintomas(cita);
		} catch (DAOException e) {
			return new LinkedHashSet<Sintoma>();
		}
	}

	public Set<Diagnostico> getDiagnosticos(Long cita) {
		try {
			return factoriaDAO.getCitaDAO().getDiagnosticos(cita);
		} catch (DAOException e) {
			return new LinkedHashSet<Diagnostico>();
		}
	}

	public Set<Tratamiento> getTratamientos(Long cita) {
		try {
			return factoriaDAO.getCitaDAO().getTratamientos(cita);
		} catch (DAOException e) {
			return new LinkedHashSet<Tratamiento>();
		}
	}

	public GestorAvisos getGestorAvisos() {
		return gestorAvisos;
	}
}
