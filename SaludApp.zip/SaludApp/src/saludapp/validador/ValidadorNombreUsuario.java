package saludapp.validador;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import saludapp.controlador.Controlador;

public class ValidadorNombreUsuario implements Validator {

	@Override
	public void validate(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ValidatorException {
		if (Controlador.getUnicaInstancia().existeUsuario((String) arg2))
			throw new ValidatorException(new FacesMessage(ResourceBundle
					.getBundle("saludapp.resource.saludapp").getString(
							"errorNombreUsuarioExiste")));	
	}

}
