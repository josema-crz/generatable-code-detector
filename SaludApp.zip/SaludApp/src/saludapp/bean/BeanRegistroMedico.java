package saludapp.bean;

import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlInputSecret;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import saludapp.controlador.Controlador;
import saludapp.modelo.CentroMedico;

public class BeanRegistroMedico {
	private String nombre;
	private String apellidos;
	private String nombreUsuario;
	private String clave;
	private String clave2;
	private String numColegiado;
	private long centroMedico;
	
	private HtmlInputSecret inputClave;

	private Map<String, Long> centrosMedicos;

	public String registrar() {
		Object m = Controlador.getUnicaInstancia().registrarMedico(nombre,
				apellidos, nombreUsuario, clave, numColegiado, centroMedico);

		if (m == null)
			return "fallo";
		return "ok";
	}
	
	public void validarClave2(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ValidatorException {
		if (!((String)arg2).equals(inputClave.getValue()))
			throw new ValidatorException(new FacesMessage(ResourceBundle
					.getBundle("saludapp.resource.saludapp").getString(
							"errorClave2")));
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getClave2() {
		return clave2;
	}

	public void setClave2(String clave2) {
		this.clave2 = clave2;
	}

	public String getNumColegiado() {
		return numColegiado;
	}

	public void setNumColegiado(String numColegiado) {
		this.numColegiado = numColegiado;
	}

	public long getCentroMedico() {
		return centroMedico;
	}

	public void setCentroMedico(long centroMedico) {
		this.centroMedico = centroMedico;
	}

	public Map<String, Long> getCentrosMedicos() {
		// Obtenemos los centros m�dicos y metemos sus nombres indexados por su
		// id
		centrosMedicos = new TreeMap<String, Long>();

		List<CentroMedico> cms;
		cms = Controlador.getUnicaInstancia().getCentrosMedicos();

		// No hay centros m�dicos
		if (cms.isEmpty()) {
			// Mostramos un mensaje en el men�
			centrosMedicos.put(
					ResourceBundle.getBundle("saludapp.resource.saludapp")
							.getString("noCentrosMedicos"), null);
		} else
			for (CentroMedico cm : cms)
				centrosMedicos.put(cm.getNombre(), cm.getId());

		return centrosMedicos;
	}

	public void setCentrosMedicos(Map<String, Long> centrosMedicos) {
		this.centrosMedicos = centrosMedicos;
	}

	public HtmlInputSecret getInputClave() {
		return inputClave;
	}

	public void setInputClave(HtmlInputSecret inputClave) {
		this.inputClave = inputClave;
	}
	
	

}
