package saludapp.bean;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.joda.time.LocalDate;

import saludapp.controlador.Controlador;
import saludapp.modelo.Paciente;

public class BeanPedirCitaUrgencia {
	private LocalDate dia;
	private Long paciente;
	private String motivoUrgencia;

	private BeanHoraDuracion beanHoraDuracion;

	private Map<String, Long> pacientes;

	{
		pacientes = new LinkedHashMap<String, Long>();
	}

	public String registrar() {
		Object resultado = Controlador.getUnicaInstancia()
				.registrarCitaUrgencia(paciente, dia,
						beanHoraDuracion.getHoraInicio(),
						beanHoraDuracion.getMinutoInicio(),
						beanHoraDuracion.getDuracion(), motivoUrgencia);

		if (resultado == null)
			return "fallo";
		return "ok";
	}

	public LocalDate getDia() {
		return dia;
	}

	public void setDia(LocalDate dia) {
		this.dia = dia;
	}

	public Long getPaciente() {
		return paciente;
	}

	public void setPaciente(Long paciente) {
		this.paciente = paciente;
	}

	public String getMotivoUrgencia() {
		return motivoUrgencia;
	}

	public void setMotivoUrgencia(String motivoUrgencia) {
		this.motivoUrgencia = motivoUrgencia;
	}

	public BeanHoraDuracion getBeanHoraDuracion() {
		return beanHoraDuracion;
	}

	public void setBeanHoraDuracion(BeanHoraDuracion beanHoraDuracion) {
		this.beanHoraDuracion = beanHoraDuracion;
	}

	public Map<String, Long> getPacientes() {
		// Metemos los pacientes en la lista
		List<Paciente> ps;
		ps = Controlador.getUnicaInstancia().getPacientes();

		// No hay pacientes
		if (ps.isEmpty()) {
			// Mostramos un mensaje en el men�
			pacientes.put(
					ResourceBundle.getBundle("saludapp.resource.saludapp")
							.getString("noPacientes"), null);
		} else
			for (Paciente p : ps)
				pacientes.put(p.getApellidos() + ", " + p.getNombre(),
						p.getId());

		return pacientes;
	}

	public void setPacientes(Map<String, Long> pacientes) {
		this.pacientes = pacientes;
	}
}
