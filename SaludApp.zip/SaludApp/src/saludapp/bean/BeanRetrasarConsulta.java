package saludapp.bean;

import javax.faces.context.FacesContext;

import org.joda.time.LocalDate;

import saludapp.controlador.Controlador;
import saludapp.modelo.Medico;


public class BeanRetrasarConsulta {
	private BeanHoraDuracion beanHoraDuracion;

	public String retrasar() {
		// Obtenemos el m�dico logueado
		Medico m = (Medico) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("usuario");
		long medico = m.getId();

		// Los retrasos se establecen con respecto al d�a de hoy
		LocalDate dia = new LocalDate(System.currentTimeMillis());

		boolean resultado = Controlador.getUnicaInstancia().setRetrasoConsulta(
				medico, dia, beanHoraDuracion.getHoraInicio(),
				beanHoraDuracion.getMinutoInicio(),
				beanHoraDuracion.getDuracion());

		if (resultado)
			return "ok";
		return "fallo";
	}

	public BeanHoraDuracion getBeanHoraDuracion() {
		return beanHoraDuracion;
	}

	public void setBeanHoraDuracion(BeanHoraDuracion beanHoraDuracion) {
		this.beanHoraDuracion = beanHoraDuracion;
	}	
	
}
