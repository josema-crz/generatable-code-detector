package saludapp.bean;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.naming.NamingException;

import saludapp.jms.BuzonSugerencias;

public class BeanSugerencia {
	private String texto;
	private Map<String, TextMessage> sugerenciasMap;
	private List<TextMessage> sugerencias = new LinkedList<TextMessage>();
	private List<TextMessage> reenviadas;

	private HtmlCommandButton botonEnviar;

	public void enviar(ActionEvent ae) {
		FacesMessage message;
		try {
			BuzonSugerencias.enviar(texto);

			message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"enviarSugerenciaOk"));

		} catch (NamingException e) {
			message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"enviarSugerenciaFallo"));
			e.printStackTrace();
		} catch (JMSException e) {
			message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"enviarSugerenciaFallo"));
			e.printStackTrace();
		}

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(botonEnviar.getClientId(context), message);

		texto = "";
	}

	public void verSugerencias(ActionEvent event) {
		sugerenciasMap = new LinkedHashMap<String, TextMessage>();
		reenviadas = new LinkedList<TextMessage>();
		try {
			List<TextMessage> recibidos = BuzonSugerencias.recibirTodas();

			for (TextMessage m : recibidos)
				sugerenciasMap.put(m.getJMSMessageID(), m);

		} catch (NamingException e) {
			e.printStackTrace();
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	public void reenviar(ActionEvent event) {
		// Obtenemos la sugerencia
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("sugerenciaId");
		String sugerenciaId = component.getValue().toString();
		TextMessage sugerencia = sugerenciasMap.get(sugerenciaId);

		try {
			// S�lo permitimos un reenv�o
			if (!reenviadas.contains(sugerencia)) {
				// La reenviamos
				BuzonSugerencias.enviar(sugerencia.getText());

				// La guardamos en el conjunto de reenviadas
				reenviadas.add(sugerencia);
			}

		} catch (JMSException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public List<TextMessage> getSugerencias() {
		sugerencias = new LinkedList<TextMessage>(sugerenciasMap.values());
		return sugerencias;
	}

	public void setSugerencias(List<TextMessage> sugerencias) {
		this.sugerencias = sugerencias;
	}

	public HtmlCommandButton getBotonEnviar() {
		return botonEnviar;
	}

	public void setBotonEnviar(HtmlCommandButton botonEnviar) {
		this.botonEnviar = botonEnviar;
	}

	public Map<String, TextMessage> getSugerenciasMap() {
		return sugerenciasMap;
	}

	public void setSugerenciasMap(Map<String, TextMessage> sugerenciasMap) {
		this.sugerenciasMap = sugerenciasMap;
	}

	public List<TextMessage> getReenviadas() {
		return reenviadas;
	}

	public void setReenviadas(List<TextMessage> reenviadas) {
		this.reenviadas = reenviadas;
	}
	
	
}

