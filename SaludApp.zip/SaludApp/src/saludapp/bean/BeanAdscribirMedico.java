package saludapp.bean;

import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import javax.faces.application.FacesMessage;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.component.html.HtmlSelectOneListbox;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import saludapp.controlador.Controlador;
import saludapp.modelo.Medico;
import saludapp.modelo.Paciente;

public class BeanAdscribirMedico {
	private Long paciente;
	private Long medico;

	private HtmlCommandButton botonAdscribir;
	private HtmlSelectOneListbox listBox;

	// Nombres mostrados al usuario
	private Map<String, Long> pacientes;
	private Map<String, Long> medicos;

	{
		// Inicializamos la lista de m�dicos (vac�a)
		medicos = new TreeMap<String, Long>();
		// Mostramos un mensaje en la lista
		medicos.put(ResourceBundle.getBundle("saludapp.resource.saludapp")
				.getString("noMedicosDisponibles"), null);
	}

	public void adscribir(ActionEvent ae) {
		// Hacemos la llamada al controlador
		int res = Controlador.getUnicaInstancia().adscribirPaciente(paciente,
				medico);

		// Si hubo error mostramos un mensaje
		if (res != 0) {
			FacesMessage message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString("errorAdscripcion"));
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(botonAdscribir.getClientId(context), message);
		} else		
		// Actualizamos los m�dicos tras la adscripci�n
		actualizarMedicos(null);
	}

	public void actualizarMedicos(ActionEvent ae) {
		Long paciente = (Long) listBox.getValue();

		medicos = new TreeMap<String, Long>();

		// Obtenemos los m�dicos del paciente seleccionado y los metemos en la
		// lista
		List<Medico> ms = Controlador.getUnicaInstancia()
				.getMedicosDisponibles(paciente);

		// No hay m�dicos
		if (ms.isEmpty()) {
			// Mostramos un mensaje en la lista
			medicos.put(ResourceBundle.getBundle("saludapp.resource.saludapp")
					.getString("noMedicosDisponibles"), null);
		} else {
			for (Medico m : ms)
				medicos.put(m.getApellidos() + ", " + m.getNombre(), m.getId());
		}
	}

	public Long getPaciente() {
		return paciente;
	}

	public void setPaciente(Long paciente) {
		this.paciente = paciente;
	}

	public Long getMedico() {
		return medico;
	}

	public void setMedico(Long medico) {
		this.medico = medico;
	}

	public Map<String, Long> getPacientes() {
		pacientes = new TreeMap<String, Long>();

		// Obtenemos los pacientes y los metemos en la lista
		List<Paciente> ps;
		ps = Controlador.getUnicaInstancia().getPacientes();

		// No hay pacientes
		if (ps.isEmpty()) {
			// Mostramos un mensaje en la lista
			pacientes.put(
					ResourceBundle.getBundle("saludapp.resource.saludapp")
							.getString("noPacientes"), null);
		} else
			for (Paciente p : ps)
				pacientes.put(p.getApellidos() + ", " + p.getNombre(),
						p.getId());

		return pacientes;
	}

	public void setPacientes(Map<String, Long> pacientes) {
		this.pacientes = pacientes;
	}

	public Map<String, Long> getMedicos() {
		return medicos;
	}

	public void setMedicos(Map<String, Long> medicos) {
		this.medicos = medicos;
	}

	public HtmlCommandButton getBotonAdscribir() {
		return botonAdscribir;
	}

	public void setBotonAdscribir(HtmlCommandButton botonAdscribir) {
		this.botonAdscribir = botonAdscribir;
	}

	public HtmlSelectOneListbox getListBox() {
		return listBox;
	}

	public void setListBox(HtmlSelectOneListbox listBox) {
		this.listBox = listBox;
	}

}
