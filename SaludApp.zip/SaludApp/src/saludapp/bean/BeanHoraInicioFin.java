package saludapp.bean;

import java.util.LinkedList;
import java.util.List;

import saludapp.modelo.HorarioConsulta;
import saludapp.modelo.IntervaloHorario;

public class BeanHoraInicioFin {
	private Integer horaInicio;
	private Integer minutoInicio;
	private Integer horaFin;
	private Integer minutoFin;
	
	private List<Integer> horas;
	private List<Integer> minutos;
	
	{
		horas = new LinkedList<Integer>();
		minutos = new LinkedList<Integer>();
		
		// Obtenemos todas las horas posibles y las metemos en la lista
		IntervaloHorario iTotal = HorarioConsulta.getIntervaloTotal();
		int hInicio = iTotal.getHoraInicio().getHourOfDay();
		int hFin = iTotal.getHoraFin().getHourOfDay();
		
		int hora;
		for(hora=hInicio; hora<=hFin; hora++)
			horas.add(hora);
		
		// Metemos todos los minutos posibles dentro de una hora (de 5 en 5)
		int minuto;
		for(minuto=0; minuto<60; minuto+=5)
			minutos.add(minuto);
	}

	public Integer getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Integer horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Integer getMinutoInicio() {
		return minutoInicio;
	}

	public void setMinutoInicio(Integer minutoInicio) {
		this.minutoInicio = minutoInicio;
	}

	public Integer getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Integer horaFin) {
		this.horaFin = horaFin;
	}

	public Integer getMinutoFin() {
		return minutoFin;
	}

	public void setMinutoFin(Integer minutoFin) {
		this.minutoFin = minutoFin;
	}

	public List<Integer> getHoras() {
		return horas;
	}

	public void setHoras(List<Integer> horas) {
		this.horas = horas;
	}

	public List<Integer> getMinutos() {
		return minutos;
	}

	public void setMinutos(List<Integer> minutos) {
		this.minutos = minutos;
	}
	
	
}
