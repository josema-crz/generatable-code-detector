package saludapp.bean;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.event.ActionEvent;

import saludapp.controlador.Controlador;
import saludapp.modelo.SolicitudCambioMedico;

public class BeanResolverSolicitud {
	private Long solicitud;
	private String paciente;
	private String nuevoMedico;
	private Integer cupoNuevoMedico;
	private String motivoCambio;

	private HtmlPanelGrid panelDetalles;
	private HtmlOutputText msgFinal;

	private List<String> solicitudes;
	// Colecci�n adicional para tener todas las solicitudes indexadas por su id
	private Map<Long, SolicitudCambioMedico> objetosSolicitud;


	public void verDetalles(ActionEvent event) {
		// Obtenemos la solicitud seleccionada
		SolicitudCambioMedico solicitudSeleccionada = objetosSolicitud
				.get(solicitud);

		paciente = solicitudSeleccionada.getPaciente().getApellidos() + ", "
				+ solicitudSeleccionada.getPaciente().getNombre();
		nuevoMedico = solicitudSeleccionada.getNuevoMedico().getApellidos()
				+ ", " + solicitudSeleccionada.getNuevoMedico().getNombre();
		cupoNuevoMedico = solicitudSeleccionada.getNuevoMedico()
				.getCupoPacientes();
		motivoCambio = solicitudSeleccionada.getMotivoCambio();

		// Mostramos el panel
		panelDetalles.setRendered(true);

		msgFinal.setRendered(false); // Escondemos el mensaje si lo hab�a
	}

	public void aceptar(ActionEvent event) {
		if (solicitud != null) {
			SolicitudCambioMedico s = Controlador.getUnicaInstancia()
					.resolverSolicitudCambioMedico(solicitud, true);

			// Escondemos el panel y mostramos un mensaje informativo
			panelDetalles.setRendered(false);

			String value = "";
			if (s == null)
				value = ResourceBundle.getBundle("saludapp.resource.saludapp")
						.getString("resolverSolicitudError");
			else
				value = ResourceBundle.getBundle("saludapp.resource.saludapp")
						.getString("resolverSolicitudAceptada");

			msgFinal.setValue(value);
			msgFinal.setRendered(true);
		}
	}

	public void denegar(ActionEvent event) {
		if (solicitud != null) {
			SolicitudCambioMedico s = Controlador.getUnicaInstancia()
					.resolverSolicitudCambioMedico(solicitud, false);

			// Escondemos el panel y mostramos un mensaje informativo
			panelDetalles.setRendered(false);

			String value = "";
			if (s == null)
				value = ResourceBundle.getBundle("saludapp.resource.saludapp")
						.getString("resolverSolicitudError");
			else
				value = ResourceBundle.getBundle("saludapp.resource.saludapp")
						.getString("resolverSolicitudDenegada");

			msgFinal.setValue(value);
			msgFinal.setRendered(true);
		}
	}

	public Long getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(Long solicitud) {
		this.solicitud = solicitud;
	}

	public String getPaciente() {
		return paciente;
	}

	public void setPaciente(String paciente) {
		this.paciente = paciente;
	}

	public String getNuevoMedico() {
		return nuevoMedico;
	}

	public void setNuevoMedico(String nuevoMedico) {
		this.nuevoMedico = nuevoMedico;
	}

	public Integer getCupoNuevoMedico() {
		return cupoNuevoMedico;
	}

	public void setCupoNuevoMedico(Integer cupoNuevoMedico) {
		this.cupoNuevoMedico = cupoNuevoMedico;
	}

	public String getMotivoCambio() {
		return motivoCambio;
	}

	public void setMotivoCambio(String motivoCambio) {
		this.motivoCambio = motivoCambio;
	}

	public HtmlPanelGrid getPanelDetalles() {
		return panelDetalles;
	}

	public void setPanelDetalles(HtmlPanelGrid panelDetalles) {
		this.panelDetalles = panelDetalles;
	}

	public HtmlOutputText getMsgFinal() {
		return msgFinal;
	}

	public void setMsgFinal(HtmlOutputText msgFinal) {
		this.msgFinal = msgFinal;
	}

	public List<String> getSolicitudes() {
		objetosSolicitud = new LinkedHashMap<Long, SolicitudCambioMedico>();
		solicitudes = new LinkedList<String>();

		List<SolicitudCambioMedico> ss = Controlador.getUnicaInstancia()
				.getSolicitudesCambioMedicoPendientes();

		// No hay solicitudes
		if (ss.isEmpty()) {
			// Mostramos un mensaje en el men�
			solicitudes.add(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"noSolicitudesPendientes"));
		} else {
			// Rellenamos la lista con los ids de las solicitudes
			// Aprovechamos que hemos tra�do todas las solicitudes de base de
			// datos y las almacenamos en una colecci�n indexadas por su id
			for (SolicitudCambioMedico s : ss) {
				solicitudes.add(String.valueOf(s.getId()));
				objetosSolicitud.put(s.getId(), s);
			}
		}
		
		return solicitudes;
	}

	public void setSolicitudes(List<String> solicitudes) {
		this.solicitudes = solicitudes;
	}	
}
