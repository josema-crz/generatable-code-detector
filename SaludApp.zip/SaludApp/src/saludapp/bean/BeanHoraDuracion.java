package saludapp.bean;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.joda.time.Duration;

import saludapp.modelo.Cita;
import saludapp.modelo.HorarioConsulta;
import saludapp.modelo.IntervaloHorario;

public class BeanHoraDuracion {
	private static final Duration duracionMin = Duration.standardMinutes(5);
	private static final Duration duracionMax = Duration.standardMinutes(180);

	private int horaInicio;
	private int minutoInicio;
	private Duration duracion;

	private List<Integer> horas;
	private List<Integer> minutos;
	private Map<String, Duration> duraciones;

	// Aqu� van las inicializaciones de las listas de horas y minutos, que son
	// siempre iguales.
	// Las duraciones se generaran cada vez que se pida pues dependen de
	// duracionMin y duracionMax que pueden cambiar en cualquier momento.
	{
		horas = new LinkedList<Integer>();
		minutos = new LinkedList<Integer>();

		// Obtenemos todas las horas posibles y las metemos en la lista
		IntervaloHorario iTotal = HorarioConsulta.getIntervaloTotal();
		int hInicio = iTotal.getHoraInicio().getHourOfDay();
		int hFin = iTotal.getHoraFin().getHourOfDay();

		int hora;
		for (hora = hInicio; hora <= hFin; hora++)
			horas.add(hora);

		// Metemos todos los minutos posibles dentro de una hora (de 5 en 5)
		int minuto;
		for (minuto = 0; minuto < 60; minuto += 5)
			minutos.add(minuto);

		// Establecemos la duraci�n por defecto
		duracion = Cita.getDuracionPorDefecto();
	}

	public int getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(int horaInicio) {
		this.horaInicio = horaInicio;
	}

	public int getMinutoInicio() {
		return minutoInicio;
	}

	public void setMinutoInicio(int minutoInicio) {
		this.minutoInicio = minutoInicio;
	}

	public Duration getDuracion() {
		return duracion;
	}

	public void setDuracion(Duration duracion) {
		this.duracion = duracion;
	}

	public List<Integer> getHoras() {
		return horas;
	}

	public void setHoras(List<Integer> horas) {
		this.horas = horas;
	}

	public List<Integer> getMinutos() {
		return minutos;
	}

	public void setMinutos(List<Integer> minutos) {
		this.minutos = minutos;
	}

	public Map<String, Duration> getDuraciones() {
		duraciones = new LinkedHashMap<String, Duration>();

		// Obtenemos las duraciones posibles
		Duration d;
		Integer duracion;
		Duration salto = Duration.standardMinutes(5);
		for (d = duracionMin; d.isShorterThan(duracionMax); d = d.plus(salto)) {
			duracion = (Integer)d.toStandardSeconds().toStandardMinutes().getMinutes();
			duraciones.put(duracion.toString(), d);
		}

		return duraciones;
	}

	public void setDuraciones(Map<String, Duration> duraciones) {
		this.duraciones = duraciones;
	}

}
