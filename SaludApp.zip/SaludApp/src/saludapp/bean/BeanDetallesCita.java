package saludapp.bean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.component.UIParameter;
import javax.faces.event.ActionEvent;

import saludapp.controlador.Controlador;
import saludapp.modelo.*;

public class BeanDetallesCita {
	private List<Sintoma> sintomas;
	private List<Diagnostico> diagnosticos;
	private List<Tratamiento> tratamientos;
	
	private Long cita;
	
	public void verDetallesCita(ActionEvent event) {
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("citaId");
		cita = Long.parseLong(component.getValue().toString());		
	}

	public List<Sintoma> getSintomas() {
		sintomas = new ArrayList<Sintoma>(Controlador.getUnicaInstancia().getSintomas(cita));
		return sintomas;
	}

	public void setSintomas(List<Sintoma> sintomas) {
		this.sintomas = sintomas;
	}

	public List<Diagnostico> getDiagnosticos() {
		diagnosticos = new ArrayList<Diagnostico>(Controlador.getUnicaInstancia().getDiagnosticos(cita));
		return diagnosticos;
	}

	public void setDiagnosticos(List<Diagnostico> diagnosticos) {
		this.diagnosticos = diagnosticos;
	}

	public List<Tratamiento> getTratamientos() {
		tratamientos = new ArrayList<Tratamiento>(Controlador.getUnicaInstancia().getTratamientos(cita));
		return tratamientos;
	}

	public void setTratamientos(List<Tratamiento> tratamientos) {
		this.tratamientos = tratamientos;
	}

	public Long getCita() {
		return cita;
	}

	public void setCita(Long cita) {
		this.cita = cita;
	}
	
	
}
