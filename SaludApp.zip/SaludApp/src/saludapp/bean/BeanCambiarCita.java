package saludapp.bean;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;

import saludapp.controlador.Controlador;
import saludapp.modelo.Cita;
import saludapp.modelo.Paciente;

public class BeanCambiarCita {
	private Long cita;
	private Map<String, Long> citas;
	
	private long paciente;

	private final String formatoHora = "HH:mm";

	{
		// Obtenemos el id del paciente
		Paciente p = (Paciente) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("usuario");
		paciente = p.getId();		
	}

	public Long getCita() {
		return cita;
	}

	public void setCita(Long cita) {
		this.cita = cita;
	}

	public Map<String, Long> getCitas() {
		citas = new LinkedHashMap<String, Long>();

		List<Cita> cs;
		cs = Controlador.getUnicaInstancia().getCitasActualesPaciente(paciente);

		// No hay citas
		if (cs.isEmpty()) {
			// Mostramos un mensaje en el men�
			citas.put(ResourceBundle.getBundle("saludapp.resource.saludapp")
					.getString("noCitas"), null);			
		} else {
			for (Cita c : cs)
				citas.put(c.getFecha()
						+ " "
						+ c.getIntervalo().getHoraInicio()
								.toString(formatoHora), c.getId());
		}
		
		return citas;
	}

	public void setCitas(Map<String, Long> citas) {
		this.citas = citas;
	}

	public long getPaciente() {
		return paciente;
	}

	public void setPaciente(long paciente) {
		this.paciente = paciente;
	}	
}
