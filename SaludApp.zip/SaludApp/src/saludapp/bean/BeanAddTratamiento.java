package saludapp.bean;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.joda.time.LocalDate;

import saludapp.controlador.Controlador;

public class BeanAddTratamiento {
	private String medicamento;
	private double cantidad;
	private double dosisDiaria;
	private LocalDate inicio;
	private LocalDate fin;

	private long cita;

	private HtmlCommandButton botonAdd;

	public void addTratamientoListener(ActionEvent event) {
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("citaId");
		cita = Long.parseLong(component.getValue().toString());
	}

	public void addTratamiento(ActionEvent event) {
		Object resultado = Controlador.getUnicaInstancia().addTratamiento(cita,
				medicamento, cantidad, dosisDiaria, inicio, fin);

		// Error: mostramos mensaje
		if (resultado == null) {
			FacesMessage message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"addTratamientoError"));
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(botonAdd.getClientId(context), message);
		}
		// �xito: reiniciamos campos
		else {
			medicamento = "";
			cantidad = 0;
			dosisDiaria = 0;
			inicio = new LocalDate();
			fin = new LocalDate();
		}
	}

	public String getMedicamento() {
		return medicamento;
	}

	public void setMedicamento(String medicamento) {
		this.medicamento = medicamento;
	}

	public double getCantidad() {
		return cantidad;
	}

	public void setCantidad(double cantidad) {
		this.cantidad = cantidad;
	}

	public double getDosisDiaria() {
		return dosisDiaria;
	}

	public void setDosisDiaria(double dosisDiaria) {
		this.dosisDiaria = dosisDiaria;
	}

	public LocalDate getInicio() {
		return inicio;
	}

	public void setInicio(LocalDate inicio) {
		this.inicio = inicio;
	}

	public LocalDate getFin() {
		return fin;
	}

	public void setFin(LocalDate fin) {
		this.fin = fin;
	}

	public long getCita() {
		return cita;
	}

	public void setCita(long cita) {
		this.cita = cita;
	}

	public HtmlCommandButton getBotonAdd() {
		return botonAdd;
	}

	public void setBotonAdd(HtmlCommandButton botonAdd) {
		this.botonAdd = botonAdd;
	}
	

}
