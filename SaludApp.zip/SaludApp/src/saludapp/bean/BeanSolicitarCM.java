package saludapp.bean;

import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import javax.faces.context.FacesContext;

import saludapp.controlador.Controlador;
import saludapp.modelo.Medico;
import saludapp.modelo.Usuario;

public class BeanSolicitarCM {
	private Long paciente;
	private Long nuevoMedico;
	private String motivoCambio;

	private Map<String, Long> medicos;

	{
		// Obtenemos el id del paciente logueado
		Usuario u = (Usuario) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("usuario");
		paciente = u.getId();
	}

	public String solicitar() {
		Object s = Controlador.getUnicaInstancia()
				.registrarSolicitudCambioMedico(paciente, nuevoMedico,
						motivoCambio);

		if (s == null)
			return "fallo";
		return "ok";
	}

	public Long getPaciente() {
		return paciente;
	}

	public void setPaciente(Long paciente) {
		this.paciente = paciente;
	}

	public Long getNuevoMedico() {
		return nuevoMedico;
	}

	public void setNuevoMedico(Long nuevoMedico) {
		this.nuevoMedico = nuevoMedico;
	}

	public String getMotivoCambio() {
		return motivoCambio;
	}

	public void setMotivoCambio(String motivoCambio) {
		this.motivoCambio = motivoCambio;
	}

	public Map<String, Long> getMedicos() {
		// El treemap mantendr� los elementos ordenados por su key
		medicos = new TreeMap<String, Long>();

		// Obtenemos los m�dicos disponibles
		List<Medico> ms = Controlador.getUnicaInstancia()
				.getMedicosDisponibles(paciente);		

		// No hay m�dicos
		if (ms.isEmpty()) {
			// Mostramos un mensaje en el men�
			medicos.put(ResourceBundle.getBundle("saludapp.resource.saludapp")
					.getString("noMedicosDisponibles"), null);
		} else {
			for (Medico m : ms)
				medicos.put(m.getApellidos() + ", " + m.getNombre(), m.getId());
		}
		
		return medicos;
	}

	public void setMedicos(Map<String, Long> medicos) {
		this.medicos = medicos;
	}

}
