package saludapp.bean;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import saludapp.controlador.Controlador;
import saludapp.modelo.ValoracionGravedad;

public class BeanAddSintoma {
	private String descripcion;
	private ValoracionGravedad valoracionGravedad;
	private long cita;

	private ValoracionGravedad[] valoracionesGravedad;

	private HtmlCommandButton botonAdd;

	public void addSintomaListener(ActionEvent event) {
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("citaId");
		cita = Long.parseLong(component.getValue().toString());
	}

	public void addSintoma(ActionEvent event) {
		Object resultado = Controlador.getUnicaInstancia().addSintoma(cita,
				descripcion, valoracionGravedad);

		// Error: mostramos mensaje
		if (resultado == null) {
			FacesMessage message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"addSintomaError"));
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(botonAdd.getClientId(context), message);
		}
		// �xito: reiniciamos campos
		else {
			descripcion = "";
		}
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}	

	public HtmlCommandButton getBotonAdd() {
		return botonAdd;
	}

	public void setBotonAdd(HtmlCommandButton botonAdd) {
		this.botonAdd = botonAdd;
	}

	public long getCita() {
		return cita;
	}

	public void setCita(long cita) {
		this.cita = cita;
	}

	public ValoracionGravedad getValoracionGravedad() {
		return valoracionGravedad;
	}

	public void setValoracionGravedad(ValoracionGravedad valoracionGravedad) {
		this.valoracionGravedad = valoracionGravedad;
	}

	public ValoracionGravedad[] getValoracionesGravedad() {
		valoracionesGravedad = ValoracionGravedad.values();
		return valoracionesGravedad;
	}

	public void setValoracionesGravedad(
			ValoracionGravedad[] valoracionesGravedad) {
		this.valoracionesGravedad = valoracionesGravedad;
	}

}
