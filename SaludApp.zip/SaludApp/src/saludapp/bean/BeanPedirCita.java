package saludapp.bean;

import java.util.Collections;
import java.util.List;

import javax.faces.component.UIParameter;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.joda.time.LocalDate;

import saludapp.controlador.Controlador;
import saludapp.modelo.Cita;
import saludapp.modelo.Paciente;

public class BeanPedirCita {
	private LocalDate dia;
	private Boolean mostrarPanelPedirCita;
	private Boolean mostrarPanelCita;
	private Boolean mostrarMsgNoAdscrito;

	private Long paciente;
	private Long adscrito;

	// Id de la cita a modificar o null si se crea una nueva cita
	private Long cita;

	private BeanHoraDuracion beanHoraDuracion;

	{
		// Obtenemos el paciente
		Paciente p = (Paciente) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("usuario");
		paciente = p.getId();
		// Obtenemos el id del m�dico adscrito al paciente logueado
		adscrito = (Long) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("adscrito");
	}

	public void verDisponibilidad(ActionEvent event) {
		// Actualizamos los intervalos
		IntervaloCincoMinutos.setIntervalos(adscrito, dia);
	}

	public String registrar() {
		Object resultado = Controlador.getUnicaInstancia().registrarCita(
				paciente, adscrito, cita, dia,
				beanHoraDuracion.getHoraInicio(),
				beanHoraDuracion.getMinutoInicio(),
				beanHoraDuracion.getDuracion());

		if (resultado == null)
			return "fallo";
		return "ok";
	}

	public void cambiarCitaListener(ActionEvent event) {
		// Cogemos el id de la cita que ser� modificada
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("idCita");
		cita = Long.parseLong(component.getValue().toString());

		// Inicializamos los intervalos
		IntervaloCincoMinutos.setIntervalos(adscrito, dia);

		// Mostramos el panel adecuado
		seleccionarPanel();
	}

	public void pedirCitaListener(ActionEvent event) {
		cita = null;

		// Inicializamos los intervalos
		IntervaloCincoMinutos.setIntervalos(adscrito, dia);

		// Mostramos el panel adecuado
		seleccionarPanel();
	}

	/**
	 * Selecciona el panel a mostrar al usuario seg�n la situaci�n: - El
	 * paciente no tiene ning�n m�dico adscrito - El paciente trata de pedir una
	 * cita nueva cuando ya tiene una o m�s pendientes - El paciente quiere
	 * pedir una cita nueva sin tener ninguna pendiente
	 */
	public void seleccionarPanel() {
		// Si no tiene m�dico adscrito, mostramos �nicamente un mensaje
		// comunicando el error
		if (adscrito == null) {
			mostrarMsgNoAdscrito = true;
			mostrarPanelCita = false;
			mostrarPanelPedirCita = false;
		} else {
			// Si estamos tratando de crear una cita nueva pero el paciente ya
			// tiene una, lo comunicamos y mostramos los datos de la cita actual
			// (la m�s reciente)
			List<Cita> citasActuales = Controlador.getUnicaInstancia()
					.getCitasActualesPaciente(paciente);
			if (cita == null && !citasActuales.isEmpty()) {
				Collections.sort(citasActuales);
				Cita c = citasActuales.get(0);
				dia = c.getFecha();
				beanHoraDuracion.setHoraInicio(c.getIntervalo().getHoraInicio()
						.getHourOfDay());
				beanHoraDuracion.setMinutoInicio(c.getIntervalo()
						.getHoraInicio().getMinuteOfHour());
				beanHoraDuracion.setDuracion(c.getIntervalo().getDuracion());

				mostrarMsgNoAdscrito = false;
				mostrarPanelCita = true;
				mostrarPanelPedirCita = false;

			} else {
				mostrarMsgNoAdscrito = false;
				mostrarPanelCita = false;
				mostrarPanelPedirCita = true;
			}
		}
	}

	public LocalDate getDia() {
		return dia;
	}

	public void setDia(LocalDate dia) {
		this.dia = dia;
	}

	public Boolean getMostrarPanelPedirCita() {
		return mostrarPanelPedirCita;
	}

	public void setMostrarPanelPedirCita(Boolean mostrarPanelPedirCita) {
		this.mostrarPanelPedirCita = mostrarPanelPedirCita;
	}

	public Boolean getMostrarPanelCita() {
		return mostrarPanelCita;
	}

	public void setMostrarPanelCita(Boolean mostrarPanelCita) {
		this.mostrarPanelCita = mostrarPanelCita;
	}

	public Long getCita() {
		return cita;
	}

	public void setCita(Long cita) {
		this.cita = cita;
	}

	public Boolean getMostrarMsgNoAdscrito() {
		return mostrarMsgNoAdscrito;
	}

	public void setMostrarMsgNoAdscrito(Boolean mostrarMsgNoAdscrito) {
		this.mostrarMsgNoAdscrito = mostrarMsgNoAdscrito;
	}

	public void setAdscrito(Long adscrito) {
		this.adscrito = adscrito;
	}

	public Long getAdscrito() {
		return adscrito;
	}

	public BeanHoraDuracion getBeanHoraDuracion() {
		return beanHoraDuracion;
	}

	public void setBeanHoraDuracion(BeanHoraDuracion beanHoraDuracion) {
		this.beanHoraDuracion = beanHoraDuracion;
	}

	public Long getPaciente() {
		return paciente;
	}

	public void setPaciente(Long paciente) {
		this.paciente = paciente;
	}

}
