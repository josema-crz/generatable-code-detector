package saludapp.bean;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.jms.JMSException;
import javax.naming.NamingException;

import saludapp.jms.Aviso;
import saludapp.jms.AvisosImportantesMedicoX;
import saludapp.modelo.Usuario;

public class BeanAvisosMedico {
	private String asunto;
	private String texto;
	private String fecha;
	private Map<String, Aviso> avisosMap = new LinkedHashMap<String, Aviso>();
	private List<Aviso> avisos; // Colecci�n recorrida en la datatable

	private Aviso aviso;

	private Long usuario;

	private HtmlCommandButton botonEnviar;

	{
		// Obtenemos el id del usuario logueado (paciente o m�dico)
		Usuario u = (Usuario) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("usuario");
		usuario = u.getId();
	}

	public void enviarTexto(ActionEvent event) {
		FacesMessage message;
		try {
			// Enviamos el aviso (lo ejecutar� el m�dico)
			AvisosImportantesMedicoX.getUnicaInstancia().enviar(asunto, texto,
					usuario.toString());
			
			message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString("enviarAvisoMedicoOk"));
			
		} catch (Exception e) {
			message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"enviarAvisoMedicoFallo"));
			e.printStackTrace();
		}		
		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage(botonEnviar.getClientId(context), message);

		texto = "";
		asunto = "";
	}

	public void verAvisos(ActionEvent event) {
		// Obtenemos el id del m�dico adscrito al paciente logueado
		Long adscrito = (Long) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("adscrito");

		if (adscrito != null) {
			try {
				// Recibimos los avisos (lo ejecutar� el paciente)
				AvisosImportantesMedicoX.getUnicaInstancia().registrarApartado(
						usuario.toString(), adscrito.toString());
			} catch (NamingException e) {
				e.printStackTrace();
			} catch (JMSException e) {
				e.printStackTrace();
			}
		}
	}

	public void verAviso(ActionEvent event) {
		// Obtenemos el aviso en cuesti�n
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("avisoId");
		String avisoId = component.getValue().toString();
		aviso = avisosMap.get(avisoId);

		// Mostramos la info
		fecha = aviso.getFecha();
		asunto = aviso.getAsunto();
		texto = aviso.getTexto();
	}

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Long getUsuario() {
		return usuario;
	}

	public void setUsuario(Long usuario) {
		this.usuario = usuario;
	}

	public HtmlCommandButton getBotonEnviar() {
		return botonEnviar;
	}

	public void setBotonEnviar(HtmlCommandButton botonEnviar) {
		this.botonEnviar = botonEnviar;
	}

	public Map<String, Aviso> getAvisosMap() {
		return avisosMap;
	}

	public void setAvisosMap(Map<String, Aviso> avisosMap) {
		this.avisosMap = avisosMap;
	}

	public List<Aviso> getAvisos() {
		avisos = new LinkedList<Aviso>(avisosMap.values());
		return avisos;
	}

	public void setAvisos(List<Aviso> avisos) {
		this.avisos = avisos;
	}

	public Aviso getAviso() {
		return aviso;
	}

	public void setAviso(Aviso aviso) {
		this.aviso = aviso;
	}

}
