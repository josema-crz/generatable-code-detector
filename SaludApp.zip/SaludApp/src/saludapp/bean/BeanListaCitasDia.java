package saludapp.bean;

import java.util.List;

import javax.faces.context.FacesContext;

import org.joda.time.LocalDate;

import saludapp.controlador.Controlador;
import saludapp.modelo.Cita;
import saludapp.modelo.Medico;

public class BeanListaCitasDia {
	private List<Cita> citas;
	private long medico;

	{
		// Obtenemos el m�dico logueado
		Medico m = (Medico) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("usuario");
		medico = m.getId();
	}

	public List<Cita> getCitas() {
		citas = Controlador.getUnicaInstancia().getCitasDia(medico,
				new LocalDate(System.currentTimeMillis()));
		return citas;
	}

	public void setCitas(List<Cita> citas) {
		this.citas = citas;
	}

	public long getMedico() {
		return medico;
	}

	public void setMedico(long medico) {
		this.medico = medico;
	}

	
}
