package saludapp.bean;


import javax.faces.component.UIParameter;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.joda.time.LocalDate;

import saludapp.controlador.Controlador;
import saludapp.modelo.Medico;


public class BeanPedirCitaRevision {
	private LocalDate dia;
	private String motivoRevision;

	private Long cita;
	private Long medico;

	private BeanHoraDuracion beanHoraDuracion;

	{
		// Obtenemos el m�dico
		Medico m = (Medico) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("usuario");
		medico = m.getId();
	}

	public void verDisponibilidad(ActionEvent event) {
		// Actualizamos los intervalos
		IntervaloCincoMinutos.setIntervalos(medico, dia);
	}

	public String registrar() {
		Object resultado = Controlador.getUnicaInstancia()
				.registrarCitaRevision(medico, cita, dia,
						beanHoraDuracion.getHoraInicio(),
						beanHoraDuracion.getMinutoInicio(),
						beanHoraDuracion.getDuracion(), motivoRevision);

		if (resultado == null)
			return "fallo";
		return "ok";
	}

	public void pedirCitaRevisionListener(ActionEvent event) {
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("citaId");
		cita = Long.parseLong(component.getValue().toString());

		// Inicializamos los intervalos
		IntervaloCincoMinutos.setIntervalos(medico, null);
	}
	

	public LocalDate getDia() {
		return dia;
	}

	public void setDia(LocalDate dia) {
		this.dia = dia;
	}

	public String getMotivoRevision() {
		return motivoRevision;
	}

	public void setMotivoRevision(String motivoRevision) {
		this.motivoRevision = motivoRevision;
	}

	public Long getCita() {
		return cita;
	}

	public void setCita(Long cita) {
		this.cita = cita;
	}

	public Long getMedico() {
		return medico;
	}

	public void setMedico(Long medico) {
		this.medico = medico;
	}

	public BeanHoraDuracion getBeanHoraDuracion() {
		return beanHoraDuracion;
	}

	public void setBeanHoraDuracion(BeanHoraDuracion beanHoraDuracion) {
		this.beanHoraDuracion = beanHoraDuracion;
	}

}
