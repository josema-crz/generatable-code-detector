package saludapp.bean;

import saludapp.controlador.Controlador;

public class BeanRegistroCM {
	private String nombre;
	private String direccion;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	public String registrar() {
		Object cm = Controlador.getUnicaInstancia().registrarCentroMedico(nombre, direccion);
		
		if (cm == null) return "fallo";
		return "ok";
	}
}
