package saludapp.bean;

import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlInputSecret;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import saludapp.controlador.Controlador;
import saludapp.modelo.CentroMedico;
import saludapp.modelo.FormaNotificacion;

public class BeanRegistroPaciente {
	private String nombre;
	private String apellidos;
	private String nombreUsuario;
	private String clave;
	private String clave2;
	private String nss;
	private String numTarjeta;
	private String telefono;
	private String movil;
	private String direccion;
	private String mail;
	private FormaNotificacion formaNotificacion;
	private long centroMedico;

	private Map<String, Long> centrosMedicos;

	private HtmlInputSecret inputClave;

	private FormaNotificacion[] formasNotificacion;

	public String registrar() {
		Object p = Controlador.getUnicaInstancia().registrarPaciente(nombre,
				apellidos, nombreUsuario, clave, nss, numTarjeta, telefono,
				movil, direccion, mail, formaNotificacion, centroMedico);

		if (p == null)
			return "fallo";
		return "ok";
	}

	public void validarClave2(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ValidatorException {
		if (!((String) arg2).equals(inputClave.getValue()))
			throw new ValidatorException(new FacesMessage(ResourceBundle
					.getBundle("saludapp.resource.saludapp").getString(
							"errorClave2")));
	}

	public void validarMail(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ValidatorException {
		Pattern p = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
				Pattern.CASE_INSENSITIVE);
		Matcher matcher = p.matcher((String) arg2);
		
		if (!matcher.find())
			throw new ValidatorException(new FacesMessage(ResourceBundle
					.getBundle("saludapp.resource.saludapp").getString(
							"errorFormatoEmail")));
	}

	public String getNss() {
		return nss;
	}

	public void setNss(String nss) {
		this.nss = nss;
	}

	public String getNumTarjeta() {
		return numTarjeta;
	}

	public void setNumTarjeta(String numTarjeta) {
		this.numTarjeta = numTarjeta;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getMovil() {
		return movil;
	}

	public void setMovil(String movil) {
		this.movil = movil;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getClave2() {
		return clave2;
	}

	public void setClave2(String clave2) {
		this.clave2 = clave2;
	}

	public long getCentroMedico() {
		return centroMedico;
	}

	public void setCentroMedico(long centroMedico) {
		this.centroMedico = centroMedico;
	}

	public Map<String, Long> getCentrosMedicos() {
		// Obtenemos los centros m�dicos y metemos sus nombres indexados por su
		// id
		centrosMedicos = new TreeMap<String, Long>();

		List<CentroMedico> cms;
		cms = Controlador.getUnicaInstancia().getCentrosMedicos();

		// No hay centros m�dicos
		if (cms.isEmpty()) {
			// Mostramos un mensaje en el men�
			centrosMedicos.put(
					ResourceBundle.getBundle("saludapp.resource.saludapp")
							.getString("noCentrosMedicos"), null);
		} else
			for (CentroMedico cm : cms)
				centrosMedicos.put(cm.getNombre(), cm.getId());

		return centrosMedicos;
	}

	public void setCentrosMedicos(Map<String, Long> centrosMedicos) {
		this.centrosMedicos = centrosMedicos;
	}

	public FormaNotificacion getFormaNotificacion() {
		return formaNotificacion;
	}

	public void setFormaNotificacion(FormaNotificacion formaNotificacion) {
		this.formaNotificacion = formaNotificacion;
	}

	public FormaNotificacion[] getFormasNotificacion() {
		formasNotificacion = FormaNotificacion.values();
		return formasNotificacion;
	}

	public void setFormasNotificacion(FormaNotificacion[] formasNotificacion) {
		this.formasNotificacion = formasNotificacion;
	}

	public HtmlInputSecret getInputClave() {
		return inputClave;
	}

	public void setInputClave(HtmlInputSecret inputClave) {
		this.inputClave = inputClave;
	}

}
