package saludapp.bean;

import java.util.LinkedList;
import java.util.List;

import javax.faces.context.FacesContext;

import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.controlador.Controlador;
import saludapp.modelo.EstadoIntervalo;
import saludapp.modelo.HorarioConsulta;
import saludapp.modelo.IntervaloHorario;

/**
 * Representa un intervalo de cinco minutos, utilizado para la representaci�n de
 * intervalos en la interfaz
 * 
 */
public class IntervaloCincoMinutos {
	public String estilo;
	public String title;

	public IntervaloCincoMinutos(String estilo, String title) {
		this.estilo = estilo;
		this.title = title;
	}

	public String getEstilo() {
		return estilo;
	}

	public void setEstilo(String estilo) {
		this.estilo = estilo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Obtiene los intervalos de cinco minutos y los mete en la petici�n
	 * 
	 * @param medico
	 * @return
	 */
	public static List<IntervaloCincoMinutos> setIntervalos(Long medico,
			LocalDate dia) {
		List<IntervaloCincoMinutos> intervalosTotal = new LinkedList<IntervaloCincoMinutos>();

		if (medico != null) {
			String formatoHora = "HH:mm";

			// Obtenemos el rango total de horas posibles
			IntervaloHorario iTotal = HorarioConsulta.getIntervaloTotal();

			// Obtenemos todos los IntervaloHorario de cinco minutos
			List<IntervaloHorario> intervalos = new LinkedList<IntervaloHorario>();
			IntervaloHorario i;
			LocalTime hora = iTotal.getHoraInicio();
			while (hora.isBefore(iTotal.getHoraFin())) {
				i = new IntervaloHorario(hora, hora.plusMinutes(5));
				intervalos.add(i);
				hora = hora.plusMinutes(5);
			}

			// Obtenemos sus estados
			List<EstadoIntervalo> estados = Controlador.getUnicaInstancia()
					.getEstadosIntervalos(medico, intervalos, dia);

			// Creamos los IntervaloCincoMinutos
			hora = iTotal.getHoraInicio();
			for (EstadoIntervalo estado : estados) {
				// La clase css tendr� el nombre intervaloestado
				String e = "intervalo" + estado.toString().toLowerCase();

				intervalosTotal.add(new IntervaloCincoMinutos(e, hora
						.toString(formatoHora)));

				hora = hora.plusMinutes(5);
			}

			// Separamos en dos listas
			List<IntervaloCincoMinutos> intervalos1 = intervalosTotal.subList(
					0, intervalosTotal.size() / 2);
			List<IntervaloCincoMinutos> intervalos2 = intervalosTotal.subList(
					intervalosTotal.size() / 2, intervalosTotal.size());

			// Pasamos las colecciones a la p�gina JSP. Patr�n
			// "Service to Worker"
			FacesContext.getCurrentInstance().getExternalContext()
					.getSessionMap().put("intervalos1", intervalos1);
			FacesContext.getCurrentInstance().getExternalContext()
					.getSessionMap().put("intervalos2", intervalos2);
		}

		return intervalosTotal;
	}
}