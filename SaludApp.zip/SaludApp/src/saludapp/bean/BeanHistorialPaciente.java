package saludapp.bean;

import java.util.List;

import javax.faces.component.UIParameter;
import javax.faces.event.ActionEvent;


import saludapp.controlador.Controlador;
import saludapp.modelo.Cita;

public class BeanHistorialPaciente {
	private List<Cita> citas;
	private Long paciente;
	private Long cita;

	public List<Cita> getCitas() {
		citas = Controlador.getUnicaInstancia().getHistorialPaciente(paciente);
		return citas;
	}

	public void setCitas(List<Cita> citas) {
		this.citas = citas;
	}

	public void historialPacienteListener(ActionEvent event) {
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("pacienteId");
		paciente = Long.parseLong(component.getValue().toString());	
		
		component = (UIParameter) event.getComponent()
				.findComponent("citaId");
		cita = Long.parseLong(component.getValue().toString());	
	}

	public Long getPaciente() {
		return paciente;
	}

	public void setPaciente(Long paciente) {
		this.paciente = paciente;
	}

	public Long getCita() {
		return cita;
	}

	public void setCita(Long cita) {
		this.cita = cita;
	}	
	
	
}
