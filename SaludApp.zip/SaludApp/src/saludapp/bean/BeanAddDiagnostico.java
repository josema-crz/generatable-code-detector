package saludapp.bean;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import saludapp.controlador.Controlador;

public class BeanAddDiagnostico {
	private String enfermedad;
	private Boolean hospitalizacion;
	
	private long cita;
	
	private HtmlCommandButton botonAdd;
	
	public void addDiagnosticoListener(ActionEvent event) {
		UIParameter component = (UIParameter) event.getComponent()
				.findComponent("citaId");
		cita = Long.parseLong(component.getValue().toString());		
	}

	public void addDiagnostico(ActionEvent event) {
		Object resultado = Controlador.getUnicaInstancia().addDiagnostico(cita,
				enfermedad, hospitalizacion);
		
		// Error: mostramos mensaje
		if (resultado == null) {
			FacesMessage message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString("addDiagnosticoError"));
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(botonAdd.getClientId(context), message);
		}
		// �xito: reiniciamos campos
		else {
			enfermedad = "";
			hospitalizacion = null;
		}		
	}

	public String getEnfermedad() {
		return enfermedad;
	}

	public void setEnfermedad(String enfermedad) {
		this.enfermedad = enfermedad;
	}

	public Boolean getHospitalizacion() {
		return hospitalizacion;
	}

	public void setHospitalizacion(Boolean hospitalizacion) {
		this.hospitalizacion = hospitalizacion;
	}

	public long getCita() {
		return cita;
	}

	public void setCita(long cita) {
		this.cita = cita;
	}

	public HtmlCommandButton getBotonAdd() {
		return botonAdd;
	}

	public void setBotonAdd(HtmlCommandButton botonAdd) {
		this.botonAdd = botonAdd;
	}

	
	
	
}
