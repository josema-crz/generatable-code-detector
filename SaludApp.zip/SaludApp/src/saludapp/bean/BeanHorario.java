package saludapp.bean;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import saludapp.controlador.Controlador;
import saludapp.modelo.HorarioConsulta;
import saludapp.modelo.Usuario;

public class BeanHorario {
	private int minimoMinutos;
	private int totalMinutos;
	private String estiloTotalMinutos;

	private long medico;

	private HtmlCommandButton botonAdd;
	private HtmlCommandButton botonRemove;
	private HtmlCommandButton botonRemoveTodos;

	private BeanHoraInicioFin beanHoraInicioFin;

	{
		// Obtenemos el id del m�dico logueado
		Usuario u = (Usuario) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("usuario");
		medico = u.getId();

		// Inicializamos minimo de minutos
		minimoMinutos = HorarioConsulta.MINIMO_HORAS_CONSULTA * 60;
	}

	public void addIntervalo(ActionEvent event) {
		Object resultado = Controlador.getUnicaInstancia()
				.addIntervaloHorarioConsulta(medico,
						beanHoraInicioFin.getHoraInicio(),
						beanHoraInicioFin.getMinutoInicio(),
						beanHoraInicioFin.getHoraFin(),
						beanHoraInicioFin.getMinutoFin());

		// Intervalo no a�adido
		if (resultado == null) {
			FacesMessage message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"a�adirIntervaloError"));
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(botonAdd.getClientId(context), message);
		}

		// Actualizamos la tabla de intervalos de cinco minutos
		IntervaloCincoMinutos.setIntervalos(medico, null);

	}

	public void removeIntervalo(ActionEvent event) {
		Object resultado = Controlador.getUnicaInstancia()
				.removeIntervaloHorarioConsulta(medico,
						beanHoraInicioFin.getHoraInicio(),
						beanHoraInicioFin.getMinutoInicio(),
						beanHoraInicioFin.getHoraFin(),
						beanHoraInicioFin.getMinutoFin());

		// Intervalo no eliminado
		if (resultado == null) {
			FacesMessage message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"eliminarIntervaloError"));
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(botonRemove.getClientId(context), message);
		}

		// Actualizamos la tabla de intervalos de cinco minutos
		IntervaloCincoMinutos.setIntervalos(medico, null);
	}

	public void removeIntervalos(ActionEvent event) {
		boolean resultado = Controlador.getUnicaInstancia()
				.removeIntervalosHorarioConsulta(medico);

		// Alg�n intervalo no eliminado
		if (resultado == false) {
			FacesMessage message = new FacesMessage(ResourceBundle.getBundle(
					"saludapp.resource.saludapp").getString(
					"eliminarIntervalosError"));
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(botonRemoveTodos.getClientId(context), message);
		}

		// Actualizamos la tabla de intervalos de cinco minutos
		IntervaloCincoMinutos.setIntervalos(medico, null);
	}

	public void establecerHorarioListener(ActionEvent event) {
		// Inicializamos tabla de intervalos
		IntervaloCincoMinutos.setIntervalos(medico, null);
	}

	public int getMinimoMinutos() {
		return minimoMinutos;
	}

	public void setMinimoMinutos(int minimoMinutos) {
		this.minimoMinutos = minimoMinutos;
	}

	public int getTotalMinutos() {
		totalMinutos = Controlador.getUnicaInstancia()
				.getTotalMinutosHorarioConsulta(medico);
		return totalMinutos;
	}

	public void setTotalMinutos(int totalMinutos) {
		this.totalMinutos = totalMinutos;
	}

	public BeanHoraInicioFin getBeanHoraInicioFin() {
		return beanHoraInicioFin;
	}

	public void setBeanHoraInicioFin(BeanHoraInicioFin beanHoraInicioFin) {
		this.beanHoraInicioFin = beanHoraInicioFin;
	}

	public String getEstiloTotalMinutos() {
		return estiloTotalMinutos;
	}

	public void setEstiloTotalMinutos(String estiloTotalMinutos) {
		this.estiloTotalMinutos = estiloTotalMinutos;
	}

	public long getMedico() {
		return medico;
	}

	public void setMedico(long medico) {
		this.medico = medico;
	}

	public HtmlCommandButton getBotonAdd() {
		return botonAdd;
	}

	public void setBotonAdd(HtmlCommandButton botonAdd) {
		this.botonAdd = botonAdd;
	}

	public HtmlCommandButton getBotonRemove() {
		return botonRemove;
	}

	public void setBotonRemove(HtmlCommandButton botonRemove) {
		this.botonRemove = botonRemove;
	}

	public HtmlCommandButton getBotonRemoveTodos() {
		return botonRemoveTodos;
	}

	public void setBotonRemoveTodos(HtmlCommandButton botonRemoveTodos) {
		this.botonRemoveTodos = botonRemoveTodos;
	}
}
