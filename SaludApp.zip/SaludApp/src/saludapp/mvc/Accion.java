package saludapp.mvc;

import javax.servlet.*; 
import javax.servlet.http.*; 
 
public interface Accion { 
	public String ejecutar(HttpServletRequest peticion, 
			HttpServletResponse respuesta, ServletContext aplicacion); 
} 