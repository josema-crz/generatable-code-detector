package saludapp.mvc;

import javax.servlet.*; 
import javax.servlet.http.*; 

import saludapp.controlador.Controlador;

import java.util.*; 

public class AccionListarUsuarios implements Accion { 
	public String ejecutar(HttpServletRequest peticion, 
			HttpServletResponse respuesta, ServletContext aplicacion) { 
		// Hace la llamada al controlador para recuperar los m�dicos y pacientes
		List listaPacientes = Controlador.getUnicaInstancia().getPacientes();
		List listaMedicos = Controlador.getUnicaInstancia().getMedicos();
		
		// Ordena las colecciones
		Collections.sort(listaPacientes);
		Collections.sort(listaMedicos);
		
		// Pasa las colecciones a la p�gina JSP. Patr�n "Service to Worker" 
		peticion.setAttribute("pacientes", listaPacientes); 
		peticion.setAttribute("medicos", listaMedicos);
		
		return "listadoUsuarios.faces"; 
	} 
}