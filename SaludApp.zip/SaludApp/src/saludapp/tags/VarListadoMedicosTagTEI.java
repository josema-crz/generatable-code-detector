package saludapp.tags;

import javax.servlet.jsp.tagext.*;

public class VarListadoMedicosTagTEI extends TagExtraInfo {
	public VariableInfo[] getVariableInfo(TagData data) {
		return new VariableInfo[] {
				new VariableInfo("nombre", "java.lang.String", true,
						VariableInfo.NESTED),
				new VariableInfo("apellidos", "java.lang.String", true,
						VariableInfo.NESTED),
				new VariableInfo("numColegiado", "java.lang.String", true,
						VariableInfo.NESTED),
				new VariableInfo("nombreUsuario", "java.lang.String", true,
						VariableInfo.NESTED) };
	}
}