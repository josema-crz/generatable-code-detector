package saludapp.tags;

import java.util.*; 
import javax.servlet.jsp.*; 
import javax.servlet.jsp.tagext.*; 

import saludapp.modelo.Medico;

public class ListadoMedicosTag extends BodyTagSupport { 
	private static final long serialVersionUID = 1L;
	
	private Collection medicos; 
	private Iterator it; 

	// Atributo de la etiqueta 
	public void setMedicos(Collection medicos) { 
		this.medicos = medicos; 
	} 

	// Utilizamos este m�todo para preparar la primera iteraci�n. 
	// Es preferible al doInitBody ya que podemos 
	// evitar la primera iteraci�n 
	public int doStartTag() throws JspTagException { 
		it = medicos.iterator(); 
		if (!it.hasNext())
			return SKIP_BODY; 
		Medico m = (Medico) it.next(); 
		if (m == null) 
			return SKIP_BODY; 
		else { 
			pageContext.setAttribute("nombre", m.getNombre()); 
			pageContext.setAttribute("apellidos", m.getApellidos()); 
			pageContext.setAttribute("numColegiado", m.getNumColegiado()); 
			pageContext.setAttribute("nombreUsuario", m.getNombreUsuario());
			return EVAL_BODY_AGAIN; 
		} 
	} 

	public int doAfterBody() throws JspTagException { 
		BodyContent bodyContent = getBodyContent(); 
		if (bodyContent != null) { 
			try { 
				// Obtiene la evaluci�n del cuerpo y 
				// lo escribe por la salida 

				bodyContent.getEnclosingWriter().print(bodyContent.getString()); 
				// Vac�a el cuerpo para la siguiente iteraci�n 
				bodyContent.clearBody(); 
			} catch (Exception e) { 
				throw new JspTagException(e.getMessage()); 
			} 
		} 
		// Comprobamos si seguimos iterando 
		if (it.hasNext()) { 
			Medico m = (Medico) it.next(); 
			pageContext.setAttribute("nombre", m.getNombre()); 
			pageContext.setAttribute("apellidos", m.getApellidos()); 
			pageContext.setAttribute("numColegiado", m.getNumColegiado()); 
			pageContext.setAttribute("nombreUsuario", m.getNombreUsuario());
			return EVAL_BODY_AGAIN; 
		} else 
			return SKIP_BODY; 
	} 
}