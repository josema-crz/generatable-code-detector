package saludapp.jms;

import java.util.LinkedList;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BuzonSugerencias {
	public static void enviar(String texto) throws NamingException,
			JMSException {
		InitialContext iniCtx = new InitialContext();
		Object tmp = iniCtx.lookup("QueueConnectionFactory");
		QueueConnectionFactory qcf = (QueueConnectionFactory) tmp;
		QueueConnection conn = qcf.createQueueConnection();
		Queue queue = (Queue) iniCtx.lookup("queue/colaBuzonSugerencias");
		QueueSession session = conn.createQueueSession(false,
				QueueSession.AUTO_ACKNOWLEDGE);
		TextMessage message = (TextMessage) session.createTextMessage();
		message.setText(texto);
		QueueSender queueSender = session.createSender(queue);
		queueSender.send(message);
		conn.close();
	}

	public static List<TextMessage> recibirTodas() throws NamingException,
			JMSException {
		InitialContext iniCtx = new InitialContext();
		Object tmp = iniCtx.lookup("QueueConnectionFactory");
		QueueConnectionFactory qcf = (QueueConnectionFactory) tmp;
		QueueConnection conn = qcf.createQueueConnection();
		Queue queue = (Queue) iniCtx.lookup("queue/colaBuzonSugerencias");
		QueueSession session = conn.createQueueSession(false,
				QueueSession.AUTO_ACKNOWLEDGE);
		QueueReceiver queueReceiver = session.createReceiver(queue);
		conn.start();
		List<TextMessage> messages = new LinkedList<TextMessage>();
		TextMessage message;
		do {
			message = (TextMessage) queueReceiver.receive(2000);
			if (message != null)
				messages.add(message);
		} while (message != null);
		
		conn.close();

		return messages;
	}
}
