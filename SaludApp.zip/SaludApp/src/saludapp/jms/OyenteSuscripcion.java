package saludapp.jms;

import java.util.Map;
import javax.faces.context.FacesContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.joda.time.DateTime;

import saludapp.bean.BeanAvisosMedico;

public class OyenteSuscripcion implements MessageListener {
	private BeanAvisosMedico beanAvisosMedico;

	public OyenteSuscripcion() {
		Map<String, Object> session = FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap();
		beanAvisosMedico = (BeanAvisosMedico) session.get("beanAvisosMedico");
	}

	@Override
	public void onMessage(Message mensaje) {
		if (mensaje instanceof TextMessage) {
			TextMessage mensajeTexto = (TextMessage) mensaje;
			try {
				// Construimos el objeto aviso
				Aviso aviso = new Aviso(mensajeTexto.getJMSMessageID(),
						new DateTime(mensajeTexto.getJMSTimestamp()),
						mensajeTexto.getStringProperty("asunto"),
						mensajeTexto.getText());
				// Lo a�adimos a la colecci�n del bean, con lo que se mostrar�
				// en la interfaz
				beanAvisosMedico.getAvisosMap().put(aviso.getId(), aviso);
			} catch (JMSException e) {
				e.printStackTrace();
			}
		}
	}
}