package saludapp.jms;

import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class AvisosImportantesMedicoX {
	private TopicConnectionFactory qcf;
	private TopicConnection conn;
	private Topic topic;
	private TopicSubscriber topicSubscriber = null;

	private static AvisosImportantesMedicoX unicaInstancia;

	private AvisosImportantesMedicoX() throws NamingException, JMSException {
		InitialContext iniCtx = new InitialContext();
		topic = (Topic) iniCtx.lookup("topic/apartadoAvisosMedico");

		// Creamos la conexi�n y sesi�n que utilizar�n los suscriptores
		Object tmp = iniCtx.lookup("TopicConnectionFactory");
		qcf = (TopicConnectionFactory) tmp;
	}

	public static AvisosImportantesMedicoX getUnicaInstancia()
			throws NamingException, JMSException {
		if (unicaInstancia == null)
			unicaInstancia = new AvisosImportantesMedicoX();
		return unicaInstancia;
	}

	public void enviar(String asunto, String texto, String idMedico)
			throws NamingException, JMSException {
		conn = qcf.createTopicConnection();
		TopicSession session = conn.createTopicSession(false,
				TopicSession.AUTO_ACKNOWLEDGE);
		TextMessage message = session.createTextMessage();
		message.setText(texto);
		message.setStringProperty("asunto", asunto);
		message.setStringProperty("idMedico", idMedico);
		TopicPublisher topicPublisher = session.createPublisher(topic);
		topicPublisher.publish(message, DeliveryMode.PERSISTENT,
				Message.DEFAULT_PRIORITY, 7 * 24 * 3600 * 1000L);
		conn.close();
	}

	/**
	 * Crea o recupera una subscripci�n duradera, lanzando la conexi�n
	 */
	public void registrarApartado(String idPaciente, String idMedico)
			throws NamingException, JMSException {
		if (topicSubscriber == null) {
			conn = qcf.createTopicConnection();
			TopicSession session = conn.createTopicSession(false,
					TopicSession.AUTO_ACKNOWLEDGE);
			topicSubscriber = session.createDurableSubscriber(topic,
					idPaciente, "idMedico LIKE '" + idMedico + "'", false);
			topicSubscriber.setMessageListener(new OyenteSuscripcion());
			conn.start();
		}
	}

	/**
	 * Cierra la subscripci�n JMS y para la conexi�n. Invocado al hacer logout.
	 */
	public void close() throws JMSException {
		if (topicSubscriber != null) {
			topicSubscriber.close();
			topicSubscriber = null;
			conn.close();
		}
	}
}
