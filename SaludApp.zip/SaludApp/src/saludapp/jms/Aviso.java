package saludapp.jms;

import org.joda.time.DateTime;

public class Aviso {
	private String id;
	private String fecha;
	private String asunto;
	private String texto;

	public Aviso(String id, DateTime fecha, String asunto, String texto) {
		super();
		this.id = id;
		this.fecha = fecha.toString("YYYY-MM-dd HH:mm:ss");
		this.asunto = asunto;
		this.texto = texto;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

}
