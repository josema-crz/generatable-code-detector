package saludapp.conversor;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

import org.joda.time.LocalDate;

/**
 * Clase para convertir de String a LocalDate y viceversa
 *
 */
public class ConversorFecha implements Converter {

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2)
			throws ConverterException {
		LocalDate fecha;
		try {
			fecha = new LocalDate(arg2);
		} catch (IllegalArgumentException e) {
			throw new ConverterException(new FacesMessage(ResourceBundle
					.getBundle("saludapp.resource.saludapp").getString(
							"errorFormatoFecha")));
		}
		return fecha;
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ConverterException {
		return arg2.toString();
	}

}
