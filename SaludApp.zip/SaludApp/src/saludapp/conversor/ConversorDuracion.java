package saludapp.conversor;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

import org.joda.time.Duration;

/**
 * Realiza la conversi�n de String a Duration y viceversa, suponiendo una
 * duraci�n por minutos
 * 
 */
public class ConversorDuracion implements Converter {

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2)
			throws ConverterException {
		try {
			return Duration.standardMinutes(Integer.valueOf(arg2));
		} catch (Exception e) {
			throw new ConverterException(new FacesMessage(ResourceBundle
					.getBundle("saludapp.resource.saludapp").getString(
							"errorFormatoDuracion")));
		}
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2)
			throws ConverterException {
		Duration d = (Duration) arg2;
		Integer duracion = (Integer)d.toStandardSeconds().toStandardMinutes().getMinutes();
		return duracion.toString();
	}

}
