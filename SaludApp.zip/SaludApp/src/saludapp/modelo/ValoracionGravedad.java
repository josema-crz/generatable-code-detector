package saludapp.modelo;

public enum ValoracionGravedad {
	ALTA, NORMAL, BAJA;
}
