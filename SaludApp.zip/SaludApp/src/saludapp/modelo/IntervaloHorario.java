package saludapp.modelo;

import org.joda.time.Duration;
import org.joda.time.Instant;
import org.joda.time.Interval;
import org.joda.time.LocalTime;

/**
 * Similar a la clase Interval de Joda Time s�lo que representa un intervalo
 * entre dos horas, no entre dos fechas concretas.
 * 
 */
public class IntervaloHorario implements Comparable<IntervaloHorario> {
	// Usado para la conversi�n a Interval
	private static final Instant CONSTANT = new Instant(0);

	private LocalTime horaInicio; // Hora de inicio
	private LocalTime horaFin; // Hora de fin

	public IntervaloHorario() {
	}

	public IntervaloHorario(LocalTime horaInicio, LocalTime horaFin) {
		// Comprobamos y corregimos en su caso la correcci�n del rango que nos
		// pasan
		if (horaInicio.isAfter(horaFin)) {
			LocalTime temp = horaFin;
			horaFin = horaInicio;
			horaInicio = temp;
		}

		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
	}

	public IntervaloHorario(LocalTime horaInicio, Duration duracion) {
		this.horaInicio = horaInicio;

		this.horaFin = horaInicio.plus(duracion.toPeriod());
	}

	public LocalTime getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(LocalTime horaInicio) {
		this.horaInicio = horaInicio;
	}

	public LocalTime getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(LocalTime horaFin) {
		this.horaFin = horaFin;
	}

	/**
	 * La duraci�n es una propiedad calculada.
	 */
	public Duration getDuracion() {
		// Obtenemos la duracion del Interval asociado
		return this.toInterval().toDuration();
	}

	/**
	 * Define la comparaci�n entre dos intervalos en funci�n de sus horas de
	 * comienzo.
	 */
	@Override
	public int compareTo(IntervaloHorario otro) {
		return horaInicio.compareTo(otro.getHoraInicio());
	}

	/**
	 * Determina si dos intervalos se solapan
	 */
	public boolean seSolapaCon(IntervaloHorario otro) {
		// Delega en el m�todo overlap de Interval
		return this.toInterval().overlaps(otro.toInterval());
	}

	/**
	 * @return el Intervalo representado como objeto Interval
	 */
	private Interval toInterval() {
		return new Interval(horaInicio.toDateTime(CONSTANT),
				horaFin.toDateTime(CONSTANT));
	}

	/**
	 * Establece un retraso en el intervalo de una duracion determinada
	 * 
	 * @param duracion
	 */
	public void setRetraso(Duration duracion) {
		horaInicio = horaInicio.plus(duracion.toPeriod());
		horaFin = horaFin.plus(duracion.toPeriod());
	}

	/**
	 * Determina si dos intervalos son iguales en funci�n de sus horas de inicio
	 * y fin
	 */
	public boolean isEqual(IntervaloHorario otro) {
		return horaInicio.isEqual(otro.getHoraInicio())
				&& horaFin.isEqual(otro.getHoraFin());
	}
}
