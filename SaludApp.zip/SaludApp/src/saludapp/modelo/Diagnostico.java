package saludapp.modelo;

public class Diagnostico {
	private long id;
	
	private String enfermedad;
	private boolean hospitalizacion;
	
	public Diagnostico() {}
	
	public Diagnostico(String enfermedad, boolean hospitalizacion) {
		this.enfermedad = enfermedad;
		this.hospitalizacion = hospitalizacion;
	}

	public String getEnfermedad() {
		return enfermedad;
	}

	public void setEnfermedad(String enfermedad) {
		this.enfermedad = enfermedad;
	}

	public boolean isHospitalizacion() {
		return hospitalizacion;
	}

	public void setHospitalizacion(boolean hospitalizacion) {
		this.hospitalizacion = hospitalizacion;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
}
