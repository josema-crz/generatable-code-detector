package saludapp.modelo;

import org.joda.time.LocalDate;

public class Tratamiento {
	private long id;
	
	private String medicamento;
	private double cantidad;
	private double dosisDiaria;
	private LocalDate inicio;
	private LocalDate fin;
	
	public Tratamiento() {}

	public Tratamiento(String medicamento, double cantidad, double dosisDiaria,
			LocalDate inicio, LocalDate fin) {
		super();
		this.medicamento = medicamento;
		this.cantidad = cantidad;
		this.dosisDiaria = dosisDiaria;
		this.inicio = inicio;
		this.fin = fin;
	}

	public String getMedicamento() {
		return medicamento;
	}

	public void setMedicamento(String medicamento) {
		this.medicamento = medicamento;
	}

	public double getCantidad() {
		return cantidad;
	}

	public void setCantidad(double cantidad) {
		this.cantidad = cantidad;
	}

	public double getDosisDiaria() {
		return dosisDiaria;
	}

	public void setDosisDiaria(double dosisDiaria) {
		this.dosisDiaria = dosisDiaria;
	}

	public LocalDate getInicio() {
		return inicio;
	}

	public void setInicio(LocalDate inicio) {
		this.inicio = inicio;
	}

	public LocalDate getFin() {
		return fin;
	}

	public void setFin(LocalDate fin) {
		this.fin = fin;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
}
