package saludapp.modelo;

public enum EstadoIntervalo {
	NOCONTEMPLADO, OCUPADO, DISPONIBLE; 
}
