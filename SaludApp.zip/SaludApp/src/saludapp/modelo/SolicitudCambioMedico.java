package saludapp.modelo;

public class SolicitudCambioMedico {
	private long id;
	
	private Paciente paciente;
	private Medico nuevoMedico;
	private String motivoCambio;
	private boolean resuelta;
	private boolean aceptada;
	
	public SolicitudCambioMedico() {}
	
	public SolicitudCambioMedico(Paciente paciente, Medico nuevoMedico,
			String motivoCambio) {
		super();
		this.paciente = paciente;
		this.nuevoMedico = nuevoMedico;
		this.motivoCambio = motivoCambio;
		
		resuelta = false;
		aceptada = false;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Medico getNuevoMedico() {
		return nuevoMedico;
	}

	public void setNuevoMedico(Medico nuevoMedico) {
		this.nuevoMedico = nuevoMedico;
	}

	public String getMotivoCambio() {
		return motivoCambio;
	}

	public void setMotivoCambio(String motivoCambio) {
		this.motivoCambio = motivoCambio;
	}
	
	public void resolver(boolean aceptada) {
		if (aceptada) {
			Medico antiguo = paciente.getAdscrito();			

			if (antiguo != null)
				antiguo.desvincularPaciente(paciente);		
			
			nuevoMedico.adscribirPaciente(paciente);
		}
		setAceptada(aceptada);
		setResuelta(true);
		// TODO Implementar aviso al paciente
	}

	public boolean isResuelta() {
		return resuelta;
	}

	public void setResuelta(boolean resuelta) {
		this.resuelta = resuelta;
	}

	public boolean isAceptada() {
		return aceptada;
	}

	public void setAceptada(boolean aceptada) {
		this.aceptada = aceptada;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
}
