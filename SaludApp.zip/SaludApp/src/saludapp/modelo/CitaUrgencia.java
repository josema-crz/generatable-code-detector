package saludapp.modelo;

import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;


public class CitaUrgencia extends Cita {
	private String motivoUrgencia;
	
	public CitaUrgencia() {
		super();
	}	
	
	public CitaUrgencia(LocalDate fecha, LocalTime hora, Duration duracion, Paciente paciente, 
			Medico medico, String motivoUrgencia) {
		super(fecha, hora, duracion, paciente, medico);
		
		this.motivoUrgencia = motivoUrgencia;
	}
	
	public CitaUrgencia(LocalDate fecha, LocalTime hora, Paciente paciente, Medico medico,
			String motivoUrgencia) {
		this(fecha, hora, getDuracionPorDefecto(), paciente, medico, motivoUrgencia);
	}

	public String getMotivoUrgencia() {
		return motivoUrgencia;
	}

	public void setMotivoUrgencia(String motivoUrgencia) {
		this.motivoUrgencia = motivoUrgencia;
	}
	
	
}

