package saludapp.modelo;

public abstract class Usuario implements Comparable<Usuario> {
	private long id;
	
	private String nombre;
	private String apellidos;
	private String nombreUsuario;
	private String clave;
	
	public Usuario() {}
	
	public Usuario(String nombre, String apellidos, String usuario, String clave) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.nombreUsuario = usuario;
		this.clave = clave;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	/**
	 * Compara dos usuarios en funci�n de sus apellidos y su nombre
	 */
	@Override
	public int compareTo(Usuario otro) {
		int comparacionApellidos = apellidos.compareTo(otro.getApellidos());
		if (comparacionApellidos == 0)
			return nombre.compareTo(otro.getNombre());
		return comparacionApellidos;
	}	
}

