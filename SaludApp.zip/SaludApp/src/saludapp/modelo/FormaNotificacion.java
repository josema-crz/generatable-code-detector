package saludapp.modelo;

public enum FormaNotificacion {
	SMS, MAIL;
}
