package saludapp.modelo;

public class Administrador extends Usuario {

	public Administrador() {
		super();
	}

	public Administrador(String usuario, String clave) {
		super("", "", usuario, clave);
	}
	
}
