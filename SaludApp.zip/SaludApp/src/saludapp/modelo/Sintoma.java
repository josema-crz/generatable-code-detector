package saludapp.modelo;

public class Sintoma {
	private long id;
	
	private String descripcion;
	private ValoracionGravedad valoracionGravedad;
	
	public Sintoma() {}
	
	public Sintoma(String descripcion, ValoracionGravedad valoracionGravedad) {		
		this.descripcion = descripcion;
		this.valoracionGravedad = valoracionGravedad;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public ValoracionGravedad getValoracionGravedad() {
		return valoracionGravedad;
	}

	public void setValoracionGravedad(ValoracionGravedad valoracionGravedad) {
		this.valoracionGravedad = valoracionGravedad;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
}
