package saludapp.modelo;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import org.joda.time.Duration;
import org.joda.time.LocalTime;

public class Medico extends Usuario {
	static final int CUPO_PACIENTES = 100;

	private String numColegiado;
	private int cupoPacientes;

	private CentroMedico centroMedico;

	private List<Cita> citas;

	private HorarioConsulta horario;

	public Medico() {
		super();

		citas = new LinkedList<Cita>();
		cupoPacientes = CUPO_PACIENTES;
		horario = new HorarioConsulta(this);
	}

	public Medico(String nombre, String apellidos, String usuario,
			String clave, String numColegiado, CentroMedico centroMedico) {
		super(nombre, apellidos, usuario, clave);

		this.numColegiado = numColegiado;
		this.centroMedico = centroMedico;

		centroMedico.addMedico(this);

		citas = new LinkedList<Cita>();
		cupoPacientes = CUPO_PACIENTES;
		horario = new HorarioConsulta(this);
	}

	public Medico(String nombre, String apellidos, String usuario,
			String clave, String numColegiado, CentroMedico centroMedico,
			int cupoPacientes) {
		this(nombre, apellidos, usuario, clave, numColegiado, centroMedico);
		this.cupoPacientes = cupoPacientes;
	}

	public String getNumColegiado() {
		return numColegiado;
	}

	public void setNumColegiado(String numColegiado) {
		this.numColegiado = numColegiado;
	}

	public CentroMedico getCentroMedico() {
		return centroMedico;
	}

	public void setCentroMedico(CentroMedico centroMedico) {
		this.centroMedico = centroMedico;
	}

	public int getCupoPacientes() {
		return cupoPacientes;
	}

	public void setCupoPacientes(int cupoPacientes) {
		this.cupoPacientes = cupoPacientes;
	}

	public void addCita(Cita cita) {
		citas.add(cita);
	}

	public void removeCita(Cita cita) {
		citas.remove(cita);
	}

	public List<Cita> getCitas() {
		return new LinkedList<Cita>(citas);
	}

	public void setCitas(List<Cita> citas) {
		this.citas = citas;
	}

	public HorarioConsulta getHorario() {
		return horario;
	}

	public void setHorario(HorarioConsulta horario) {
		this.horario = horario;
	}

	/**
	 * Establece la relaci�n entre el paciente y el m�dico, eliminando el m�dico
	 * adscrito hasta el momento al paciente en caso de que lo hubiera.
	 * 
	 * @param paciente
	 * 
	 * @return 0 todo ha ido correctamente -1 se ha alcanzado el cupo de
	 *         pacientes del m�dico
	 */
	public int adscribirPaciente(Paciente paciente) {
		if (cupoPacientes == 0)
			return -1;		

		cupoPacientes--;
		paciente.setAdscrito(this);

		return 0;
	}

	/**
	 * Elimina la relaci�n entre el m�dico y un paciente
	 * 
	 * @param paciente
	 */
	public void desvincularPaciente(Paciente paciente) {
		cupoPacientes++;		
		paciente.setAdscrito(null);
	}

	/**
	 * Devuelve los intervalos ocupados dado un conjunto de citas
	 * 
	 * @param citas
	 *            Las citas de un d�a en concreto
	 */
	private List<IntervaloHorario> getIntervalosOcupados(List<Cita> citas) {
		List<IntervaloHorario> ocupados = new LinkedList<IntervaloHorario>();

		// Obtenemos los intervalos correspondientes a las citas que nos
		// pasan
		for (Cita cita : citas)
			ocupados.add(cita.getIntervalo());

		return ocupados;
	}

	/**
	 * Determina el estado de un conjunto de intervalos, dado un conjunto de
	 * citas concreto, y teniendo en cuenta los intervalos no contemplados en el
	 * horario
	 * 
	 * @param citas
	 *            Las citas de un d�a en concreto
	 */
	public List<EstadoIntervalo> getEstadosIntervalos(
			List<IntervaloHorario> intervalos, List<Cita> citas) {
		List<EstadoIntervalo> estados = new LinkedList<EstadoIntervalo>();

		// Si el horario no est� bien configurado, se mostrar�n todos los
		// intervalos como no contemplados, excepto cuando estemos configurando
		// el propio horario (citas=null)
		if (!horario.esCorrecto() && citas != null) {
			for (int i = 0; i < intervalos.size(); i++)
				estados.add(EstadoIntervalo.NOCONTEMPLADO);

		} else {
			// Obtenemos los intervalos no contemplados en el horario
			List<IntervaloHorario> noContemplados = getIntervalosNoContemplados();
			// Obtenemos los intervalos ocupados para ese conjunto de citas
			List<IntervaloHorario> ocupados = new LinkedList<IntervaloHorario>();
			if (citas != null)
				ocupados = getIntervalosOcupados(citas);

			EstadoIntervalo estado;
			// Para cada intervalo:
			for (IntervaloHorario intervalo : intervalos) {
				// Comprobamos que est� dentro de los l�mites
				if (!horario.esPosible(intervalo))
					estado = EstadoIntervalo.NOCONTEMPLADO;
				else {
					// Comprobamos que no se solapa con ninguno de ellos
					estado = EstadoIntervalo.DISPONIBLE;

					for (IntervaloHorario i : noContemplados)
						if (intervalo.seSolapaCon(i))
							estado = EstadoIntervalo.NOCONTEMPLADO;

					for (IntervaloHorario i : ocupados)
						if (intervalo.seSolapaCon(i))
							estado = EstadoIntervalo.OCUPADO;
				}

				estados.add(estado);
			}
		}
		return estados;
	}

	/**
	 * Establece un retraso con la duraci�n especificada a partir de una hora,
	 * para el conjunto de citas especificado, modificando la hora de las citas
	 * afectadas. Devuelve las citas afectadas por el retraso.
	 * 
	 * @param citas
	 *            Las citas de un d�a en concreto
	 */
	public List<Cita> setRetraso(List<Cita> citas, LocalTime hora,
			Duration duracion) {
		List<Cita> citasAfectadas = new LinkedList<Cita>();

		if (!citas.isEmpty()) { // Lista no vac�a
			// Ordenamos las citas:
			Collections.sort(citas);

			ListIterator<Cita> iter = citas.listIterator();
			Cita cita;
			// Eliminamos las citas anteriores a la hora de retraso
			do
				cita = iter.next();
			while (iter.hasNext()
					&& !cita.getIntervalo().getHoraFin().isAfter(hora));

			if (iter.hasNext()
					|| cita.getIntervalo().getHoraFin().isAfter(hora)) {
				boolean fin = false;
				LocalTime h = hora;

				// Si la hora de inicio del retraso se halla en medio de una
				// cita, esa cita se ignora y no se retrasa
				if (cita.getIntervalo().getHoraInicio().isBefore(hora)) {
					// Aunque no se modifica la metemos en la lista de afectadas
					// para informar de esta situaci�n
					citasAfectadas.add(cita);

					// Actualizamos h, la hora que vamos tomando como referencia
					// de inicio del retraso
					h = cita.getIntervalo().getHoraFin();

					if (iter.hasNext())
						cita = iter.next();
					else
						fin = true;
				}

				// Tenemos en cuenta los huecos entre citas, que se ir�n
				// 'tragando' el retraso establecido
				while (fin == false) {
					// Hallamos el hueco con respecto al anterior punto de
					// referencia
					Duration hueco = new Duration(h.toDateTimeToday(), cita
							.getIntervalo().getHoraInicio().toDateTimeToday());

					// Si el hueco iguala o supera al retraso, entonces 'se lo
					// traga' y no es necesario seguir retrasando citas
					if (hueco.isLongerThan(duracion) || hueco.isEqual(duracion))
						fin = true;
					else {
						// Si no, calculamos la nueva duraci�n del retraso, que
						// se ver� disminuida si hab�a hueco
						duracion = duracion.minus(hueco);
						// Establecemos la siguiente hora que tomaremos como
						// referencia
						h = cita.getIntervalo().getHoraFin();
						// Retrasamos la cita
						cita.setRetraso(duracion);
						citasAfectadas.add(cita);

						if (iter.hasNext())
							cita = iter.next();
						else
							fin = true;
					}
				}
			}
		}
		return citasAfectadas;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		return false;
	}

	private List<IntervaloHorario> getIntervalosNoContemplados() {
		return horario.getIntervalosNoContemplados();
	}

}
