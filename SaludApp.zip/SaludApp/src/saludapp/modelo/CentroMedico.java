package saludapp.modelo;

import java.util.HashSet;
import java.util.Set;

public class CentroMedico {
	private long id;
	
	private String nombre;
	private String direccion;
	
	private Set<Medico> medicos;
	private Set<Paciente> pacientes;
	
	public CentroMedico() {}
	
	public CentroMedico(String nombre, String direccion) {
		this.nombre = nombre;
		this.direccion = direccion;
		medicos = new HashSet<Medico>();
		pacientes = new HashSet<Paciente>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	public void addMedico(Medico medico){
		medicos.add(medico);
		medico.setCentroMedico(this);
	}
	
	public void removeMedico(Medico medico) {
		if (medicos.contains(medico)) {
			medicos.remove(medico);
			medico.setCentroMedico(null);
		}
	}
	
	public void addPaciente(Paciente paciente){
		pacientes.add(paciente);
		paciente.setCentroMedico(this);
	}
	
	public void removePaciente(Paciente paciente) {
		if (pacientes.contains(paciente)) {
			pacientes.remove(paciente);
			paciente.setCentroMedico(null);
		}
	}

	public Set<Medico> getMedicos() {
		return new HashSet<Medico>(medicos);
	}

	public void setMedicos(Set<Medico> medicos) {
		this.medicos = medicos;
	}

	public Set<Paciente> getPacientes() {
		return new HashSet<Paciente>(pacientes);
	}

	public void setPacientes(Set<Paciente> pacientes) {
		this.pacientes = pacientes;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
}
