package saludapp.modelo;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.joda.time.LocalTime;

public class HorarioConsulta {
	public static final int MINIMO_HORAS_CONSULTA = 7;
	
	// La hora m�nima de inicio son las 8:00
	static final LocalTime horaMinInicio = new LocalTime(8, 0, 0);
	
	// La hora m�xima de fin son las 21:00
	static final LocalTime horaMaxFin = new LocalTime(21, 0, 0);
	
	// La duraci�n m�nima de un retraso
	public static final int RETRASO_MIN = 10;
	// Y la m�xima
	public static final int RETRASO_MAX = 180;
	
	private long id;
	
	private int minimoHoras;
	private int totalMinutos;
	
	private Medico medico;
	
	private List<IntervaloHorario> intervalos;
	
	
	public HorarioConsulta() {
		intervalos = new LinkedList<IntervaloHorario>();
		totalMinutos = 0;
	}
	
	public HorarioConsulta(Medico medico, int minimoHoras) {
		this();
		
		// Horas totales de consulta m�nimas:
		this.minimoHoras = minimoHoras;
		this.medico = medico;
	}
	
	public HorarioConsulta(Medico medico) {
		this(medico, MINIMO_HORAS_CONSULTA);
	}
	
	

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public int getMinimoHoras() {
		return minimoHoras;
	}

	public void setMinimoHoras(int minimoHoras) {
		this.minimoHoras = minimoHoras;
	}
	
	/**
	 * Un horario determinado es correcto cuando el total de horas de consulta definidas en �l iguala o supera
	 * el m�nimo establecido
	 */
	public boolean esCorrecto() {
		return totalMinutos >= minimoHoras*60;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getTotalMinutos() {
		return totalMinutos;
	}

	public void setTotalMinutos(int totalMinutos) {
		this.totalMinutos = totalMinutos;
	}

	/**
	 * Devuelve los intervalos de consulta definidos para este horario.
	 */
	public List<IntervaloHorario> getIntervalos() {
		return new LinkedList<IntervaloHorario>(intervalos);
	}

	public void setIntervalos(List<IntervaloHorario> intervalos) {
		this.intervalos = intervalos;
	}
	
	public boolean addIntervalo(IntervaloHorario intervalo) {
		// Comprobamos que el intervalo se encuentra entre los l�mites definidos
		if (!esPosible(intervalo))	return false;
		
		// Comprobamos que el intervalo no se solapa con los ya existentes
		for (IntervaloHorario inter : intervalos)
			if (intervalo.seSolapaCon(inter))
				return false;
		
		// Lo a�adimos
		intervalos.add(intervalo);
		
		// Mantenemos los intervalos ordenados
		Collections.sort(intervalos);
		
		// Actualizamos el total de minutos
		totalMinutos += intervalo.getDuracion().toStandardSeconds().toStandardMinutes().getMinutes();
		
		return true;
	}
	
	public boolean removeIntervalo(IntervaloHorario intervalo) {
		// Buscamos el intervalo entre los definidos y, si lo encontramos, lo eliminamos
		for (IntervaloHorario inter : intervalos)
			if (intervalo.isEqual(inter)) {
				intervalos.remove(inter);
				// Actualizamos el total de minutos
				totalMinutos -= inter.getDuracion().toStandardSeconds().toStandardMinutes().getMinutes();
				return true;
			}			
		return false;
	}
	
	public void removeIntervalos() {
		intervalos.clear();
		totalMinutos = 0;
	}

	/**
	 * Devuelve el intervalo que representa el total de horas disponibles para asignar al horario.
	 */
	public static IntervaloHorario getIntervaloTotal() {
		return new IntervaloHorario(horaMinInicio, horaMaxFin);
	}
	
	/**
	 * Devuelve los intervalos no contemplados por el horario (las horas dentro del l�mite inferior y superior
	 * durante las que no hay consulta)
	 */
	public List<IntervaloHorario> getIntervalosNoContemplados() {
		List<IntervaloHorario> noContemplados = new LinkedList<IntervaloHorario>();		
				
		// Sacamos los intervalos no definidos, con cuidado de incluir al que va desde horaMinInicio al
		// primer intervalo definido y desde el �ltimo definido hasta horaMaxFin.
		LocalTime horaInicio = horaMinInicio;
		for (IntervaloHorario intervalo : intervalos) {
			noContemplados.add(new IntervaloHorario(horaInicio, intervalo.getHoraInicio()));
			horaInicio = intervalo.getHoraFin();
		}
		noContemplados.add(new IntervaloHorario(horaInicio, horaMaxFin));		
		
		return noContemplados;
	}
	
	/**
	 * Indica si un intervalo se encuentra dentro de los l�mites horarios
	 */
	public boolean esPosible(IntervaloHorario intervalo) {
		return !(intervalo.getHoraInicio().isBefore(horaMinInicio) 
				|| intervalo.getHoraFin().isAfter(horaMaxFin));
	}
}
