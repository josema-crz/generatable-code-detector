package saludapp.modelo;

import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Set;

import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;

import saludapp.controlador.Controlador;

public class Cita implements Comparable<Cita> {
	static final Duration DURACION_POR_DEFECTO = Duration.standardMinutes(15);
	public static final int DURACION_MINIMA = 5;
	public static final int DURACION_MAXIMA = 60;

	private long id;

	private LocalDate fecha;
	private IntervaloHorario intervalo;

	private Paciente paciente;
	private Medico medico;

	private Set<Sintoma> sintomas;
	private Set<Diagnostico> diagnosticos;
	private Set<Tratamiento> tratamientos;

	public Cita() {
	}

	public Cita(LocalDate fecha, LocalTime hora, Duration duracion,
			Paciente paciente, Medico medico) {
		this.paciente = paciente;
		this.medico = medico;
		this.fecha = fecha;
		this.intervalo = new IntervaloHorario(hora, duracion);

		sintomas = new HashSet<Sintoma>();
		diagnosticos = new HashSet<Diagnostico>();
		tratamientos = new HashSet<Tratamiento>();

		medico.addCita(this);
		paciente.addCita(this);
	}

	public Cita(LocalDate fecha, LocalTime hora, Paciente paciente,
			Medico medico) {
		this(fecha, hora, DURACION_POR_DEFECTO, paciente, medico);
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public IntervaloHorario getIntervalo() {
		return intervalo;
	}

	public void setIntervalo(IntervaloHorario intervalo) {
		this.intervalo = intervalo;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public Set<Sintoma> getSintomas() {
		return new HashSet<Sintoma>(sintomas);
	}

	public void setSintomas(Set<Sintoma> sintomas) {
		this.sintomas = sintomas;
	}

	public void addSintoma(Sintoma sintoma) {
		sintomas.add(sintoma);
	}

	public void removeSintoma(Sintoma sintoma) {
		sintomas.remove(sintoma);
	}

	public Set<Diagnostico> getDiagnosticos() {
		return new HashSet<Diagnostico>(diagnosticos);
	}

	public void setDiagnosticos(Set<Diagnostico> diagnosticos) {
		this.diagnosticos = diagnosticos;
	}

	public void addDiagnostico(Diagnostico diagnostico) {
		diagnosticos.add(diagnostico);
	}

	public void removeDiagnostico(Diagnostico diagnostico) {
		diagnosticos.remove(diagnostico);
	}

	public Set<Tratamiento> getTratamientos() {
		return new HashSet<Tratamiento>(tratamientos);
	}

	public void setTratamientos(Set<Tratamiento> tratamientos) {
		this.tratamientos = tratamientos;
	}

	public void addTratamiento(Tratamiento tratamiento) {
		tratamientos.add(tratamiento);
	}

	public void removeTratamiento(Tratamiento tratamiento) {
		tratamientos.remove(tratamiento);
	}

	public static Duration getDuracionPorDefecto() {
		return DURACION_POR_DEFECTO;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Establece un retraso sobre la cita, de una duraci�n determinada. Comunica
	 * el retraso al paciente.
	 * 
	 * @param duracion
	 */
	public void setRetraso(Duration duracion) {
		intervalo.setRetraso(duracion);

		comunicarRetraso(duracion);
	}

	/**
	 * Comunica la nueva hora de la cita tras el retraso, utilizando la forma de
	 * notificaci�n configurada en el paciente.
	 */
	private void comunicarRetraso(Duration duracion) {
		// Construimos el mensaje comunicando los nuevos datos de la cita
		String eol = System.getProperty("line.separator");
		String mensaje = "Se ha modificado su cita:" + eol + "D�a: " + fecha
				+ eol + "Hora: " + intervalo.getHoraInicio() + eol + "M�dico: "
				+ medico.getApellidos() + ", " + medico.getNombre() + eol
				+ "Centro m�dico: " + medico.getCentroMedico().getNombre();

		// Obtenemos los otros datos necesarios para el env�o
		String destino = "";
		String forma = "";
		switch (paciente.getFormaNotificacion()) {
		case SMS:
			destino = paciente.getTelefono();
			forma = "SMS";
			break;
		case MAIL:
			destino = paciente.getMail();
			forma = "Mail";
			break;
		}

		// Enviamos la notificaci�n utilizando el gestor de avisos
		try {
			Controlador.getUnicaInstancia().getGestorAvisos()
					.enviar(forma, destino, mensaje);
		} catch (RemoteException e) {
			System.err.println("Error al acceder al objeto remoto");
		}
	}

	/**
	 * Compara dos fechas en funci�n de su fecha. Si la fecha es igual, entonces
	 * compara sus horas de comienzo.
	 */
	@Override
	public int compareTo(Cita otra) {
		int comparacionFechas = fecha.compareTo(otra.getFecha());
		if (comparacionFechas == 0)
			return intervalo.compareTo(otra.getIntervalo());
		return comparacionFechas;
	}
}
