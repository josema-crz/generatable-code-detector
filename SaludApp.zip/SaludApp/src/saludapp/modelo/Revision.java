package saludapp.modelo;

import org.joda.time.Duration;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;



public class Revision extends Cita {
	private String motivoRevision;
	private Cita revisada;
	
	public Revision() {
		super();
	}
	
	public Revision(LocalDate fecha, LocalTime hora, Paciente paciente, Medico medico,
			String motivoRevision, Cita revisada) {
		super(fecha, hora, paciente, medico);
		
		this.motivoRevision = motivoRevision;
		this.revisada = revisada;
	}
	
	public Revision(LocalDate fecha, LocalTime hora, Duration duracion, Paciente paciente, 
			Medico medico, String motivoRevision, Cita revisada) {
		super(fecha, hora, duracion, paciente, medico);
		
		this.motivoRevision = motivoRevision;
		this.revisada = revisada;
	}

	public String getMotivoRevision() {
		return motivoRevision;
	}

	public void setMotivoRevision(String motivoRevision) {
		this.motivoRevision = motivoRevision;
	}

	public Cita getRevisada() {
		return revisada;
	}

	public void setRevisada(Cita revisada) {
		this.revisada = revisada;
	}
	
	
}
