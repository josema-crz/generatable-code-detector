package saludapp.modelo;

import java.util.LinkedList;
import java.util.List;

public class Paciente extends Usuario {
	private String NSS;
	private String numTarjeta;
	private String telefono;
	private String movil;
	private String direccion;
	private String mail;
	private FormaNotificacion formaNotificacion;
	
	private CentroMedico centroMedico;	
	private Medico adscrito;
	
	private List<Cita> historial; // Se presupone ordenado (las citas se van insertando en orden)
	
	public Paciente() {
		super();
		
		historial = new LinkedList<Cita>();
	}
	
	public Paciente(String nombre, String apellidos, String usuario, String clave, 
			String nSS, String numTarjeta, String telefono,
			String movil, String direccion, String mail,
			FormaNotificacion formaNotificacion, CentroMedico centroMedico) {
		super(nombre, apellidos, usuario, clave);
		
		NSS = nSS;
		this.numTarjeta = numTarjeta;
		this.telefono = telefono;
		this.movil = movil;
		this.direccion = direccion;
		this.mail = mail;
		this.formaNotificacion = formaNotificacion;
		this.centroMedico = centroMedico;
		
		centroMedico.addPaciente(this);
		
		historial = new LinkedList<Cita>();
	}



	public String getNSS() {
		return NSS;
	}

	public void setNSS(String nSS) {
		NSS = nSS;
	}

	public String getNumTarjeta() {
		return numTarjeta;
	}

	public void setNumTarjeta(String numTarjeta) {
		this.numTarjeta = numTarjeta;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getMovil() {
		return movil;
	}

	public void setMovil(String movil) {
		this.movil = movil;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public Medico getAdscrito() {
		return adscrito;
	}

	public void setAdscrito(Medico adscrito) {
		this.adscrito = adscrito;
	}	

	public FormaNotificacion getFormaNotificacion() {
		return formaNotificacion;
	}

	public void setFormaNotificacion(FormaNotificacion formaNotificacion) {
		this.formaNotificacion = formaNotificacion;
	}

	public List<Cita> getHistorial() {
		return new LinkedList<Cita>(historial);
	}	
	
	public void setHistorial(List<Cita> historial) {
		this.historial = historial;
	}

	public void addCita(Cita cita) {
		historial.add(cita);
	}
	
	public void removeCita(Cita cita) {
		historial.remove(cita);
	}

	public CentroMedico getCentroMedico() {
		return centroMedico;
	}

	public void setCentroMedico(CentroMedico centroMedico) {
		this.centroMedico = centroMedico;
	}
	
	
}
