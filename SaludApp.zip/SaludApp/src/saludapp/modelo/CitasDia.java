package saludapp.modelo;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Clase intermedia que contiene las citas de un d�a determinado
 * Fue necesario declararla por la dificultad de persistir un multimap en hibernate
 *
 */
public class CitasDia {
	private long id;
	
	private List<Cita> citas;
	
	public CitasDia() {
		citas = new LinkedList<Cita>();
	}
	
	public void addCita(Cita cita) {
		citas.add(cita);
	}
	
	public void removeCita(Cita cita) {
		citas.remove(cita);
	}

	public List<Cita> getCitas() {
		return citas;
	}

	public void setCitas(List<Cita> citas) {
		this.citas = citas;
	}
	
	public void ordenar() {
		Collections.sort(citas);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
}
