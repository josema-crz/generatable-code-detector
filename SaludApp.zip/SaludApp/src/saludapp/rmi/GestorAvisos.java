package saludapp.rmi;


import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GestorAvisos extends Remote {
	public boolean enviar(String formaNotificacion, String destino,
			String mensaje) throws RemoteException;
}
